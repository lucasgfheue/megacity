package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import static com.megaciudad.core.little.Kit.*;

/** Decoraciones básicas de interiores y patios (las primeras del mod), ahora con bloques de mods. */
public final class DecoIn {
    private DecoIn() {
    }

    public static final Model RECEPTION = row2("recepcion", n(3, counter("white")),
            a(DESK_BELL, r(RF + "computer[facing=north,powered=false]|" + MC + "black_carpet"), lamp("white")));
    public static final Model SOFA = row("sofa", sofaRow("gray", 2));
    public static final Model SOFA_RED = row("sofa_rojo", sofaRow("red", 2));
    public static final Model SOFA_BLUE = row("sofa_azul", sofaRow("blue", 2));
    public static final Model ARMCHAIR = one("sillon", sofa("light_gray", "default"));
    public static final Model COFFEE_TABLE = one("mesa_centro", cloth("light_gray"));
    public static final Model PLANT = col("planta", potted("flowering_azalea_bush"), leaves("flowering_azalea"));
    public static final Model DESK = row2("escritorio", deskRow("birch", 2), a(COMPUTER, null));
    public static final Model OFFICE_CHAIR = one("silla_oficina", seat("gray"));

    // ------------------------------------------------------------------ supermercado

    private static final BlockRef[][][] SHELF_GOODS = {
            {{fdCrate("carrot"), fdCrate("cabbage"), fdCrate("tomato")}, {fdCrate("potato"), fdCrate("onion"), fdCrate("beetroot")}},
            {{CARDBOARD, edCrate("egg_crate"), RICE_BAG}, {r(ED + "flour_sack|" + MC + "white_wool"), CARDBOARD_TIED, r(ED + "coffee_bean_sack|" + MC + "brown_wool")}},
            {{STRAWBERRIES, BANANAS, MINT}, {edCrate("apple_crate"), edCrate("golden_apple_crate"), CHOCOLATE_BLOCK}},
            {{BARREL_N, BARREL_N, BARREL_N}, {r(NP + "sugar_sack[facing=up]|" + MC + "white_wool"), r(NP + "cocoa_bean_sack[facing=up]|" + MC + "brown_wool"), BARREL_UP}},
    };
    private static final Model[] SHELVES = new Model[SHELF_GOODS.length];

    static {
        for (int i = 0; i < SHELVES.length; i++) SHELVES[i] = row2("gondola" + i, SHELF_GOODS[i][0], SHELF_GOODS[i][1]);
    }

    public static Model shelf(int variant) {
        return SHELVES[Math.floorMod(variant, SHELVES.length)];
    }

    public static final Model FRIDGE = row2("heladera_super", n(2, FREEZER_L), n(2, FRIDGE_L));

    public static final Model CHECKOUT = m("caja", 2, 2, 3)
            .fill(0, 0, 0, 0, 0, 2, counter("light_gray"))
            .b(0, 1, 1, STOCK_TICKER).b(0, 1, 0, DESK_BELL)
            .b(1, 0, 1, seat("black"));
    public static final Model CART = one("carrito", HOPPER);
    public static final Model FRUIT_STAND = row("puesto_frutas", edCrate("apple_crate"), BANANAS);
    public static final Model BAKERY = row2("vitrina_panaderia", n(2, foodDisplay("oak")), a(pie("apple_pie"), edPie("chocolate_cheesecake")));

    // ------------------------------------------------------------------ ropa

    private static final String[][] CLOTHES = {{"red", "blue"}, {"black", "white"}, {"pink", "light_blue"}, {"green", "yellow"}};
    private static final Model[] RACKS = new Model[CLOTHES.length], MANNEQUINS = new Model[CLOTHES.length];

    static {
        for (int i = 0; i < CLOTHES.length; i++) {
            RACKS[i] = m("perchero" + i, 2, 2, 1).b(0, 0, 0, standingBanner(CLOTHES[i][0])).b(1, 0, 0, standingBanner(CLOTHES[i][1]));
            MANNEQUINS[i] = col("maniqui" + i, standingBanner(CLOTHES[i][1]), null);
        }
    }

    public static Model clothesRack(int variant) {
        return RACKS[Math.floorMod(variant, RACKS.length)];
    }

    public static Model mannequin(int variant) {
        return MANNEQUINS[Math.floorMod(variant, MANNEQUINS.length)];
    }

    public static final Model DISPLAY_TABLE = row("mesa_exhibidora", cloth("white"), cloth("white"));

    // ------------------------------------------------------------------ patio de comidas

    private static BlockRef chairFacingSouth(String wood) {
        return r(RF + wood + "_chair[facing=north,tucked=false]|" + MC + wood + "_stairs[facing=north]");
    }

    private static final BlockRef[][] MEALS = {
            {feast("roast_chicken_block"), edFeast("lasagna_block", "shepherds_pie_block")},
            {edFeast("curry_block", "rice_roll_medley_block"), feast("stuffed_pumpkin_block")},
            {edFeast("bbq_ribs_block", "honey_glazed_ham_block"), pie("chocolate_pie")},
            {edFeast("hotdish_block", "shepherds_pie_block"), edPie("lemon_meringue_pie")},
            {feast("shepherds_pie_block"), edFeast("brownies", "roast_chicken_block")},
    };
    private static final String[] TABLE_WOODS = {"oak", "spruce", "birch", "dark_oak", "cherry"};
    private static final Model[] FOOD_TABLES = new Model[MEALS.length];
    private static final String[] PARASOLS = {"red", "yellow", "blue", "white", "green", "orange"};
    private static final Model[] PARASOL_TABLES = new Model[PARASOLS.length];

    static {
        for (int i = 0; i < MEALS.length; i++) {
            String w = TABLE_WOODS[i % TABLE_WOODS.length];
            FOOD_TABLES[i] = m("mesa_patio" + i, 2, 2, 2)
                    .b(0, 0, 1, table(w, false, true, false, false)).b(1, 0, 1, table(w, false, false, false, true))
                    .b(0, 0, 0, chairFacingSouth(w)).b(1, 0, 0, chairFacingSouth(w))
                    .b(0, 1, 1, MEALS[i][0]).b(1, 1, 1, MEALS[i][1]);
        }
        for (int i = 0; i < PARASOLS.length; i++) {
            String w = TABLE_WOODS[i % TABLE_WOODS.length];
            Model m = m("sombrilla" + i, 3, 3, 3);
            m.b(1, 0, 1, table(w, false, false, false, false)).b(1, 1, 1, v("oak_fence"));
            m.fill(0, 2, 0, 2, 2, 2, v(PARASOLS[i] + "_wool"));
            m.b(0, 0, 1, r(RF + w + "_chair[facing=west,tucked=false]|" + MC + w + "_stairs[facing=west]"));
            m.b(2, 0, 1, r(RF + w + "_chair[facing=east,tucked=false]|" + MC + w + "_stairs[facing=east]"));
            PARASOL_TABLES[i] = m;
        }
    }

    public static Model foodTable(int variant) {
        return FOOD_TABLES[Math.floorMod(variant, FOOD_TABLES.length)];
    }

    public static Model parasolTable(int variant) {
        return PARASOL_TABLES[Math.floorMod(variant, PARASOL_TABLES.length)];
    }

    // ------------------------------------------------------------------ varios

    public static final Model ATM = col("cajero", ANDESITE_CASING, STOCK_TICKER);
    public static final Model TICKET_MACHINE = col("maquina_boletos", BRASS_CASING, STOCK_TICKER);
    public static final Model CLOCK = col("reloj", v("dark_oak_fence"), Kit.CLOCK);
    public static final Model TV = row2("tele", drawerRow("dark_oak", 2), a(Kit.TV, lamp("white")));
    public static final Model COUNTER = row2("mostrador", n(3, counter("light_gray")), a(CUTTING, PLATE, knifeBlock("oak")));
    public static final Model COFFEE_MACHINE = one("cafetera", BREWING);
    public static final Model HOSPITAL_BED = m("cama_hospital", 1, 2, 2).b(0, 0, 0, bed("white", "foot")).b(0, 0, 1, bed("white", "head"))
            .b(0, 1, 1, MIRROR);
    public static final Model SCHOOL_DESK = one("pupitre", desk("birch", false, false)).seatFront(chairModel("birch"));
    public static final Model CHALKBOARD = m("pizarron", 3, 2, 1)
            .sign(0, 1, 0, wallSign("warped"), "white", false, "", "MATEMÁTICA", "", "")
            .sign(1, 1, 0, wallSign("warped"), "white", false, "", "2 + 2 = 4", "3 x 3 = 9", "")
            .sign(2, 1, 0, wallSign("warped"), "white", false, "", "TAREA:", "pág. 25", "");
    public static final Model FUEL_PUMP = col("surtidor", TANK_LOW, TANK_HIGH);

    // ------------------------------------------------------------------ plazas

    public static final Model SLIDE = m("tobogan", 1, 2, 3)
            .b(0, 0, 0, v("smooth_quartz_slab[type=bottom]")).b(0, 0, 1, v("quartz_stairs[facing=south]"))
            .b(0, 0, 2, v("oak_fence")).b(0, 1, 2, v("smooth_quartz_slab[type=bottom]"));
    public static final Model SWINGS = m("hamacas", 3, 2, 1)
            .b(0, 0, 0, v("oak_fence")).b(2, 0, 0, v("oak_fence")).b(0, 1, 0, v("oak_fence")).b(2, 1, 0, v("oak_fence"))
            .b(1, 1, 0, v("chain[axis=y]")).b(1, 0, 0, v("oak_pressure_plate"));
    public static final Model PICNIC_TABLE = m("mesa_picnic", 2, 1, 2)
            .b(0, 0, 0, seatStairs("spruce")).b(1, 0, 0, seatStairs("spruce"))
            .b(0, 0, 1, v("spruce_slab[type=top]")).b(1, 0, 1, v("spruce_slab[type=top]"));
    public static final Model STATUE = col("estatua", v("chiseled_stone_bricks"), v("polished_andesite"), v("chiseled_quartz_block"));
    public static final Model PARKING_BOOTH = row("barrera", ANDESITE_CASING, v("end_rod[facing=east]"), v("end_rod[facing=east]"));
}
