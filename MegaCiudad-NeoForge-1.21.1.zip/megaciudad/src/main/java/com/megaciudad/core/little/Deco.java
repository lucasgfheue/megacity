package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static com.megaciudad.core.little.Kit.*;

/** Mobiliario urbano, vehículos y carteles, hechos con bloques (vanilla y de mods). */
public final class Deco {
    private Deco() {
    }

    // ------------------------------------------------------------------ materiales de carteles

    public static final Mat BASE = Mat.of("smooth_stone");
    public static final Mat BLACK = Mat.of("black_concrete");
    public static final Mat GRAY = Mat.of("gray_concrete");
    public static final Mat LGRAY = Mat.of("light_gray_concrete");
    public static final Mat WHITE = Mat.of("white_concrete");
    public static final Mat RED = Mat.of("red_concrete");
    public static final Mat YELLOW = Mat.of("yellow_concrete");
    public static final Mat GREEN = Mat.of("green_concrete");
    public static final Mat LIME = Mat.of("lime_concrete");
    public static final Mat BLUE = Mat.of("blue_concrete");
    public static final Mat LBLUE = Mat.of("light_blue_concrete");
    public static final Mat ORANGE = Mat.of("orange_concrete");
    public static final Mat BROWN = Mat.of("brown_concrete");
    public static final Mat CYAN = Mat.of("cyan_concrete");
    public static final Mat PINK = Mat.of("pink_concrete");
    public static final Mat PURPLE = Mat.of("purple_concrete");
    public static final Mat GOLD = Mat.of("gold_block");
    public static final Mat QUARTZ = Mat.of("smooth_quartz");
    public static final Mat LAMP = Mat.of("sea_lantern");
    public static final Mat SEA = Mat.of("sea_lantern");
    public static final Mat GREEN_LIT = Mat.of("verdant_froglight");
    public static final Mat RED_OFF = Mat.of("red_terracotta");
    public static final Mat GRN_OFF = Mat.of("green_terracotta");
    public static final Mat GLASS_BLACK = Mat.of("black_stained_glass");

    // ------------------------------------------------------------------ mobiliario urbano

    private static final BlockRef POLE = v("polished_andesite_wall");

    public static final Model LAMP_POST = m("farol", 1, 6, 2)
            .fill(0, 0, 1, 0, 5, 1, POLE).b(0, 5, 0, v("smooth_stone_slab[type=top]"))
            .b(0, 4, 0, cageLamp("yellow", "iron", "down"));
    public static final Model PARK_LAMP = m("farol_parque", 1, 5, 1)
            .fill(0, 0, 0, 0, 3, 0, v("dark_oak_fence")).b(0, 4, 0, cageLamp("yellow", "brass", "up"));
    public static final Model BENCH = m("banco", 2, 2, 1).b(0, 0, 0, seatStairs("spruce")).b(1, 0, 0, seatStairs("spruce"));
    public static final Model BENCH_FLOOR = m("banco_anden", 2, 2, 1).b(0, 0, 0, seatStairs("dark_oak")).b(1, 0, 0, seatStairs("dark_oak"));
    public static final Model BIN = col("papelera", RECYCLE, null);
    public static final Model BIN_FLOOR = col("papelera_anden", RECYCLE, null);
    public static final Model HYDRANT = col("hidrante", v("red_nether_brick_wall"), null);
    public static final Model MAILBOX = col("buzon", POST_BOX, null);
    public static final Model TRAFFIC_LIGHT = m("semaforo", 1, 5, 1)
            .fill(0, 0, 0, 0, 2, 0, v("polished_blackstone_wall")).b(0, 3, 0, v("verdant_froglight")).b(0, 4, 0, v("red_terracotta"));
    public static final Model BOLLARD = col("bolardo", v("polished_andesite_wall"), null);
    public static final Model BIKE_RACK = m("bicicletero", 2, 2, 1).b(0, 0, 0, bars(true, false)).b(1, 0, 0, bars(false, true));
    public static final Model PLANTER = col("macetero", hedge("azalea"), null);

    public static final Model BUS_STOP = busStop();

    private static Model busStop() {
        Model m = m("parada", 3, 3, 2);
        for (int x = 0; x < 3; x++) {
            m.b(x, 0, 1, pane("light_blue", x < 2, x > 0)).b(x, 1, 1, pane("light_blue", x < 2, x > 0));
            m.b(x, 0, 0, seatStairs("dark_oak"));
            m.b(x, 2, 0, v("smooth_stone_slab[type=bottom]")).b(x, 2, 1, v("smooth_stone_slab[type=bottom]"));
        }
        return m;
    }

    public static final Model KIOSK = m("kiosco", 2, 3, 2)
            .b(0, 0, 0, counter("green")).b(1, 0, 0, counter("green"))
            .b(0, 1, 0, CANDY_BOWL).b(1, 1, 0, chocoBox("blue"))
            .fill(0, 0, 1, 1, 1, 1, CHISELED)
            .fill(0, 2, 0, 1, 2, 1, v("dark_oak_slab[type=bottom]"));

    // ------------------------------------------------------------------ vehículos

    public static final String[] PAINTS = {"red", "blue", "white", "black", "light_gray", "gray", "cyan", "green", "yellow",
            "orange", "brown", "light_blue"};
    private static final BlockRef WHEELS = v("black_concrete"), WINDSHIELD = v("black_stained_glass");
    private static final List<Model> CARS = new ArrayList<>(), VANS = new ArrayList<>();

    static {
        for (int i = 0; i < PAINTS.length; i++) {
            BlockRef body = v(PAINTS[i] + "_concrete");
            Model c = m("auto" + i, 2, 2, 4);
            for (int x = 0; x < 2; x++) {
                c.b(x, 0, 0, WHEELS).b(x, 0, 1, body).b(x, 0, 2, body).b(x, 0, 3, WHEELS);
                c.b(x, 1, 1, WINDSHIELD).b(x, 1, 2, body);
            }
            CARS.add(c);
            Model v = m("furgon" + i, 2, 2, 5);
            for (int x = 0; x < 2; x++) {
                v.b(x, 0, 0, WHEELS).b(x, 0, 1, body).b(x, 0, 2, body).b(x, 0, 3, body).b(x, 0, 4, WHEELS);
                v.b(x, 1, 1, WINDSHIELD).b(x, 1, 2, body).b(x, 1, 3, body).b(x, 1, 4, body);
            }
            VANS.add(v);
        }
    }

    public static Model car(int variant) {
        return CARS.get(Math.floorMod(variant, CARS.size()));
    }

    public static Model van(int variant) {
        return VANS.get(Math.floorMod(variant, VANS.size()));
    }

    public static final Model AMBULANCE = ambulance();

    private static Model ambulance() {
        Model m = m("ambulancia", 2, 2, 5);
        BlockRef w = v("white_concrete"), red = v("red_concrete");
        for (int x = 0; x < 2; x++) {
            m.b(x, 0, 0, WHEELS).b(x, 0, 1, w).b(x, 0, 2, red).b(x, 0, 3, w).b(x, 0, 4, WHEELS);
            m.b(x, 1, 1, WINDSHIELD).b(x, 1, 2, w).b(x, 1, 3, w).b(x, 1, 4, w);
        }
        return m;
    }

    public static final Model FIRE_TRUCK = fireTruck();

    private static Model fireTruck() {
        Model m = m("autobomba", 2, 3, 6);
        BlockRef red = v("red_concrete");
        for (int x = 0; x < 2; x++) {
            m.b(x, 0, 0, WHEELS).b(x, 0, 5, WHEELS);
            for (int z = 1; z <= 4; z++) m.b(x, 0, z, red);
            m.b(x, 1, 0, red).b(x, 1, 1, WINDSHIELD);
            for (int z = 2; z <= 5; z++) m.b(x, 1, z, red);
            for (int z = 2; z <= 5; z++) m.b(x, 2, z, v("iron_trapdoor[facing=north,half=bottom,open=false]"));
        }
        return m;
    }

    // ------------------------------------------------------------------ carteles

    private static final ConcurrentHashMap<String, Model> SIGNS = new ConcurrentHashMap<>();

    /**
     * Cartel de pared: una fila de letreros de madera del color del fondo, con el texto en letras
     * luminosas. Los letreros quedan pegados a la fachada que está justo detrás del modelo.
     */
    public static Model wallSign(String text, Mat board, Mat letters, int px) {
        String key = text + "|" + board.block.spec + "|" + letters.block.spec + "|" + px;
        return SIGNS.computeIfAbsent(key, k -> {
            int tw = Font.width(text) * px;
            int pad = Math.max(2, px * 2);
            int wv = tw + pad * 2, hv = Font.H * px + pad;
            int sx = Math.max(1, (wv + 15) / 16), sy = Math.max(1, (hv + 15) / 16);
            Model m = new Model("cartel", sx, sy, 1);
            BlockRef sign = Kit.wallSign(board.signWood());
            String color = letters.dye();
            String[][] texts = layout(text, sx);
            int row = (sy - 1) / 2;
            for (int y = 0; y < sy; y++)
                for (int x = 0; x < sx; x++) {
                    if (y == row) m.sign(x, y, 0, sign, color, true, texts[x]);
                    else m.sign(x, y, 0, sign, color, true, "", "", "", "");
                }
            return m;
        });
    }

    private static final int LINE = 15;

    /** Reparte el texto entre n letreros (hasta 4 líneas de 15 caracteres cada uno), centrado. */
    static String[][] layout(String text, int n) {
        List<String> words = new ArrayList<>();
        for (String w : text.trim().split("\\s+")) {
            while (w.length() > LINE) {
                words.add(w.substring(0, LINE));
                w = w.substring(LINE);
            }
            if (!w.isEmpty()) words.add(w);
        }
        String[][] out = new String[n][];
        for (int i = 0; i < n; i++) out[i] = new String[]{"", "", "", ""};
        if (words.isEmpty()) return out;
        if (words.size() <= n) {
            int start = (n - words.size()) / 2;
            for (int i = 0; i < words.size(); i++) out[start + i][1] = words.get(i);
            return out;
        }
        // varias palabras por letrero, en líneas de hasta 15 caracteres
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > LINE) {
                lines.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) lines.add(cur.toString());
        int per = Math.max(1, (lines.size() + n - 1) / n);
        if (per > 4) per = 4;
        int used = Math.min(n, (lines.size() + per - 1) / per);
        int start = (n - used) / 2;
        for (int i = 0; i < lines.size() && i / per < n; i++) {
            int s = start + i / per;
            if (s >= n) break;
            int l = i % per + (per <= 2 ? 1 : 0);
            if (l < 4) out[s][l] = lines.get(i);
        }
        return out;
    }
}
