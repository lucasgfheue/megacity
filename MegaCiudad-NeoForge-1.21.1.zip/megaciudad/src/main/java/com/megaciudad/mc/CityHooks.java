package com.megaciudad.mc;

import com.megaciudad.Config;
import com.megaciudad.MegaCiudad;
import com.megaciudad.core.gen.CityGenerator;
import com.megaciudad.core.layout.CityLayout;
import com.megaciudad.mixin.StructureManagerAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.EnumSet;

/** Puntos de entrada llamados desde los mixins de ChunkGenerator. */
public final class CityHooks {
    private CityHooks() {
    }

    private static volatile CityGenerator generator;
    private static volatile long genSeed;
    private static volatile int genX, genZ;

    public static CityGenerator generator(long seed) {
        int cx = Config.CENTER_X.get(), cz = Config.CENTER_Z.get();
        CityGenerator g = generator;
        if (g == null || genSeed != seed || genX != cx || genZ != cz) {
            synchronized (CityHooks.class) {
                g = generator;
                if (g == null || genSeed != seed || genX != cx || genZ != cz) {
                    g = new CityGenerator(cx, cz, seed);
                    genSeed = seed;
                    genX = cx;
                    genZ = cz;
                    generator = g;
                    MegaCiudad.LOGGER.info("Ciudad de 2000x2000 en x[{}, {}) z[{}, {})", g.L.minX, g.L.minX + CityLayout.SIZE,
                            g.L.minZ, g.L.minZ + CityLayout.SIZE);
                }
            }
        }
        return g;
    }

    private static boolean isOverworld(WorldGenLevel level) {
        ServerLevel sl = level.getLevel();
        return sl != null && sl.dimension() == Level.OVERWORLD;
    }

    /**
     * Se ejecuta al empezar la decoración de un chunk. Devuelve true si la decoración vanilla
     * (árboles, minerales en superficie, estructuras) debe cancelarse para este chunk.
     */
    public static boolean decorate(WorldGenLevel level, ChunkAccess chunk) {
        if (!Config.ENABLED.get() || !isOverworld(level)) return false;
        CityGenerator g = generator(level.getSeed());
        ChunkPos cp = chunk.getPos();
        int kind = g.L.chunkKind(cp.x, cp.z);
        if (kind == CityLayout.CHUNK_NONE) return false;
        try {
            Terrain.shape(chunk, g.L, level.getSeed());
            if (kind == CityLayout.CHUNK_URBAN) g.generateChunk(new McSink(level, chunk), cp.x, cp.z);
            else if (kind == CityLayout.CHUNK_BUFFER) Terrain.greenBuffer(chunk, level.getSeed());
            Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.WORLD_SURFACE_WG, Heightmap.Types.OCEAN_FLOOR_WG));
        } catch (Throwable t) {
            MegaCiudad.LOGGER.error("Error generando el chunk de ciudad {}", cp, t);
        }
        return kind == CityLayout.CHUNK_URBAN || kind == CityLayout.CHUNK_BUFFER;
    }

    /** true si no deben iniciarse estructuras (aldeas, puestos, etc.) en este chunk. */
    public static boolean blockStructures(StructureManager structureManager, ChunkAccess chunk) {
        if (!Config.ENABLED.get()) return false;
        LevelAccessor la = ((StructureManagerAccessor) structureManager).megaciudad$getLevel();
        if (!(la instanceof WorldGenLevel wgl) || !isOverworld(wgl)) return false;
        CityGenerator g = generator(wgl.getSeed());
        ChunkPos cp = chunk.getPos();
        return g.L.chunkKind(cp.x, cp.z) != CityLayout.CHUNK_NONE;
    }
}
