package com.megaciudad.core;

/** RNG determinista (SplitMix64). Igual resultado en cualquier chunk que lo use. */
public final class Rng {
    private long s;

    public Rng(long seed) {
        this.s = seed;
    }

    public static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    public static long hash(long seed, long... v) {
        long h = mix(seed + 0x9E3779B97F4A7C15L);
        for (long x : v) h = mix(h ^ (x * 0x9E3779B97F4A7C15L + 0x632BE59BD9B4E019L));
        return h;
    }

    /** Valor pseudoaleatorio en [0,1) para coordenadas enteras (sin estado). */
    public static double unit(long seed, long... v) {
        return (hash(seed, v) >>> 11) * 0x1.0p-53;
    }

    public long nextLong() {
        s += 0x9E3779B97F4A7C15L;
        return mix(s);
    }

    public int nextInt(int n) {
        if (n <= 1) return 0;
        return (int) ((nextLong() >>> 33) % n);
    }

    /** Entero en [a, b] inclusive. */
    public int range(int a, int b) {
        return b <= a ? a : a + nextInt(b - a + 1);
    }

    public double nextDouble() {
        return (nextLong() >>> 11) * 0x1.0p-53;
    }

    public boolean chance(double p) {
        return nextDouble() < p;
    }

    public <T> T pick(T[] arr) {
        return arr[nextInt(arr.length)];
    }

    public int pick(int[] arr) {
        return arr[nextInt(arr.length)];
    }

    /** Elección ponderada: devuelve el índice. */
    public int weighted(double... w) {
        double t = 0;
        for (double x : w) t += x;
        double r = nextDouble() * t;
        for (int i = 0; i < w.length; i++) {
            r -= w[i];
            if (r < 0) return i;
        }
        return w.length - 1;
    }

    public Rng fork(long salt) {
        return new Rng(hash(s, salt));
    }
}
