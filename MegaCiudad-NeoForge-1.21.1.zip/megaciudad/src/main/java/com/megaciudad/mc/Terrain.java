package com.megaciudad.mc;

import com.megaciudad.core.Rng;
import com.megaciudad.core.layout.CityLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Prepara el terreno: dentro de la ciudad lo deja plano (cimientos de piedra hasta y=63 y aire
 * arriba); en el anillo exterior hace una transición suave hacia el relieve natural.
 */
final class Terrain {
    private Terrain() {
    }

    static final int FOUNDATION = 46;
    private static final BlockState STONE = Blocks.STONE.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS_BLOCK.defaultBlockState();
    private static final BlockState SAND = Blocks.SAND.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    static void shape(ChunkAccess chunk, CityLayout L, long seed) {
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int maxY = chunk.getMaxBuildHeight() - 1;
        for (int lz = 0; lz < 16; lz++)
            for (int lx = 0; lx < 16; lx++) {
                int x = x0 + lx, z = z0 + lz;
                int top = Math.max(chunk.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z), chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z));
                top = Math.min(maxY, top);
                int d = L.distOutside(x, z);
                if (d == 0) {
                    for (int y = top; y >= CityLayout.GROUND; y--) {
                        p.set(x, y, z);
                        if (!chunk.getBlockState(p).isAir()) chunk.setBlockState(p, AIR, false);
                    }
                    for (int y = FOUNDATION; y < CityLayout.ROAD_Y; y++) {
                        p.set(x, y, z);
                        BlockState s = chunk.getBlockState(p);
                        if (s.isAir() || !s.getFluidState().isEmpty() || s.canBeReplaced() || s.getBlock() instanceof FallingBlock)
                            chunk.setBlockState(p, STONE, false);
                    }
                    continue;
                }
                if (d > CityLayout.BLEND) continue;
                int natural = chunk.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
                double t = Math.min(1.0, (d - 1) / (double) CityLayout.BLEND);
                double s = t * t * (3 - 2 * t);
                // pequeña variación para que el borde no sea perfectamente recto
                s = Math.max(0, Math.min(1, s + (Rng.unit(seed, 77, x / 4, z / 4) - 0.5) * 0.08 * t));
                int target = (int) Math.round(CityLayout.GROUND + (natural - CityLayout.GROUND) * s);
                if (natural > target) {
                    for (int y = Math.max(top, natural); y > target; y--) {
                        p.set(x, y, z);
                        if (!chunk.getBlockState(p).isAir()) chunk.setBlockState(p, AIR, false);
                    }
                } else if (natural < target) {
                    for (int y = Math.max(natural + 1, FOUNDATION); y < target; y++) {
                        p.set(x, y, z);
                        BlockState bs = chunk.getBlockState(p);
                        if (bs.isAir() || !bs.getFluidState().isEmpty() || bs.canBeReplaced()) chunk.setBlockState(p, target - y > 3 ? STONE : DIRT, false);
                    }
                }
                if (natural != target) {
                    boolean dry = target >= 62;
                    p.set(x, target, z);
                    chunk.setBlockState(p, dry ? GRASS : SAND, false);
                    for (int y = target - 1; y >= target - 3; y--) {
                        p.set(x, y, z);
                        BlockState bs = chunk.getBlockState(p);
                        if (bs.isAir() || !bs.getFluidState().isEmpty() || bs.canBeReplaced() || bs.getBlock() == Blocks.STONE)
                            chunk.setBlockState(p, dry ? DIRT : SAND, false);
                    }
                    if (dry) {
                        // quitar agua que haya quedado por encima del nuevo suelo
                        for (int y = target + 1; y <= 62; y++) {
                            p.set(x, y, z);
                            if (!chunk.getBlockState(p).getFluidState().isEmpty()) chunk.setBlockState(p, AIR, false);
                        }
                    }
                }
            }
    }

    /** Pasto y flores en el anillo inmediato a la ciudad (allí no corre la decoración vanilla). */
    static void greenBuffer(ChunkAccess chunk, long seed) {
        int x0 = chunk.getPos().getMinBlockX(), z0 = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockState grass = Blocks.SHORT_GRASS.defaultBlockState();
        BlockState[] flowers = {Blocks.DANDELION.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
                Blocks.OXEYE_DAISY.defaultBlockState(), Blocks.CORNFLOWER.defaultBlockState()};
        for (int lz = 0; lz < 16; lz++)
            for (int lx = 0; lx < 16; lx++) {
                int x = x0 + lx, z = z0 + lz;
                int top = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                p.set(x, top, z);
                if (chunk.getBlockState(p).getBlock() != Blocks.GRASS_BLOCK) continue;
                double u = Rng.unit(seed, 91, x, z);
                p.set(x, top + 1, z);
                if (!chunk.getBlockState(p).isAir()) continue;
                if (u < 0.18) chunk.setBlockState(p, grass, false);
                else if (u < 0.21) chunk.setBlockState(p, flowers[(int) (u * 1000) % flowers.length], false);
            }
    }
}
