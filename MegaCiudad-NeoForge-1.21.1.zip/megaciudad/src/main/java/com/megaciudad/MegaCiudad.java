package com.megaciudad;

import com.megaciudad.core.gen.CityGenerator;
import com.megaciudad.mc.CityHooks;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.LevelEvent;
import org.slf4j.Logger;

/**
 * MegaCiudad: genera una ciudad de 2000x2000 bloques en el mundo normal, con edificios de todo tipo
 * y decoraciones hechas con mini-bloques de LittleTiles. No registra ningún ítem ni bloque propio:
 * todo se genera con bloques vanilla y bloques de LittleTiles, así que nada aparece en el inventario.
 */
@Mod(MegaCiudad.MODID)
public final class MegaCiudad {
    public static final String MODID = "megaciudad";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MegaCiudad(IEventBus modEventBus, ModContainer modContainer) {
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        NeoForge.EVENT_BUS.addListener(MegaCiudad::onCreateSpawn);
        LOGGER.info("MegaCiudad cargado: la ciudad se genera al crear un mundo nuevo");
    }

    /** Hace aparecer a los jugadores en la plaza central de la ciudad. */
    private static void onCreateSpawn(LevelEvent.CreateSpawnPosition event) {
        if (!Config.ENABLED.get() || !Config.SPAWN_IN_PLAZA.get()) return;
        if (!(event.getLevel() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;
        CityGenerator g = CityHooks.generator(level.getSeed());
        int[] sp = g.spawnPoint();
        level.setDefaultSpawnPos(new BlockPos(sp[0], sp[1], sp[2]), 0.0F);
        event.setCanceled(true);
        LOGGER.info("Punto de aparición en la plaza central: {} {} {}", sp[0], sp[1], sp[2]);
    }
}
