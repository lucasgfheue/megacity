package com.megaciudad.core.gen;

import com.megaciudad.core.B;
import com.megaciudad.core.BlockRef;
import com.megaciudad.core.Canvas;
import com.megaciudad.core.Rng;
import com.megaciudad.core.layout.AxisLayout;
import com.megaciudad.core.layout.CityLayout;
import com.megaciudad.core.little.Deco;
import com.megaciudad.core.little.Model;

import static com.megaciudad.core.layout.AxisLayout.*;

/** Pavimento, cruces, rotonda central y mobiliario urbano. */
public final class Streets {
    private final CityLayout L;
    private static final AxisLayout A = CityLayout.A;
    private static final int RY = CityLayout.ROAD_Y;

    public Streets(CityLayout l) {
        this.L = l;
    }

    private BlockRef asphalt(int x, int z) {
        double u = Rng.unit(L.seed, 31, x, z);
        if (u < 0.0025) return B.ASPHALT_DARK;
        if (u < 0.03) return B.ASPHALT_WORN;
        return B.ASPHALT;
    }

    // ------------------------------------------------------------------ pavimento

    public void pave(Canvas c) {
        for (int z = c.z0; z <= c.z1; z++)
            for (int x = c.x0; x <= c.x1; x++) {
                if (!L.inCity(x, z)) continue;
                int ox = x - L.minX, oz = z - L.minZ;
                boolean lx = A.isLot(ox), lz = A.isLot(oz);
                if (lx && lz) {
                    c.set(x, RY, z, B.DIRT);
                    c.set(x, RY + 1, z, B.GRASS);
                } else if (!lx && lz) {
                    int k = A.roadAt(ox);
                    segment(c, x, z, A.roadKind[k], A.posAt(ox), oz);
                } else if (lx) {
                    int k = A.roadAt(oz);
                    segment(c, x, z, A.roadKind[k], A.posAt(oz), ox);
                } else {
                    intersection(c, x, z, A.roadAt(ox), A.posAt(ox), A.roadAt(oz), A.posAt(oz));
                }
            }
    }

    private void sidewalk(Canvas c, int x, int z) {
        c.set(x, RY, z, B.SIDEWALK_BASE);
        c.set(x, RY + 1, z, B.SIDEWALK);
    }

    private void segment(Canvas c, int x, int z, int kind, int p, int along) {
        switch (section(kind, p)) {
            case SW -> sidewalk(c, x, z);
            case DIV -> c.set(x, RY, z, Math.floorMod(along, 6) < 3 ? B.MARK_WHITE : asphalt(x, z));
            case CENTER -> c.set(x, RY, z, Math.floorMod(along, 6) < 3 ? B.MARK_YELLOW : asphalt(x, z));
            case MEDIAN -> {
                boolean edge = p == 10 || p == (kind == CENTRAL ? 13 : 12);
                c.set(x, RY, z, edge ? B.SIDEWALK_BASE : B.DIRT);
                c.set(x, RY + 1, z, edge ? B.CURB : B.GRASS);
            }
            default -> c.set(x, RY, z, asphalt(x, z));
        }
    }

    private void intersection(Canvas c, int x, int z, int kx, int px, int kz, int pz) {
        int sx = section(A.roadKind[kx], px), sz = section(A.roadKind[kz], pz);
        if (sx == SW && sz == SW) {
            sidewalk(c, x, z);
            return;
        }
        if (sx == SW) {
            c.set(x, RY, z, (pz & 1) == 1 ? B.MARK_WHITE : asphalt(x, z));
            return;
        }
        if (sz == SW) {
            c.set(x, RY, z, (px & 1) == 1 ? B.MARK_WHITE : asphalt(x, z));
            return;
        }
        if (kx == 12 && kz == 12) {
            double dx = x - (L.roadX0(12) + 11.5), dz = z - (L.roadZ0(12) + 11.5);
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d <= 5.6) {
                c.set(x, RY, z, B.STONE_BRICKS);
                c.set(x, RY + 1, z, d > 4.8 ? B.of("stone_brick_slab[type=bottom,waterlogged=false]") : B.GRASS);
                return;
            }
            if (d <= 6.6) {
                c.set(x, RY, z, B.MARK_WHITE);
                return;
            }
        }
        c.set(x, RY, z, asphalt(x, z));
    }

    // ------------------------------------------------------------------ mobiliario

    public void furnish(Canvas c) {
        int cx0 = c.x0 - L.minX, cx1 = c.x1 - L.minX, cz0 = c.z0 - L.minZ, cz1 = c.z1 - L.minZ;
        if (cx1 < 0 || cz1 < 0 || cx0 >= SIZE || cz0 >= SIZE) return;
        for (int k = 0; k < ROADS; k++) {
            int rx0 = A.roadStart[k], rx1 = rx0 + A.roadWidth[k] - 1;
            // calles N-S (franja en X)
            if (rx1 >= cx0 - 2 && rx0 <= cx1 + 2)
                for (int j = 0; j < LOTS; j++) {
                    int a0 = A.lotStart[j], a1 = a0 + A.lotSize[j] - 1;
                    if (a1 >= cz0 - 6 && a0 <= cz1 + 6) segmentFurniture(c, true, k, j);
                }
            // calles E-O (franja en Z)
            if (rx1 >= cz0 - 2 && rx0 <= cz1 + 2)
                for (int i = 0; i < LOTS; i++) {
                    int a0 = A.lotStart[i], a1 = a0 + A.lotSize[i] - 1;
                    if (a1 >= cx0 - 6 && a0 <= cx1 + 6) segmentFurniture(c, false, k, i);
                }
        }
        for (int kx = 0; kx < ROADS; kx++) {
            int x0 = A.roadStart[kx], x1 = x0 + A.roadWidth[kx] - 1;
            if (x1 < cx0 - 2 || x0 > cx1 + 2) continue;
            for (int kz = 0; kz < ROADS; kz++) {
                int z0 = A.roadStart[kz], z1 = z0 + A.roadWidth[kz] - 1;
                if (z1 < cz0 - 2 || z0 > cz1 + 2) continue;
                intersectionFurniture(c, kx, kz);
            }
        }
    }

    /** Rotación para que el frente del modelo mire hacia la calzada desde el lado s de la vereda. */
    private static int faceRot(boolean ns, int s) {
        return ns ? (s == 0 ? 1 : 3) : (s == 0 ? 2 : 0);
    }

    /**
     * Coloca un modelo en la vereda. pBack = posición transversal de la fila trasera del modelo,
     * depth = filas hacia la calzada, a = coordenada de mundo mínima a lo largo de la calle.
     */
    private void place(Canvas c, boolean ns, int k, int s, int pBack, int a, Model m, int y) {
        int depth = m.sz;
        int pmin = s == 0 ? pBack : pBack - depth + 1;
        int rot = faceRot(ns, s);
        if (ns) c.model(m, rot, L.roadX0(k) + pmin, y, a);
        else c.model(m, rot, a, y, L.roadZ0(k) + pmin);
    }

    private void placeVehicle(Canvas c, boolean ns, int k, int pMin, int a, Model m, int rot) {
        if (ns) c.model(m, rot, L.roadX0(k) + pMin, RY + 1, a);
        else c.model(m, rot, a, RY + 1, L.roadZ0(k) + pMin);
    }

    private void segmentFurniture(Canvas c, boolean ns, int k, int lot) {
        int kind = A.roadKind[k], w = A.roadWidth[k];
        int len = A.lotSize[lot];
        int base = ns ? L.lotZ0(lot) : L.lotX0(lot);
        int i = ns ? (k > 0 ? Math.min(k - 1, LOTS - 1) : 0) : lot;
        int j = ns ? lot : (k > 0 ? Math.min(k - 1, LOTS - 1) : 0);
        int dist = L.district(i, j);
        Rng r = new Rng(Rng.hash(L.seed, ns ? 0x51 : 0x52, k, lot));
        boolean metro = (!ns && k == CityLayout.METRO_EW_ROAD) || (ns && k == CityLayout.METRO_NS_ROAD);
        boolean outerEdge = (k == 0 || k == ROADS - 1);
        for (int s = 0; s < 2; s++) {
            if (outerEdge && ((k == 0 && s == 0) || (k == ROADS - 1 && s == 1))) {
                // vereda exterior del bulevar: solo faroles
                for (int a = 8; a < len - 3; a += 16) lamp(c, ns, k, s, base + a, w);
                continue;
            }
            int curb = s == 0 ? 2 : w - 3, inner = s == 0 ? 0 : w - 1, mid = s == 0 ? 1 : w - 2;
            int[] lamps = s == 0 ? new int[]{4, 20, 36, 52} : new int[]{12, 28, 44, 60};
            int[] trees = s == 0 ? new int[]{12, 28, 44, 60} : new int[]{4, 20, 36, 52};
            boolean busStop = kind != STREET && r.chance(0.55);
            for (int a : lamps) {
                if (a > len - 3) continue;
                lamp(c, ns, k, s, base + a, w);
                if (r.chance(0.55)) place(c, ns, k, s, curb, base + a + 1, Deco.BIN, RY + 1);
            }
            double treeP = dist == CityLayout.CORE ? 0.45 : 0.85;
            for (int a : trees) {
                if (a > len - 3) continue;
                if (busStop && a >= 38 && a <= 42) continue;
                if (r.chance(treeP)) streetTree(c, ns, k, curb, base + a, r.nextLong());
                else if (dist <= CityLayout.MIDTOWN && r.chance(0.6)) place(c, ns, k, s, curb, base + a, Deco.PLANTER, RY + 1);
            }
            if (busStop) place(c, ns, k, s, mid, base + 39, Deco.BUS_STOP, RY + 1);
            if (r.chance(0.4)) place(c, ns, k, s, curb, base + 31, Deco.HYDRANT, RY + 1);
            double benchP = dist <= CityLayout.MIDTOWN ? 0.4 : 0.22;
            for (int a : new int[]{7, 23, 55}) if (a + 1 < len - 2 && r.chance(benchP)) place(c, ns, k, s, inner, base + a, Deco.BENCH, RY + 1);
            if (r.chance(0.22)) place(c, ns, k, s, inner, base + 17, Deco.MAILBOX, RY + 1);
            if (dist <= CityLayout.MIDTOWN && r.chance(0.18)) place(c, ns, k, s, inner, base + 47, Deco.BIKE_RACK, RY + 1);
            if (dist <= CityLayout.MIDTOWN && r.chance(0.1)) place(c, ns, k, s, inner, base + 58, Deco.KIOSK, RY + 1);
            // autos estacionados junto al cordón
            if (!busStop || r.chance(0.3)) {
                for (int a : new int[]{14, 47}) {
                    if (r.chance(dist == CityLayout.OUTER ? 0.18 : 0.3) && a + 4 < len - 2) {
                        int pMin = s == 0 ? 3 : w - 5;
                        int rot = ns ? (s == 0 ? 2 : 0) : (s == 0 ? 3 : 1);
                        Model car = r.chance(0.12) ? Deco.van(r.nextInt(4)) : Deco.car(r.chance(0.1) ? 100 : r.nextInt(30));
                        placeVehicle(c, ns, k, pMin, base + a, car, rot);
                    }
                }
            }
        }
        // algún vehículo circulando por el carril interno
        {
            if (r.chance(0.12)) {
                int pMin = kind == STREET ? 7 : 13;
                int rot = ns ? 0 : 1;
                placeVehicle(c, ns, k, pMin, base + r.range(8, len - 12), Deco.car(r.chance(0.15) ? 100 : r.nextInt(30)), rot);
            }
        }
    }

    private void lamp(Canvas c, boolean ns, int k, int s, int a, int w) {
        place(c, ns, k, s, s == 0 ? 2 : w - 3, a, Deco.LAMP_POST, RY + 1);
    }

    private void streetTree(Canvas c, boolean ns, int k, int p, int a, long seed) {
        int x = ns ? L.roadX0(k) + p : a, z = ns ? a : L.roadZ0(k) + p;
        if (!c.overlaps(x - 3, z - 3, x + 3, z + 3)) return;
        c.set(x, RY, z, B.DIRT);
        c.set(x, RY + 1, z, B.of("rooted_dirt"));
        Trees.street(c, x, RY + 2, z, seed);
    }

    private void intersectionFurniture(Canvas c, int kx, int kz) {
        int x0 = L.roadX0(kx), z0 = L.roadZ0(kz), wx = A.roadWidth[kx], wz = A.roadWidth[kz];
        if (!c.overlaps(x0 - 1, z0 - 1, x0 + wx, z0 + wz)) return;
        boolean big = A.roadKind[kx] != STREET || A.roadKind[kz] != STREET;
        int y = RY + 1;
        // las esquinas del perímetro exterior no tienen vereda completa
        boolean[] corner = {
                !(kx == 0 || kz == 0), !(kx == ROADS - 1 || kz == 0), !(kx == ROADS - 1 || kz == ROADS - 1), !(kx == 0 || kz == ROADS - 1)};
        if (big) {
            if (corner[0]) c.model(Deco.TRAFFIC_LIGHT, 0, x0 + 2, y, z0 + 2);
            if (corner[1]) c.model(TRAFFIC_LIGHT_B, 1, x0 + wx - 3, y, z0 + 2);
            if (corner[2]) c.model(Deco.TRAFFIC_LIGHT, 2, x0 + wx - 3, y, z0 + wz - 3);
            if (corner[3]) c.model(TRAFFIC_LIGHT_B, 3, x0 + 2, y, z0 + wz - 3);
        } else {
            if (corner[0]) c.model(STOP, 0, x0 + 2, y, z0 + 2);
            if (corner[2]) c.model(STOP, 2, x0 + wx - 3, y, z0 + wz - 3);
        }
        if (corner[1]) {
            String a = CityLayout.nsName(kx), b = CityLayout.ewName(kz);
            c.sign(x0 + wx - 1, y, z0, B.of("dark_oak_sign[rotation=2,waterlogged=false]"),
                    new String[]{"", a, b, ""}, "white", false);
        }
        if (kx == 12 && kz == 12) monument(c, x0 + 12, z0 + 12);
    }

    /** Semáforo con los colores invertidos (para las esquinas giradas 90°). */
    private static final Model TRAFFIC_LIGHT_B = new Model("semaforo_b", 1, 5, 1)
            .fill(0, 0, 0, 0, 2, 0, B.of("polished_blackstone_wall"))
            .b(0, 3, 0, B.of("green_terracotta")).b(0, 4, 0, B.of("shroomlight"));

    private static final Model STOP = new Model("pare", 1, 4, 1)
            .fill(0, 0, 0, 0, 2, 0, B.of("polished_andesite_wall"))
            .sign(0, 3, 0, B.of("mangrove_sign[rotation=8]"), "white", true, "", "PARE", "", "");

    /** Obelisco de la rotonda central. */
    private void monument(Canvas c, int cx, int cz) {
        int y = RY + 2;
        c.fill(cx - 2, y, cz - 2, cx + 1, y, cz + 1, B.STONE_BRICKS);
        c.fill(cx - 1, y + 1, cz - 1, cx, y + 2, cz, B.CHISELED_STONE);
        c.fill(cx - 1, y + 3, cz - 1, cx, y + 22, cz, B.SMOOTH_QUARTZ);
        c.fill(cx - 1, y + 23, cz - 1, cx, y + 23, cz, B.QUARTZ_BRICKS);
        c.set(cx - 1, y + 24, cz - 1, B.GOLD_BLOCK);
        c.set(cx, y + 24, cz, B.GOLD_BLOCK);
        c.set(cx - 1, y + 24, cz, B.GOLD_BLOCK);
        c.set(cx, y + 24, cz - 1, B.GOLD_BLOCK);
        c.set(cx, y + 25, cz, B.LIGHT15);
        for (int[] d : new int[][]{{-4, 0}, {3, -1}, {0, 3}, {-1, -4}, {-3, 3}, {2, 2}, {3, -3}, {-4, -3}}) {
            BlockRef f = B.FLOWERS[Math.floorMod(d[0] * 7 + d[1] * 3, B.FLOWERS.length)];
            c.set(cx + d[0], y, cz + d[1], f);
        }
        c.set(cx - 3, y, cz - 2, B.LIGHT12);
        c.set(cx + 2, y, cz + 1, B.LIGHT12);
    }
}
