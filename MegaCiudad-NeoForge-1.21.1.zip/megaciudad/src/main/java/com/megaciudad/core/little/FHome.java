package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Muebles de casas y departamentos (Refurbished, Farmer's Delight, Extra Delight, Create y vanilla). */
public final class FHome {
    private FHome() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    // ------------------------------------------------------------------ living

    public static final Model SOFA_L = reg(sofaL());

    private static Model sofaL() {
        Model m = m("sofa_l", 3, 1, 2);
        BlockRef[] s = sofaRow("light_gray", 3);
        for (int x = 0; x < 3; x++) m.b(x, 0, 1, s[x]);
        return m.b(0, 0, 0, stool("light_gray"));
    }

    public static final Model SOFA_MOD = reg(row("sofa_moderno", sofaRow("white", 2)));
    public static final Model CHESTERFIELD = reg(row("chesterfield", sofaRow("brown", 2)));
    public static final Model WINGBACK = reg(one("sillon_orejero", sofa("green", "default")));
    public static final Model RECLINER = reg(one("reclinable", sofa("black", "default")));
    public static final Model BEANBAG = reg(one("puff", seat("orange")));
    public static final Model OTTOMAN = reg(one("otomana", stool("brown")));
    public static final Model COFFEE_WOOD = reg(row("mesa_ratona", n(2, cloth("brown"))));
    public static final Model SIDE_LAMP = reg(one("velador", lamp("white")));
    public static final Model FLOOR_LAMP = reg(col("lampara_pie", v("dark_oak_fence"), lamp("yellow")));
    public static final Model ARC_LAMP = reg(m("lampara_arco", 2, 2, 1).b(0, 0, 0, v("dark_oak_fence")).b(0, 1, 0, lamp("white")));
    public static final Model TV_UNIT = reg(row2("mueble_tv", drawerRow("dark_oak", 3), a(lamp("gray"), TV, potted("fern"))));
    public static final Model BOOKCASE = reg(col("biblioteca", BOOKS, BOOKS));
    public static final Model BOOKCASE_WIDE = reg(m("biblioteca_ancha", 2, 2, 1).fill(0, 0, 0, 1, 1, 0, BOOKS));
    public static final Model CUBE_SHELF = reg(m("estante_cubos", 2, 2, 1).fill(0, 0, 0, 1, 1, 0, CHISELED));
    public static final Model FIREPLACE = reg(row2("chimenea", n(2, v("campfire[lit=true,facing=north]")),
            n(2, v("brick_stairs[facing=south,half=top]"))));
    public static final Model PIANO = reg(row2("piano", n(2, NOTE), n(2, v("polished_blackstone_slab[type=bottom]"))));
    public static final Model GRAND_PIANO = reg(m("piano_cola", 2, 1, 2).b(0, 0, 0, NOTE).b(1, 0, 0, NOTE)
            .b(0, 0, 1, v("polished_blackstone_slab[type=top]")).b(1, 0, 1, v("polished_blackstone_slab[type=top]")));
    public static final Model AQUARIUM = reg(row2("acuario", drawerRow("dark_oak", 2), n(2, v("light_blue_stained_glass"))));
    public static final Model GUITAR = reg(one("guitarra", NOTE));
    public static final Model RECORD_PLAYER = reg(one("tocadiscos", JUKEBOX));
    public static final Model SPEAKER = reg(col("parlante", NOTE, NOTE));
    public static final Model RUG_ROUND = reg(m("alfombra_redonda", 2, 1, 2).fill(0, 0, 0, 1, 0, 1, gingham("red")));
    public static final Model RUG_RECT = reg(m("alfombra", 3, 1, 2).fill(0, 0, 0, 2, 0, 1, v("cyan_carpet")));
    public static final Model PAINT_LAND = reg(row("cuadro_paisaje", banner("green"), banner("light_blue")));
    public static final Model PAINT_ABS = reg(one("cuadro_abstracto", banner("orange")));
    public static final Model PAINT_FLOWERS = reg(one("cuadro_flores", banner("pink")));
    public static final Model MIRROR_ROUND = reg(one("espejo", MIRROR));
    public static final Model WALL_CLOCK = reg(one("reloj_pared", CLOCK));
    public static final Model WALL_SHELF = reg(row("repisa", n(2, v("spruce_trapdoor[facing=north,half=top,open=false]"))));
    public static final Model PENDANT = reg(one("colgante", CEIL_LIGHT));
    public static final Model CHANDELIER = reg(one("arana", cageLamp("yellow", "brass", "down")));
    public static final Model CEILING_FAN = reg(m("ventilador_techo", 2, 1, 2).b(0, 0, 0, fan("oak")));
    public static final Model VASE_FLOWERS = reg(one("florero", potted("allium")));
    public static final Model MONSTERA = reg(col("monstera", potted("fern"), leaves("jungle")));
    public static final Model CACTUS = reg(one("cactus", potted("cactus")));
    public static final Model PALM = reg(col("palmera", potted("jungle_sapling"), leaves("jungle")));
    public static final Model SNAKE_PLANT = reg(one("sansevieria", potted("bamboo")));
    public static final Model BONSAI = reg(one("bonsai", potted("cherry_sapling")));
    public static final Model HANGING_PLANT = reg(one("planta_colgante", v("spore_blossom")));
    public static final Model FICUS = reg(col("ficus", potted("azalea_bush"), leaves("azalea")));
    public static final Model COAT_RACK = reg(col("perchero_pie", v("spruce_fence"), standingBanner("brown")));
    public static final Model ENTRY_CONSOLE = reg(one("consola", drawer("oak", false, false)));
    public static final Model GLOBE = reg(one("globo", v("decorated_pot")));

    // ------------------------------------------------------------------ cocina y comedor

    public static final Model KSINK = reg(col("pileta_cocina", ksink("white"), spiceRack("oak")));
    public static final Model KCOUNTER = reg(col("mesada", counter("white"), board("oak")));
    public static final Model KSPICE = reg(col("mesada_especias", kdrawer("white"), knifeBlock("oak")));
    public static final Model STOVE = reg(col("cocina", STOVE_L, POT));
    public static final Model FRIDGE_HOME = reg(col("heladera", FREEZER_L, FRIDGE_L));
    public static final Model FRIDGE_SXS = reg(row2("heladera_doble", n(2, FREEZER_L), n(2, FRIDGE_L)));
    public static final Model DISHWASHER = reg(col("lavavajillas", kdrawer("white"), PLATE));
    public static final Model MICROWAVE = reg(col("microondas", counter("white"), MICRO_L));
    public static final Model BREAKFAST = reg(col("desayuno", counter("white"), TOASTER));
    public static final Model WALL_CABINET = reg(one("alacena", wallCab("white")));
    public static final Model HOOD = reg(one("campana", HOOD_L));
    public static final Model DINING_TABLE = reg(tableGrid("mesa_comedor", "oak", 2, 1).chairs(chairModel("oak")));
    public static final Model DINING_SET = reg(tableGrid("juego_comedor", "dark_oak", 2, 2).chairs(chairModel("dark_oak")));
    public static final Model ROUND_TABLE = reg(m("mesa_redonda", 2, 1, 2).fill(0, 0, 0, 1, 0, 1, cloth("white")).chairs(chairModel("birch")));
    public static final Model CHAIR = reg(one("silla_madera", chair("oak")));
    public static final Model ISLAND = reg(row("isla_cocina", ksink("white"), counter("white")));
    public static final Model BAR_STOOL = reg(one("banqueta", stool("black")));
    public static final Model WASHER = reg(one("lavarropas", v("dropper[facing=north]")));
    public static final Model DRYER = reg(one("secarropas", v("dispenser[facing=north]")));
    public static final Model PANTRY = reg(col("despensa", cabinet("oak", "left"), cabinet("oak", "left")));
    public static final Model HIGH_CHAIR = reg(one("silla_bebe", stool("white")));
    public static final Model PEDAL_BIN = reg(one("tacho_pedal", RECYCLE));

    // ------------------------------------------------------------------ dormitorios

    private static Model beds(String name, String color, int w, int h) {
        Model m = m(name, w, h, 2);
        for (int x = 0; x < w; x++) m.b(x, 0, 0, bed(color, "foot")).b(x, 0, 1, bed(color, "head"));
        return m;
    }

    public static final Model BED_DOUBLE = reg(beds("cama_doble", "light_blue", 2, 1));
    public static final Model BED_MODERN = reg(beds("cama_moderna", "gray", 2, 1));
    public static final Model BED_CANOPY = reg(beds("cama_dosel", "red", 2, 3).fill(0, 2, 0, 1, 2, 1, v("birch_slab[type=bottom]")));
    public static final Model BED_SINGLE = reg(beds("cama_simple", "green", 1, 1));
    public static final Model BUNK = reg(beds("cucheta", "blue", 1, 2).b(0, 1, 0, bed("yellow", "foot")).b(0, 1, 1, bed("yellow", "head")));
    public static final Model CAR_BED = reg(beds("cama_auto", "red", 1, 1));
    public static final Model CRIB = reg(one("cuna", gingham("light_blue")));
    public static final Model NIGHTSTAND = reg(col("mesa_luz", drawer("oak", false, false), lamp("white")));
    public static final Model WARDROBE = reg(row2("ropero", a(cabinet("oak", "left"), cabinet("oak", "right")),
            a(cabinet("oak", "left"), cabinet("oak", "right"))));
    public static final Model WARDROBE_MIRROR = reg(row2("ropero_espejo", a(cabinet("birch", "left"), cabinet("birch", "right")),
            a(cabinet("birch", "left"), MIRROR)));
    public static final Model DRESSER = reg(row("comoda", drawerRow("birch", 2)));
    public static final Model VANITY = reg(col("tocador", drawer("birch", false, false), MIRROR));
    public static final Model DESK_HOME = reg(row2("escritorio_casa", deskRow("oak", 2), a(COMPUTER, lamp("white"))));
    public static final Model GAMING_DESK = reg(row2("escritorio_gamer", deskRow("dark_oak", 2), a(COMPUTER, TV)));
    public static final Model GAMING_CHAIR = reg(one("silla_gamer", seat("red")));
    public static final Model MIRROR_FLOOR = reg(col("espejo_pie", MIRROR, MIRROR));
    public static final Model TOY_BOX = reg(one("baul_juguetes", v("red_shulker_box[facing=up]")));
    public static final Model TEDDY = reg(one("peluche", seat("brown")));
    public static final Model HAMPER = reg(one("cesto_ropa", BASKET));
    public static final Model ROCKING_HORSE = reg(one("caballito", v("spruce_stairs[facing=east]")));

    // ------------------------------------------------------------------ baños

    public static final Model TOILET = reg(one("inodoro", toilet("white")));
    public static final Model BATH_SINK = reg(col("lavatorio", basin("white"), MIRROR));
    public static final Model VANITY_DOUBLE = reg(row2("lavatorio_doble", n(2, basin("white")), n(2, MIRROR)));
    public static final Model BATHTUB = reg(m("banera", 1, 1, 2).b(0, 0, 0, bath("white")[0]).b(0, 0, 1, bath("white")[1]));
    public static final Model SHOWER = reg(col("ducha", v("smooth_quartz_slab[type=bottom]"), v("lightning_rod[facing=down]")));
    public static final Model TOWEL_RACK = reg(one("toallero", banner("white")));
    public static final Model MED_MIRROR = reg(one("botiquin_espejo", MIRROR));
}
