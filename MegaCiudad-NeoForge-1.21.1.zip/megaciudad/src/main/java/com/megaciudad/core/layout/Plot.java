package com.megaciudad.core.layout;

/** Parcela dentro de una manzana, con el tipo de edificio y su orientación hacia la calle. */
public final class Plot {
    // Tipos de edificio
    public static final int TOWER = 0, RESI_TOWER = 1, HOTEL = 2, APARTMENTS = 3, TOWNHOUSE = 4, HOUSE = 5, SHOPS = 6,
            SUPERMARKET = 7, MALL = 8, CENTRAL_STATION = 9, HOSPITAL = 10, SCHOOL = 11, FIRE_STATION = 12, POLICE = 13,
            GAS_STATION = 14, PARKING_GARAGE = 15, PARKING_LOT = 16, PARK = 17, PLAZA = 18, WAREHOUSE = 19, FACTORY = 20,
            STADIUM = 21, CITY_HALL = 22, CATHEDRAL = 23, CENTRAL_PLAZA = 24, COURTYARD = 25, OFFICE = 26, LANDMARK = 27;

    public static final String[] NAMES = {"torre", "torre residencial", "hotel", "apartamentos", "casa adosada", "casa",
            "locales", "supermercado", "shopping", "estación central", "hospital", "escuela", "bomberos", "policía",
            "estación de servicio", "garaje", "estacionamiento", "parque", "plaza", "depósito", "fábrica", "estadio",
            "intendencia", "catedral", "plaza central", "patio", "oficinas", "torre central"};

    public final int x0, z0, x1, z1;
    public final int rot;
    public final int type;
    public final long seed;
    public final int district;
    public final int lotI, lotJ;

    public Plot(int x0, int z0, int x1, int z1, int rot, int type, long seed, int district, int lotI, int lotJ) {
        this.x0 = Math.min(x0, x1);
        this.z0 = Math.min(z0, z1);
        this.x1 = Math.max(x0, x1);
        this.z1 = Math.max(z0, z1);
        this.rot = rot & 3;
        this.type = type;
        this.seed = seed;
        this.district = district;
        this.lotI = lotI;
        this.lotJ = lotJ;
    }

    public int width() {
        return x1 - x0 + 1;
    }

    public int depth() {
        return z1 - z0 + 1;
    }
}
