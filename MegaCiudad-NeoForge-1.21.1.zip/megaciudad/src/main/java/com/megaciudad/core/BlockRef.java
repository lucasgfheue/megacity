package com.megaciudad.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Referencia inmutable e internada a un estado de bloque, escrita como en los comandos:
 * "minecraft:oak_stairs[facing=north,half=top]". No depende de Minecraft: el adaptador
 * la resuelve a un BlockState real (y la guarda en {@link #mcState}).
 */
public final class BlockRef {
    private static final ConcurrentHashMap<String, BlockRef> CACHE = new ConcurrentHashMap<>();
    private static final List<BlockRef> ALL = new ArrayList<>();

    public final String id;
    public final String[] keys;
    public final String[] values;
    public final String spec;
    public final int index;
    public final boolean air;
    /** Bloques cuya forma depende de los vecinos (vallas, paneles, muros, escaleras...). */
    public final boolean connectable;
    /** Alternativa si el bloque no existe (mod no instalado); null si no hay. */
    public final BlockRef fallback;
    private final BlockRef[] rotations = new BlockRef[4];
    /** Cache del BlockState de Minecraft (lo usa solo el adaptador). */
    public volatile Object mcState;

    private BlockRef(String id, String[] keys, String[] values, String spec, int index, BlockRef fallback) {
        this.id = id;
        this.fallback = fallback;
        this.keys = keys;
        this.values = values;
        this.spec = spec;
        this.index = index;
        String path = id.substring(id.indexOf(':') + 1);
        this.air = path.equals("air") || path.equals("cave_air") || path.equals("void_air");
        boolean wall = path.endsWith("_wall") && !path.contains("sign") && !path.contains("torch")
                && !path.contains("banner") && !path.contains("skull") && !path.contains("head") && !path.contains("fan");
        boolean vanilla = id.startsWith("minecraft:");
        boolean furniture = !vanilla && (path.endsWith("_sofa") || path.endsWith("_table") || path.endsWith("_desk")
                || path.endsWith("_drawer") || path.endsWith("_kitchen_cabinetry") || path.endsWith("_hedge")
                || path.endsWith("_lattice_fence") || path.endsWith("_bars") || path.equals("fluid_pipe"));
        this.connectable = furniture || wall || path.endsWith("_fence") || path.endsWith("pane") || path.equals("iron_bars")
                || path.endsWith("_stairs") || path.equals("chest") || path.equals("trapped_chest");
        rotations[0] = this;
    }

    public static BlockRef of(String spec) {
        BlockRef r = CACHE.get(spec);
        return r != null ? r : create(spec);
    }

    private static synchronized BlockRef create(String raw) {
        BlockRef r = CACHE.get(raw);
        if (r != null) return r;
        String s = raw.trim();
        BlockRef fb = null;
        int bar = s.indexOf('|');
        if (bar >= 0) {
            fb = create(s.substring(bar + 1));
            s = s.substring(0, bar).trim();
        }
        String id;
        String[] keys = new String[0];
        String[] vals = new String[0];
        int b = s.indexOf('[');
        if (b >= 0) {
            id = s.substring(0, b);
            String inner = s.substring(b + 1, s.lastIndexOf(']'));
            String[] parts = inner.isEmpty() ? new String[0] : inner.split(",");
            String[][] kv = new String[parts.length][];
            for (int i = 0; i < parts.length; i++) {
                String[] p = parts[i].split("=", 2);
                kv[i] = new String[]{p[0].trim(), p.length > 1 ? p[1].trim() : ""};
            }
            Arrays.sort(kv, (x, y) -> x[0].compareTo(y[0]));
            keys = new String[kv.length];
            vals = new String[kv.length];
            for (int i = 0; i < kv.length; i++) {
                keys[i] = kv[i][0];
                vals[i] = kv[i][1];
            }
        } else {
            id = s;
        }
        if (id.indexOf(':') < 0) id = "minecraft:" + id;
        String canon = canonical(id, keys, vals) + (fb != null ? "|" + fb.spec : "");
        r = CACHE.get(canon);
        if (r == null) {
            r = new BlockRef(id, keys, vals, canon, ALL.size(), fb);
            ALL.add(r);
            CACHE.put(canon, r);
        }
        CACHE.put(raw, r);
        return r;
    }

    private static String canonical(String id, String[] keys, String[] vals) {
        if (keys.length == 0) return id;
        StringBuilder sb = new StringBuilder(id).append('[');
        for (int i = 0; i < keys.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(keys[i]).append('=').append(vals[i]);
        }
        return sb.append(']').toString();
    }

    public static synchronized BlockRef byIndex(int i) {
        return ALL.get(i);
    }

    public static synchronized int count() {
        return ALL.size();
    }

    public String get(String key) {
        for (int i = 0; i < keys.length; i++) if (keys[i].equals(key)) return values[i];
        return null;
    }

    public boolean has(String key) {
        return get(key) != null;
    }

    /** Devuelve una copia con la propiedad cambiada (o agregada). */
    public BlockRef with(String key, String value) {
        List<String> ks = new ArrayList<>(Arrays.asList(keys));
        List<String> vs = new ArrayList<>(Arrays.asList(values));
        int i = ks.indexOf(key);
        if (i >= 0) vs.set(i, value);
        else {
            ks.add(key);
            vs.add(value);
        }
        StringBuilder sb = new StringBuilder(id);
        if (!ks.isEmpty()) {
            sb.append('[');
            for (int j = 0; j < ks.size(); j++) {
                if (j > 0) sb.append(',');
                sb.append(ks.get(j)).append('=').append(vs.get(j));
            }
            sb.append(']');
        }
        if (fallback != null) sb.append('|').append(fallback.spec);
        return of(sb.toString());
    }

    public String path() {
        return id.substring(id.indexOf(':') + 1);
    }

    // ---------------------------------------------------------------- rotación

    private static final String[] DIRS = {"north", "east", "south", "west"};

    static int dirIndex(String d) {
        for (int i = 0; i < 4; i++) if (DIRS[i].equals(d)) return i;
        return -1;
    }

    static String rotDir(String d, int k) {
        int i = dirIndex(d);
        return i < 0 ? d : DIRS[(i + k) & 3];
    }

    /** Rota el estado k veces 90° en sentido horario (visto desde arriba, norte arriba). */
    public BlockRef rot(int k) {
        k &= 3;
        if (k == 0 || (keys.length == 0 && fallback == null)) return this;
        BlockRef r = rotations[k];
        if (r != null) return r;
        String[] nv = values.clone();
        boolean changed = false;
        int nIdx = -1, eIdx = -1, sIdx = -1, wIdx = -1;
        for (int i = 0; i < keys.length; i++) {
            String key = keys[i];
            String v = values[i];
            switch (key) {
                case "facing" -> nv[i] = rotDir(v, k);
                case "axis" -> {
                    if ((k & 1) == 1) nv[i] = v.equals("x") ? "z" : v.equals("z") ? "x" : v;
                }
                case "rotation" -> {
                    try {
                        nv[i] = Integer.toString((Integer.parseInt(v) + 4 * k) & 15);
                    } catch (NumberFormatException ignored) {
                    }
                }
                case "shape" -> nv[i] = rotRailShape(v, k);
                case "north" -> nIdx = i;
                case "east" -> eIdx = i;
                case "south" -> sIdx = i;
                case "west" -> wIdx = i;
                default -> {
                }
            }
        }
        if (nIdx >= 0 && eIdx >= 0 && sIdx >= 0 && wIdx >= 0) {
            int[] idx = {nIdx, eIdx, sIdx, wIdx};
            String[] old = {values[nIdx], values[eIdx], values[sIdx], values[wIdx]};
            for (int d = 0; d < 4; d++) nv[idx[(d + k) & 3]] = old[d];
        }
        for (int i = 0; i < nv.length; i++) if (!nv[i].equals(values[i])) changed = true;
        BlockRef fr = fallback != null ? fallback.rot(k) : null;
        if (fr != fallback) changed = true;
        r = changed ? of(canonical(id, keys, nv) + (fr != null ? "|" + fr.spec : "")) : this;
        rotations[k] = r;
        return r;
    }

    private static String rotRailShape(String v, int k) {
        if (!(v.contains("north") || v.contains("south") || v.contains("east") || v.contains("west"))) return v;
        if (v.startsWith("ascending_")) return "ascending_" + rotDir(v.substring(10), k);
        String[] p = v.split("_");
        if (p.length != 2) return v;
        String a = rotDir(p[0], k), b = rotDir(p[1], k);
        boolean ns = a.equals("north") || a.equals("south");
        boolean ns2 = b.equals("north") || b.equals("south");
        if (ns && ns2) return "north_south";
        if (!ns && !ns2) return "east_west";
        String first = ns ? a : b, second = ns ? b : a;
        return first + "_" + second;
    }

    /** Primer bloque vanilla de la cadena (para la vista previa); null si no hay. */
    public BlockRef vanilla() {
        for (BlockRef r = this; r != null; r = r.fallback) if (r.id.startsWith("minecraft:")) return r;
        return null;
    }

    public String namespace() {
        return id.substring(0, id.indexOf(':'));
    }

    @Override
    public String toString() {
        return spec;
    }
}
