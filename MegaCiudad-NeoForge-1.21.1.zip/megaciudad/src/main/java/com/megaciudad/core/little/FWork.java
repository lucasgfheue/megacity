package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Oficinas, escuelas, hospital, iglesia, estación, bomberos y policía. */
public final class FWork {
    private FWork() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    /** Computadora con la pantalla hacia el fondo del modelo (para quien se sienta detrás). */
    private static final BlockRef COMPUTER_BACK = r(RF + "computer[facing=north,powered=false]|" + MC + "black_carpet");

    private static Model signs(String name, String wood, String color, boolean glow, int y, String[]... texts) {
        Model m = m(name, texts.length, y + 1, 1);
        for (int x = 0; x < texts.length; x++) m.sign(x, y, 0, wallSign(wood), color, glow, texts[x]);
        return m;
    }

    // ------------------------------------------------------------------ oficina

    public static final Model WORKSTATION = reg(workstation());

    private static Model workstation() {
        Model m = m("puesto_trabajo", 2, 2, 2);
        BlockRef[] d = deskRow("birch", 2);
        m.b(0, 0, 1, d[0]).b(1, 0, 1, d[1]);
        m.b(0, 1, 1, COMPUTER).b(1, 1, 1, COMPUTER);
        return m.b(0, 0, 0, seat("gray"));
    }

    public static final Model DESK_SIMPLE = reg(row2("escritorio_simple", deskRow("birch", 2), a(COMPUTER, null)));

    public static final Model EXEC_DESK = reg(m("escritorio_ejecutivo", 3, 2, 2)
            .b(0, 0, 0, deskRow("dark_oak", 3)[0]).b(1, 0, 0, deskRow("dark_oak", 3)[1]).b(2, 0, 0, deskRow("dark_oak", 3)[2])
            .b(0, 1, 0, potted("azalea_bush")).b(1, 1, 0, COMPUTER_BACK).b(2, 1, 0, CLIPBOARD));
    public static final Model EXEC_CHAIR = reg(one("sillon_ejecutivo", chair("dark_oak")));
    public static final Model CONF_TABLE = reg(tableGrid("mesa_reuniones", "dark_oak", 4, 2).chairs(chairModel("dark_oak")));
    public static final Model CONF_ROUND = reg(m("mesa_reuniones_redonda", 2, 1, 2).fill(0, 0, 0, 1, 0, 1, cloth("light_gray")).chairs(chairModel("birch")));
    public static final Model FILE_CABINET = reg(one("archivero", kdrawer("light_gray")));
    public static final Model BINDER_SHELF = reg(col("estante_biblioratos", CHISELED, BOOKS));
    public static final Model WATER_COOLER = reg(col("dispensador_agua", counter("white"), TANK));
    public static final Model PRINTER = reg(one("impresora", PACKAGER));
    public static final Model COPIER = reg(one("fotocopiadora", REPACKAGER));
    public static final Model WHITEBOARD = reg(signs("pizarra_blanca", "birch", "black", false, 1,
            new String[]{"", "OBJETIVOS", "2026", ""}, new String[]{"", "VENTAS +20%", "CLIENTES +15%", ""}));
    public static final Model PROJ_SCREEN = reg(m("pantalla_proyector", 3, 2, 1).fill(0, 1, 0, 2, 1, 0, banner("white")));
    public static final Model PARTITION = reg(row("mampara", pane("light_gray", true, false), pane("light_gray", false, true)));
    public static final Model SERVER_RACK = reg(col("rack_servidores", RAILWAY_CASING, RAILWAY_CASING));
    public static final Model VENDING_SNACK = reg(col("maquina_snacks", v("red_concrete"), STOCK_TICKER));
    public static final Model VENDING_DRINK = reg(col("maquina_bebidas", FREEZER_D, FRIDGE_D));
    public static final Model COFFEE_STATION = reg(row2("estacion_cafe", n(2, counter("white")), a(BREWING, JUICER)));

    public static final Model RECEPTION_MOD = reg(m("recepcion_moderna", 3, 2, 2)
            .fill(0, 0, 0, 2, 0, 0, counter("white"))
            .b(0, 1, 0, DESK_BELL).b(1, 1, 0, COMPUTER_BACK).b(2, 1, 0, potted("azalea_bush"))
            .b(1, 0, 1, seat("black")));
    public static final Model LOCKERS = reg(m("lockers", 2, 2, 1).fill(0, 0, 0, 1, 1, 0, wallCab("light_gray")));
    public static final Model SAFE = reg(one("caja_fuerte", VAULT));
    public static final Model RECYCLE_BINS = reg(one("contenedores_reciclaje", RECYCLE));
    public static final Model FOOSBALL = reg(row("metegol", v("fletching_table"), v("fletching_table")));
    public static final Model PING_PONG = reg(tableGrid("ping_pong", "spruce", 3, 2));
    public static final Model BULLETIN = reg(signs("cartelera", "oak", "black", false, 0,
            new String[]{"AVISOS", "Reunión", "lunes 9 h", ""}, new String[]{"", "Cumpleaños", "de Ana", "¡Torta 16 h!"}));
    public static final Model PODIUM = reg(col("atril", LECTERN, null));
    public static final Model WAIT_SOFA = reg(row("sofa_espera", sofaRow("gray", 2)));

    // ------------------------------------------------------------------ escuela

    public static final Model TEACHER_DESK = reg(row2("escritorio_maestra", deskRow("oak", 2), a(CLIPBOARD, FRUIT_BOWL)));
    public static final Model LIB_SHELF = reg(m("estanteria_biblioteca", 3, 2, 1).fill(0, 0, 0, 2, 1, 0, BOOKS));
    public static final Model LAB_TABLE = reg(row2("mesa_laboratorio", n(2, counter("white")), a(BREWING, BREWING)));
    public static final Model MICROSCOPE = reg(one("microscopio", BREWING));
    public static final Model MAP_WALL = reg(row("mapa", banner("lime"), banner("light_blue")));
    public static final Model SCHOOL_LOCKERS = reg(m("lockers_escuela", 2, 2, 1).fill(0, 0, 0, 1, 1, 0, wallCab("blue")));
    public static final Model HOOP = reg(m("aro_basquet", 1, 3, 1).b(0, 1, 0, v("tripwire_hook[facing=north]")).b(0, 2, 0, banner("white")));
    public static final Model CAFETERIA_TABLE = reg(tableGrid("mesa_comedor_escolar", "birch", 3, 2).chairs(stoolModel("light_blue")));
    public static final Model EASEL = reg(col("atril_pintura", v("oak_fence"), standingBanner("white")));
    public static final Model SKELETON = reg(col("esqueleto", v("bone_block[axis=y]"), v("skeleton_skull[rotation=8]")));
    public static final Model KIDS_TABLE = reg(tableGrid("mesa_ninos", "birch", 2, 1).chairs(stoolModel("yellow")));

    // ------------------------------------------------------------------ hospital

    public static final Model IV_STAND = reg(col("portasuero", v("end_rod[facing=up]"), v("end_rod[facing=up]")));
    public static final Model MONITOR_STAND = reg(col("monitor_medico", ANDESITE_CASING, TV));
    public static final Model WHEELCHAIR = reg(one("silla_ruedas", seat("black")));
    public static final Model GURNEY = reg(m("camilla", 1, 1, 2).b(0, 0, 0, bed("white", "foot")).b(0, 0, 1, bed("white", "head")));
    public static final Model MED_CABINET = reg(col("armario_medico", wallCab("white"), wallCab("white")));
    public static final Model WAIT_CHAIRS = reg(row("sillas_espera", n(3, seat("light_blue"))));
    public static final Model EXAM_BED = reg(m("camilla_examen", 1, 1, 2).b(0, 0, 0, bed("light_blue", "foot")).b(0, 0, 1, bed("light_blue", "head")));
    public static final Model SURGICAL_LAMP = reg(m("lampara_quirofano", 2, 1, 2).fill(0, 0, 0, 1, 0, 1, CEIL_LIGHT));
    public static final Model XRAY = reg(row("negatoscopio", banner("white"), banner("white")));
    public static final Model OXYGEN = reg(one("tubo_oxigeno", BACKTANK));
    public static final Model DIVIDER = reg(m("biombo", 2, 2, 1).b(0, 0, 0, pane("light_blue", true, false)).b(1, 0, 0, pane("light_blue", false, true))
            .b(0, 1, 0, pane("light_blue", true, false)).b(1, 1, 0, pane("light_blue", false, true)));
    public static final Model FIRST_AID = reg(one("botiquin", toolbox("red")));
    public static final Model NURSE_DESK = reg(row2("mostrador_enfermeria", n(3, counter("white")), a(CLIPBOARD, COMPUTER, potted("azure_bluet"))));

    // ------------------------------------------------------------------ iglesia

    public static final Model PEW = reg(row("banco_iglesia", n(3, seatStairs("spruce"))));
    public static final Model ALTAR = reg(row2("altar", n(3, v("chiseled_quartz_block")),
            a(v("white_candle[candles=3,lit=true]"), null, v("white_candle[candles=3,lit=true]"))));
    public static final Model CANDLE_STAND = reg(col("candelabro", v("polished_deepslate_wall"), v("white_candle[candles=4,lit=true]")));
    public static final Model ORGAN = reg(m("organo", 3, 3, 1).b(0, 0, 0, v("dark_oak_planks")).b(1, 0, 0, NOTE).b(2, 0, 0, v("dark_oak_planks"))
            .fill(0, 1, 0, 2, 2, 0, PIPE_Y));
    public static final Model FONT = reg(one("pila_bautismal", CAULDRON_WATER));
    public static final Model FLAG = reg(m("bandera", 1, 3, 1).b(0, 0, 0, v("chain[axis=y]")).b(0, 1, 0, standingBanner("light_blue")));

    // ------------------------------------------------------------------ estación y aeropuerto

    public static final Model TURNSTILE = reg(one("molinete", ANDESITE_BARS));
    public static final Model INFO_KIOSK = reg(col("kiosco_info", BRASS_CASING, TV));
    public static final Model LUGGAGE_CART = reg(m("carro_valijas", 1, 1, 2).b(0, 0, 0, v("black_shulker_box[facing=up]")).b(0, 0, 1, v("brown_shulker_box[facing=up]")));
    public static final Model SUITCASES = reg(one("valijas", v("blue_shulker_box[facing=up]")));
    public static final Model STANCHIONS = reg(row("separadores", bars(true, false), bars(false, true)));
    public static final Model DRINK_FOUNTAIN = reg(one("bebedero", CAULDRON_WATER));
    public static final Model DEPARTURES = reg(row("pantalla_salidas", DISPLAY, DISPLAY));
    public static final Model BENCH_METAL = reg(row("banco_metal", n(3, seatStairs("polished_blackstone"))));
    public static final Model METAL_DETECTOR = reg(col("detector_metales", v("iron_bars"), v("iron_bars"), v("smooth_stone_slab[type=bottom]")));

    // ------------------------------------------------------------------ bomberos y policía

    public static final Model FIRE_GEAR = reg(row2("equipo_bombero", a(BACKTANK, NETHERITE_TANK), a(banner("red"), banner("red"))));
    public static final Model HOSE_REEL = reg(one("manguera", r(CR + "copper_valve_handle[facing=north]|" + MC + "air")));
    public static final Model EXTINGUISHER = reg(one("extintor", valve("red")));
    public static final Model CONES = reg(one("conos", v("orange_candle[candles=4,lit=false]")));
    public static final Model POLICE_MOTO = reg(m("moto_policia", 1, 1, 2).b(0, 0, 0, v("polished_blackstone_stairs[facing=north]")).b(0, 0, 1, v("blue_concrete")));
    public static final Model SCOOTER = reg(m("scooter", 1, 1, 2).b(0, 0, 0, v("polished_andesite_stairs[facing=north]")).b(0, 0, 1, v("lime_concrete")));
    public static final Model BICYCLE = reg(row("bicicleta", bars(true, false), bars(false, true)));
}
