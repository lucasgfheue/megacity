package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import java.util.ArrayList;
import java.util.List;

/**
 * Decoración hecha con bloques (vanilla o de mods, con alternativa si el mod no está), con el frente
 * hacia el norte (z = 0) y la esquina mínima en (0, 0, 0). Puede incluir carteles con texto.
 */
public final class Model {
    public final String name;
    public final int sx, sy, sz;
    final List<int[]> blocks = new ArrayList<>();
    final List<Sign> signs = new ArrayList<>();
    private final Compiled[] cache = new Compiled[4];
    /** Silla que se pone alrededor (lados largos) al colocar esta mesa en una habitación; null = ninguna. */
    public Model around;
    /** Silla que se pone delante de la primera celda (pupitres); null = ninguna. */
    public Model front;

    public Model(String name, int sx, int sy, int sz) {
        this.name = name;
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
    }

    private void check(int x, int y, int z) {
        if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz)
            throw new IllegalArgumentException(name + ": bloque fuera del modelo en " + x + "," + y + "," + z);
    }

    public Model b(int x, int y, int z, BlockRef r) {
        check(x, y, z);
        if (r != null) blocks.add(new int[]{x, y, z, r.index});
        return this;
    }

    public Model b(int x, int y, int z, String spec) {
        return b(x, y, z, BlockRef.of(spec));
    }

    public Model extra(int x, int y, int z, BlockRef r) {
        return b(x, y, z, r);
    }

    public Model fill(int x0, int y0, int z0, int x1, int y1, int z1, BlockRef r) {
        for (int y = y0; y <= y1; y++)
            for (int z = z0; z <= z1; z++)
                for (int x = x0; x <= x1; x++) b(x, y, z, r);
        return this;
    }

    public Model fill(int x0, int y0, int z0, int x1, int y1, int z1, String spec) {
        return fill(x0, y0, z0, x1, y1, z1, BlockRef.of(spec));
    }

    /** Bloque de luz invisible. */
    public Model light(int x, int y, int z, int level) {
        return b(x, y, z, BlockRef.of("minecraft:light[level=" + level + "]"));
    }

    /** Cartel (de pared o de pie) con hasta 4 líneas de texto. */
    public Model sign(int x, int y, int z, BlockRef state, String color, boolean glow, String... lines) {
        check(x, y, z);
        signs.add(new Sign(x, y, z, state, lines, color, glow));
        return this;
    }

    public Model copy(String newName) {
        Model m = new Model(newName, sx, sy, sz);
        m.blocks.addAll(blocks);
        m.signs.addAll(signs);
        m.around = around;
        m.front = front;
        return m;
    }

    public Model chairs(Model chair) {
        around = chair;
        return this;
    }

    public Model seatFront(Model chair) {
        front = chair;
        return this;
    }

    public int blockCount() {
        return blocks.size() + signs.size();
    }

    public record Sign(int x, int y, int z, BlockRef state, String[] lines, String color, boolean glow) {
    }

    public static final class Compiled {
        public final int sx, sz;
        public final List<int[]> extras;
        public final List<Sign> signs;

        Compiled(int sx, int sz, List<int[]> extras, List<Sign> signs) {
            this.sx = sx;
            this.sz = sz;
            this.extras = extras;
            this.signs = signs;
        }
    }

    public Compiled compiled(int k) {
        k &= 3;
        Compiled c = cache[k];
        if (c == null) {
            c = compile(k);
            cache[k] = c;
        }
        return c;
    }

    private int[] pos(int k, int x, int z) {
        return switch (k) {
            case 1 -> new int[]{sz - 1 - z, x};
            case 2 -> new int[]{sx - 1 - x, sz - 1 - z};
            case 3 -> new int[]{z, sx - 1 - x};
            default -> new int[]{x, z};
        };
    }

    private Compiled compile(int k) {
        List<int[]> ex = new ArrayList<>(blocks.size());
        for (int[] e : blocks) {
            int[] p = pos(k, e[0], e[2]);
            ex.add(new int[]{p[0], e[1], p[1], BlockRef.byIndex(e[3]).rot(k).index});
        }
        List<Sign> sg = new ArrayList<>(signs.size());
        for (Sign s : signs) {
            int[] p = pos(k, s.x(), s.z());
            sg.add(new Sign(p[0], s.y(), p[1], s.state().rot(k), s.lines(), s.color(), s.glow()));
        }
        int rsx = (k & 1) == 0 ? sx : sz, rsz = (k & 1) == 0 ? sz : sx;
        return new Compiled(rsx, rsz, ex, sg);
    }
}
