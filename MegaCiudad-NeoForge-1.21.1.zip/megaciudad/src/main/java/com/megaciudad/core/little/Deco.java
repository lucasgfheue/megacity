package com.megaciudad.core.little;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Biblioteca de decoraciones hechas con mini-bloques de LittleTiles (grilla 16).
 * Convención: el frente del modelo mira al norte (z=0). Los modelos "de vereda" incluyen en su
 * bloque inferior media losa de piedra lisa para empalmar con la vereda (losa inferior).
 */
public final class Deco {
    private Deco() {
    }

    // ------------------------------------------------------------------ materiales
    public static final Mat BASE = Mat.of("smooth_stone");
    public static final Mat BLACK = Mat.of("black_concrete");
    public static final Mat GRAY = Mat.of("gray_concrete");
    public static final Mat LGRAY = Mat.of("light_gray_concrete");
    public static final Mat WHITE = Mat.of("white_concrete");
    public static final Mat RED = Mat.of("red_concrete");
    public static final Mat YELLOW = Mat.of("yellow_concrete");
    public static final Mat GREEN = Mat.of("green_concrete");
    public static final Mat LIME = Mat.of("lime_concrete");
    public static final Mat BLUE = Mat.of("blue_concrete");
    public static final Mat LBLUE = Mat.of("light_blue_concrete");
    public static final Mat ORANGE = Mat.of("orange_concrete");
    public static final Mat BROWN = Mat.of("brown_concrete");
    public static final Mat CYAN = Mat.of("cyan_concrete");
    public static final Mat PINK = Mat.of("pink_concrete");
    public static final Mat PURPLE = Mat.of("purple_concrete");
    public static final Mat IRON = Mat.of("iron_block");
    public static final Mat GOLD = Mat.of("gold_block");
    public static final Mat QUARTZ = Mat.of("smooth_quartz");
    public static final Mat STONE = Mat.of("stone");
    public static final Mat ANDESITE = Mat.of("polished_andesite");
    public static final Mat DEEPSLATE = Mat.of("polished_deepslate");
    public static final Mat SPRUCE = Mat.of("spruce_planks");
    public static final Mat DARK_OAK = Mat.of("dark_oak_planks");
    public static final Mat OAK = Mat.of("oak_planks");
    public static final Mat BIRCH = Mat.of("birch_planks");
    public static final Mat CHERRY = Mat.of("cherry_planks");
    public static final Mat OAK_LOG = Mat.of("oak_log");
    public static final Mat GLASS = Mat.of("glass");
    public static final Mat GLASS_BLUE = Mat.of("light_blue_stained_glass");
    public static final Mat GLASS_DARK = Mat.of("gray_stained_glass");
    public static final Mat GLASS_BLACK = Mat.of("black_stained_glass");
    public static final Mat LAMP = Mat.of("sea_lantern");
    public static final Mat PEARL = Mat.of("pearlescent_froglight");
    public static final Mat WARM = Mat.of("ochre_froglight");
    public static final Mat SEA = Mat.of("sea_lantern");
    public static final Mat GLOW = Mat.of("glowstone");
    public static final Mat GREEN_LIT = Mat.of("verdant_froglight");
    public static final Mat RED_OFF = Mat.of("red_terracotta");
    public static final Mat YEL_OFF = Mat.of("yellow_terracotta");
    public static final Mat GRN_OFF = Mat.of("green_terracotta");
    public static final Mat LEAF = Mat.of("moss_block");
    public static final Mat LEAF_DARK = Mat.of("green_wool");
    public static final Mat SOIL = Mat.of("rooted_dirt");
    public static final Mat TERRA = Mat.of("terracotta");
    public static final Mat WATER = Mat.tint("light_blue_stained_glass", 0x4FA3E0, 200);
    public static final Mat WOOL_W = Mat.of("white_wool");

    private static void base(Model m) {
        m.box(BASE, 0, 0, 0, m.vx, 8, m.vz);
    }

    private static final ConcurrentHashMap<String, Model> CACHE = new ConcurrentHashMap<>();

    // ------------------------------------------------------------------ vereda

    /** Farol: poste en la celda trasera (z=1) y brazo con luminaria sobre la calzada (z=0). */
    public static final Model LAMP_POST = lampPost();

    private static Model lampPost() {
        Model m = new Model("farol", 1, 6, 2);
        m.box(BASE, 0, 0, 16, 16, 8, 32);
        m.box(BLACK, 5, 8, 21, 11, 13, 27);
        m.box(GRAY, 4, 8, 20, 12, 9, 28);
        m.box(BLACK, 6, 13, 22, 10, 88, 26);
        m.box(BLACK, 5, 40, 21, 11, 42, 27);
        m.box(BLACK, 7, 86, 7, 9, 89, 24);
        m.box(BLACK, 7, 83, 20, 9, 86, 22);
        m.box(BLACK, 7, 81, 22, 9, 83, 24);
        m.box(GRAY, 3, 85, 1, 13, 89, 12);
        m.box(BLACK, 4, 89, 2, 12, 90, 11);
        m.box(LAMP, 4, 84, 2, 12, 85, 11);
        m.light(0, 4, 0, 15);
        return m;
    }

    /** Farol de parque, estilo clásico con farolito arriba (1x1). */
    public static final Model PARK_LAMP = parkLamp();

    private static Model parkLamp() {
        Model m = new Model("farol_parque", 1, 5, 1);
        m.cylY(BLACK, 8, 8, 3, 0, 4);
        m.cylY(BLACK, 8, 8, 1.6, 4, 60);
        m.cylY(BLACK, 8, 8, 2.4, 20, 22);
        m.box(BLACK, 4, 60, 4, 12, 61, 12);
        m.box(WARM, 5, 61, 5, 11, 70, 11);
        m.box(BLACK, 4, 61, 4, 5, 70, 5);
        m.box(BLACK, 11, 61, 4, 12, 70, 5);
        m.box(BLACK, 4, 61, 11, 5, 70, 12);
        m.box(BLACK, 11, 61, 11, 12, 70, 12);
        m.box(BLACK, 4, 70, 4, 12, 71, 12);
        m.box(BLACK, 6, 71, 6, 10, 73, 10);
        m.box(GOLD, 7, 73, 7, 9, 75, 9);
        m.light(0, 5, 0, 15);
        return m;
    }

    public static final Model BENCH = bench(true, SPRUCE);
    public static final Model BENCH_FLOOR = bench(false, DARK_OAK);

    private static Model bench(boolean onSidewalk, Mat wood) {
        Model m = new Model(onSidewalk ? "banco" : "banco_interior", 2, 2, 1);
        int b = onSidewalk ? 8 : 0;
        if (onSidewalk) base(m);
        for (int lx : new int[]{2, 28}) {
            m.box(BLACK, lx, b, 3, lx + 2, b + 7, 5);
            m.box(BLACK, lx, b, 11, lx + 2, b + 19, 13);
            m.box(BLACK, lx, b + 6, 3, lx + 2, b + 7, 13);
            m.box(BLACK, lx - 1, b + 11, 2, lx + 3, b + 12, 12);
        }
        m.box(wood, 1, b + 7, 2, 31, b + 8, 5);
        m.box(wood, 1, b + 7, 6, 31, b + 8, 9);
        m.box(wood, 1, b + 7, 10, 31, b + 8, 13);
        m.box(wood, 1, b + 10, 12, 31, b + 12, 14);
        m.box(wood, 1, b + 14, 12, 31, b + 16, 14);
        m.box(wood, 1, b + 18, 12, 31, b + 20, 14);
        return m;
    }

    public static final Model BIN = bin(true);
    public static final Model BIN_FLOOR = bin(false);

    private static Model bin(boolean sidewalk) {
        Model m = new Model(sidewalk ? "papelera" : "papelera_interior", 1, 2, 1);
        int b = sidewalk ? 8 : 0;
        if (sidewalk) base(m);
        m.cylY(BLACK, 8, 8, 3, b, b + 2);
        m.cylY(GREEN, 8, 8, 4.5, b + 2, b + 13);
        m.cylY(GRAY, 8, 8, 4.8, b + 6, b + 7);
        m.cylY(IRON, 8, 8, 5, b + 13, b + 15);
        m.cylY(BLACK, 8, 8, 3.4, b + 10, b + 15);
        return m;
    }

    public static final Model HYDRANT = hydrant();

    private static Model hydrant() {
        Model m = new Model("hidrante", 1, 2, 1);
        base(m);
        m.cylY(RED, 8, 8, 3.8, 8, 10);
        m.cylY(RED, 8, 8, 3, 10, 19);
        m.cylY(RED, 8, 8, 3.5, 17, 18);
        m.cylY(RED, 8, 8, 2.4, 19, 21);
        m.cylY(YELLOW, 8, 8, 1.2, 21, 23);
        m.cylX(RED, 14.5, 8, 1.6, 3, 13);
        m.cylZ(RED, 8, 13.5, 1.9, 3, 8);
        m.cylZ(YELLOW, 8, 13.5, 1.0, 2, 3);
        return m;
    }

    public static final Model MAILBOX = mailbox();

    private static Model mailbox() {
        Model m = new Model("buzon", 1, 2, 1);
        base(m);
        m.box(BLACK, 6, 8, 6, 10, 14, 10);
        m.box(YELLOW, 3, 14, 3, 13, 25, 13);
        m.cylZ(YELLOW, 8, 25, 5, 3, 13);
        m.box(BLACK, 5, 22, 2, 11, 23, 3);
        m.box(BLUE, 3, 17, 2, 13, 19, 3);
        return m;
    }

    /** Semáforo de esquina: cabezal al norte (verde) y al oeste (rojo). */
    public static final Model TRAFFIC_LIGHT = trafficLight();

    private static Model trafficLight() {
        Model m = new Model("semaforo", 1, 5, 1);
        base(m);
        m.box(GRAY, 5, 8, 5, 11, 10, 11);
        m.box(BLACK, 6, 10, 6, 10, 74, 10);
        m.box(YELLOW, 6, 22, 5, 10, 27, 6);
        m.box(BLACK, 7, 23, 4, 9, 25, 5);
        // cabezal norte
        m.box(BLACK, 5, 50, 1, 11, 71, 6);
        m.box(RED_OFF, 6, 65, 0, 10, 69, 1);
        m.box(YEL_OFF, 6, 59, 0, 10, 63, 1);
        m.box(GREEN_LIT, 6, 52, 0, 10, 57, 1);
        m.box(BLACK, 5, 69, 0, 11, 70, 1);
        // cabezal oeste
        m.box(BLACK, 1, 50, 5, 6, 71, 11);
        m.box(RED, 0, 65, 6, 1, 69, 10);
        m.box(YEL_OFF, 0, 59, 6, 1, 63, 10);
        m.box(GRN_OFF, 0, 52, 6, 1, 57, 10);
        m.box(BLACK, 0, 69, 5, 1, 70, 11);
        return m;
    }

    public static final Model BOLLARD = bollard();

    private static Model bollard() {
        Model m = new Model("bolardo", 1, 2, 1);
        base(m);
        m.cylY(GRAY, 8, 8, 2.5, 8, 22);
        m.cylY(YELLOW, 8, 8, 2.6, 18, 19);
        m.cylY(LGRAY, 8, 8, 2.0, 22, 23);
        return m;
    }

    public static final Model BIKE_RACK = bikeRack();

    private static Model bikeRack() {
        Model m = new Model("bicicletero", 2, 2, 1);
        base(m);
        for (int x = 3; x < 32; x += 9) {
            m.box(IRON, x, 8, 4, x + 1, 20, 5);
            m.box(IRON, x, 8, 11, x + 1, 20, 12);
            m.box(IRON, x, 19, 4, x + 1, 20, 12);
        }
        // una bicicleta
        m.cylZ(BLACK, 8, 13, 3.5, 7, 8);
        m.cylZ(BLACK, 15, 13, 3.5, 7, 8);
        m.cylZ(LGRAY, 8, 13, 2.5, 7, 8);
        m.cylZ(LGRAY, 15, 13, 2.5, 7, 8);
        m.box(RED, 8, 13, 7, 16, 14, 8);
        m.box(RED, 11, 13, 7, 12, 18, 8);
        m.box(BLACK, 10, 18, 6, 13, 19, 9);
        return m;
    }

    public static final Model PLANTER = planter();

    private static Model planter() {
        Model m = new Model("macetero", 1, 2, 1);
        base(m);
        m.box(LGRAY, 1, 8, 1, 15, 17, 15);
        m.box(SOIL, 2, 16, 2, 14, 17, 14);
        m.ellipsoid(LEAF, 8, 22, 8, 6, 5, 6);
        m.ellipsoid(LEAF_DARK, 6, 21, 9, 3, 3, 3);
        m.box(Mat.of("red_wool"), 10, 24, 5, 11, 25, 6);
        m.box(Mat.of("yellow_wool"), 5, 25, 10, 6, 26, 11);
        return m;
    }

    /** Refugio de ómnibus: abierto hacia la calle (norte). */
    public static final Model BUS_STOP = busStop();

    private static Model busStop() {
        Model m = new Model("parada", 3, 3, 2);
        base(m);
        for (int x : new int[]{1, 45})
            for (int z : new int[]{4, 26}) m.box(BLACK, x, 8, z, x + 2, 44, z + 2);
        m.box(GLASS_BLUE, 3, 10, 26, 45, 42, 27);
        m.box(BLACK, 3, 25, 26, 45, 26, 27);
        m.box(GLASS_BLUE, 1, 10, 6, 2, 42, 26);
        m.box(WHITE, 0, 44, 2, 48, 46, 30);
        m.box(LGRAY, 0, 46, 3, 48, 47, 29);
        m.box(SEA, 6, 43, 10, 42, 44, 22);
        m.box(BLACK, 8, 8, 20, 10, 15, 24);
        m.box(BLACK, 38, 8, 20, 40, 15, 24);
        m.box(SPRUCE, 6, 15, 19, 42, 16, 25);
        m.box(IRON, 45, 10, 6, 47, 42, 26);
        m.box(SEA, 44, 13, 8, 45, 39, 24);
        m.box(BLUE, 6, 36, 2, 42, 44, 3);
        text(m, "PARADA", WHITE, 1, 24, 44, 1, 1);
        m.light(1, 1, 0, 12);
        return m;
    }

    /** Kiosco de diarios (2x3x2). */
    public static final Model KIOSK = kiosk();

    private static Model kiosk() {
        Model m = new Model("kiosco", 2, 3, 2);
        base(m);
        m.box(GREEN, 2, 8, 2, 30, 36, 30);
        m.box(GLASS_BLUE, 4, 18, 1, 28, 32, 2);
        m.box(WHITE, 4, 18, 2, 28, 19, 6);
        for (int x = 5; x < 27; x += 4) m.box(x % 8 == 1 ? RED : x % 8 == 5 ? BLUE : YELLOW, x, 19, 3, x + 3, 23, 5);
        m.box(GREEN, 0, 36, 0, 32, 38, 32);
        m.box(DEEPSLATE, 4, 38, 4, 28, 42, 28);
        m.box(YELLOW, 1, 27, 0, 31, 36, 1);
        text(m, "DIARIO", BLACK, 1, 16, 35, 0, 1);
        return m;
    }

    // ------------------------------------------------------------------ vehículos

    public static final Mat[] PAINTS = {RED, BLUE, WHITE, BLACK, LGRAY, GRAY, Mat.of("cyan_terracotta"), GREEN,
            Mat.of("orange_terracotta"), Mat.of("brown_concrete"), Mat.of("light_blue_terracotta")};

    public static Model car(int variant) {
        return CACHE.computeIfAbsent("car" + variant, k -> buildCar(variant));
    }

    /** Auto (2 de ancho x 4 de largo), frente al norte. variant: 0..n-1 colores, 100 = taxi, 101 = policía. */
    private static Model buildCar(int variant) {
        Mat paint = variant == 100 ? YELLOW : variant == 101 ? WHITE : PAINTS[Math.floorMod(variant, PAINTS.length)];
        Model m = new Model("auto" + variant, 2, 2, 4);
        boolean hatch = variant % 3 == 1 && variant < 100;
        int zEnd = hatch ? 56 : 62;
        m.box(paint, 1, 4, 3, 31, 13, zEnd);
        m.box(BLACK, 1, 3, 1, 31, 7, 4);
        m.box(BLACK, 1, 3, zEnd - 1, 31, 7, zEnd + 1);
        m.box(BLACK, 7, 7, 2, 25, 11, 3);
        m.box(LAMP, 2, 8, 2, 7, 11, 3);
        m.box(LAMP, 25, 8, 2, 30, 11, 3);
        m.box(RED, 2, 8, zEnd, 7, 11, zEnd + 1);
        m.box(RED, 25, 8, zEnd, 30, 11, zEnd + 1);
        Mat win = GLASS_BLACK;
        int c0 = 19, c1 = hatch ? 52 : 47;
        m.box(win, 3, 13, c0, 29, 21, c1);
        m.box(win, 4, 13, c0 - 3, 28, 16, c0);
        m.box(paint, 4, 21, c0 + 1, 28, 23, c1 - 1);
        for (int z : new int[]{c0, (c0 + c1) / 2, c1 - 2}) {
            m.box(paint, 3, 13, z, 5, 21, z + 2);
            m.box(paint, 27, 13, z, 29, 21, z + 2);
        }
        m.box(paint, 0, 14, c0 - 1, 1, 16, c0 + 1);
        m.box(paint, 31, 14, c0 - 1, 32, 16, c0 + 1);
        m.box(DEEPSLATE, 1, 10, 30, 31, 11, 31);
        for (int zc : new int[]{13, hatch ? 47 : 51}) {
            m.cylX(BLACK, 5, zc, 5, 1, 8);
            m.cylX(BLACK, 5, zc, 5, 24, 31);
            m.cylX(IRON, 5, zc, 2.2, 0, 1);
            m.cylX(IRON, 5, zc, 2.2, 31, 32);
        }
        if (variant == 100) {
            m.box(BLACK, 10, 23, 30, 22, 26, 36);
            m.box(GLOW, 11, 23, 30, 21, 25, 31);
            m.box(BLACK, 1, 9, 22, 31, 10, 44);
        } else if (variant == 101) {
            m.box(BLUE, 1, 7, 6, 31, 10, 58);
            m.box(BLACK, 1, 4, 22, 31, 7, 46);
            m.box(BLUE, 7, 23, 30, 16, 25, 35);
            m.box(RED, 16, 23, 30, 25, 25, 35);
        }
        return m;
    }

    /** Furgoneta de reparto (2x2x5). */
    public static Model van(int variant) {
        return CACHE.computeIfAbsent("van" + variant, k -> {
            Mat paint = variant == 0 ? WHITE : variant == 1 ? LGRAY : variant == 2 ? YELLOW : variant == 3 ? Mat.of("red_concrete") : BLUE;
            Model m = new Model("furgon" + variant, 2, 2, 5);
            m.box(paint, 1, 4, 2, 31, 29, 78);
            m.box(GLASS_BLACK, 3, 17, 2, 29, 27, 3);
            m.box(GLASS_BLACK, 1, 18, 4, 2, 27, 16);
            m.box(GLASS_BLACK, 30, 18, 4, 31, 27, 16);
            m.box(BLACK, 1, 3, 0, 31, 7, 2);
            m.box(BLACK, 1, 3, 78, 31, 7, 80);
            m.box(LAMP, 2, 9, 1, 7, 12, 2);
            m.box(LAMP, 25, 9, 1, 30, 12, 2);
            m.box(RED, 2, 9, 78, 6, 15, 79);
            m.box(RED, 26, 9, 78, 30, 15, 79);
            m.box(BLACK, 15, 6, 78, 17, 28, 79);
            if (variant == 4) {
                m.box(RED, 0, 12, 20, 1, 20, 76);
                m.box(RED, 31, 12, 20, 32, 20, 76);
                m.box(RED, 6, 29, 8, 26, 31, 12);
                m.box(BLUE, 6, 29, 12, 26, 31, 14);
            }
            for (int zc : new int[]{14, 64}) {
                m.cylX(BLACK, 5, zc, 5, 1, 8);
                m.cylX(BLACK, 5, zc, 5, 24, 31);
                m.cylX(IRON, 5, zc, 2, 0, 1);
                m.cylX(IRON, 5, zc, 2, 31, 32);
            }
            return m;
        });
    }

    /** Ambulancia (furgón blanco con franjas y balizas). */
    public static final Model AMBULANCE = ambulance();

    private static Model ambulance() {
        Model m = new Model("ambulancia", 2, 2, 5);
        m.box(WHITE, 1, 4, 2, 31, 29, 78);
        m.box(GLASS_BLACK, 3, 17, 2, 29, 27, 3);
        m.box(RED, 0, 12, 4, 1, 16, 78);
        m.box(RED, 31, 12, 4, 32, 16, 78);
        m.box(RED, 1, 12, 78, 31, 16, 79);
        m.box(RED, 0, 19, 40, 1, 27, 44);
        m.box(RED, 0, 21, 38, 1, 25, 46);
        m.box(RED, 31, 19, 40, 32, 27, 44);
        m.box(RED, 31, 21, 38, 32, 25, 46);
        m.box(RED, 4, 29, 6, 14, 31, 10);
        m.box(BLUE, 18, 29, 6, 28, 31, 10);
        m.box(BLACK, 1, 3, 0, 31, 7, 2);
        m.box(LAMP, 2, 9, 1, 7, 12, 2);
        m.box(LAMP, 25, 9, 1, 30, 12, 2);
        for (int zc : new int[]{14, 64}) {
            m.cylX(BLACK, 5, zc, 5, 1, 8);
            m.cylX(BLACK, 5, zc, 5, 24, 31);
        }
        return m;
    }

    /** Autobomba (2x3x6). */
    public static final Model FIRE_TRUCK = fireTruck();

    private static Model fireTruck() {
        Model m = new Model("autobomba", 2, 3, 6);
        m.box(RED, 1, 5, 2, 31, 30, 24);
        m.box(GLASS_BLACK, 3, 18, 1, 29, 28, 2);
        m.box(GLASS_BLACK, 0, 18, 4, 1, 28, 20);
        m.box(GLASS_BLACK, 31, 18, 4, 32, 28, 20);
        m.box(RED, 1, 5, 24, 31, 26, 94);
        m.box(IRON, 1, 6, 30, 2, 24, 90);
        m.box(IRON, 30, 6, 30, 31, 24, 90);
        for (int z = 34; z < 88; z += 10) {
            m.box(LGRAY, 0, 8, z, 1, 22, z + 8);
            m.box(LGRAY, 31, 8, z, 32, 22, z + 8);
        }
        m.box(IRON, 4, 26, 26, 6, 30, 92);
        m.box(IRON, 26, 26, 26, 28, 30, 92);
        for (int z = 28; z < 92; z += 5) m.box(IRON, 6, 28, z, 26, 29, z + 1);
        m.box(BLUE, 4, 30, 6, 14, 33, 10);
        m.box(RED, 18, 30, 6, 28, 33, 10);
        m.box(BLACK, 1, 4, 0, 31, 8, 2);
        m.box(LAMP, 2, 10, 1, 7, 13, 2);
        m.box(LAMP, 25, 10, 1, 30, 13, 2);
        m.box(WHITE, 0, 14, 4, 1, 16, 94);
        m.box(WHITE, 31, 14, 4, 32, 16, 94);
        for (int zc : new int[]{14, 62, 80}) {
            m.cylX(BLACK, 6, zc, 6, 1, 8);
            m.cylX(BLACK, 6, zc, 6, 24, 31);
            m.cylX(IRON, 6, zc, 2.5, 0, 1);
            m.cylX(IRON, 6, zc, 2.5, 31, 32);
        }
        return m;
    }

    // ------------------------------------------------------------------ texto

    /**
     * Dibuja texto en el plano frontal de un modelo (se lee bien desde el norte).
     * cx = centro en x (vóxel), yTop = borde superior (vóxel, exclusivo), z0..z0+depth = relieve.
     */
    public static void text(Model m, String s, Mat mat, int px, int cx, int yTop, int z0, int depth) {
        boolean[][] bm = Font.bitmap(s);
        int w = bm[0].length;
        int xRight = cx + (w * px) / 2 - 1;
        for (int r = 0; r < Font.H; r++)
            for (int c = 0; c < w; c++) {
                if (!bm[r][c]) continue;
                int x1 = xRight - c * px + 1, x0 = x1 - px;
                int y1 = yTop - r * px, y0 = y1 - px;
                m.box(mat, x0, y0, z0, x1, y1, z0 + depth);
            }
    }

    /**
     * Cartel de pared con letras en relieve. El fondo del cartel queda pegado a la cara trasera
     * del modelo (z = 16), para colgarlo sobre una fachada que esté justo detrás.
     */
    public static Model wallSign(String text, Mat board, Mat letters, int px) {
        String key = "sign|" + text + "|" + System.identityHashCode(board) + "|" + System.identityHashCode(letters) + "|" + px;
        return CACHE.computeIfAbsent(key, k -> {
            int tw = Font.width(text) * px;
            int pad = Math.max(2, px * 2);
            int wv = tw + pad * 2, hv = Font.H * px + pad;
            int sx = (wv + 15) / 16, sy = (hv + 15) / 16;
            Model m = new Model("cartel", sx, sy, 1);
            int x0 = (sx * 16 - wv) / 2, y0 = (sy * 16 - hv) / 2;
            m.box(board, x0, y0, 12, x0 + wv, y0 + hv, 16);
            m.box(BLACK, x0, y0, 11, x0 + wv, y0 + 1, 12);
            text(m, text, letters, px, sx * 8, y0 + hv - pad / 2 + (Font.hasAccentRow(text) ? 0 : px), 10, 2);
            return m;
        });
    }
}
