package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

/** Material de carteles y letreros: un bloque vanilla (p. ej. "blue_concrete") del que se deduce el color. */
public final class Mat {
    private static final String[] DYES = {"light_blue", "light_gray", "white", "orange", "magenta", "yellow", "lime", "pink",
            "gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    public final BlockRef block;

    private Mat(BlockRef block) {
        this.block = block;
    }

    public static Mat of(String id) {
        return new Mat(BlockRef.of(id));
    }

    public static Mat of(BlockRef b) {
        return new Mat(b);
    }

    /** Color de tinte más parecido (white, red, light_blue...). */
    public String dye() {
        String p = block.path();
        for (String d : DYES) if (p.startsWith(d + "_")) return d;
        if (p.contains("gold") || p.contains("ochre") || p.contains("glowstone") || p.contains("shroomlight")) return "yellow";
        if (p.contains("verdant") || p.contains("emerald") || p.contains("moss")) return "lime";
        if (p.contains("pearlescent") || p.contains("amethyst")) return "pink";
        if (p.contains("redstone") || p.contains("nether_wart")) return "red";
        if (p.contains("lapis")) return "blue";
        if (p.contains("blackstone") || p.contains("obsidian") || p.contains("coal") || p.contains("deepslate")) return "black";
        return "white";
    }

    /** Madera de cartel con el color más parecido a este material. */
    public String signWood() {
        return switch (dye()) {
            case "black", "gray" -> "dark_oak";
            case "white", "light_gray" -> "birch";
            case "red" -> "mangrove";
            case "green", "lime", "cyan", "blue", "light_blue" -> "warped";
            case "yellow" -> "bamboo";
            case "orange" -> "acacia";
            case "pink", "magenta" -> "cherry";
            case "purple" -> "crimson";
            default -> "spruce";
        };
    }
}
