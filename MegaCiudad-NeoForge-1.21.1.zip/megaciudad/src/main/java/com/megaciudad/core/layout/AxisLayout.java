package com.megaciudad.core.layout;

/**
 * Trazado de un eje (igual para X y Z): 25 calles/avenidas (incluyendo los bulevares del
 * perímetro) y 24 manzanas entre ellas, sumando exactamente 2000 bloques.
 */
public final class AxisLayout {
    public static final int SIZE = 2000;
    public static final int LOTS = 24, ROADS = 25;

    public static final int STREET = 0, AVENUE = 1, CENTRAL = 2, PERIMETER = 3;
    public static final int SW = 0, LANE = 1, DIV = 2, CENTER = 3, MEDIAN = 4;

    public final int[] roadStart = new int[ROADS], roadWidth = new int[ROADS], roadKind = new int[ROADS];
    public final int[] lotStart = new int[LOTS], lotSize = new int[LOTS];
    /** Para cada desplazamiento: >=0 índice de manzana; <0 -(índice de calle + 1). */
    private final int[] cellAt = new int[SIZE];
    private final int[] posAt = new int[SIZE];

    public AxisLayout() {
        int pos = 0;
        roadKind[0] = PERIMETER;
        roadWidth[0] = width(PERIMETER);
        roadStart[0] = 0;
        pos += roadWidth[0];
        for (int i = 0; i < LOTS; i++) {
            int half = i < 12 ? i : 23 - i;
            lotSize[i] = (half == 3 || half == 8) ? 66 : 67;
            lotStart[i] = pos;
            pos += lotSize[i];
            int k = i + 1;
            if (k < ROADS - 1) {
                int interior = i; // calle interior 0..22
                int kind = interior == 11 ? CENTRAL : (interior == 2 || interior == 6 || interior == 16 || interior == 20) ? AVENUE : STREET;
                roadKind[k] = kind;
                roadWidth[k] = width(kind);
                roadStart[k] = pos;
                pos += roadWidth[k];
            }
        }
        roadKind[ROADS - 1] = PERIMETER;
        roadWidth[ROADS - 1] = width(PERIMETER);
        roadStart[ROADS - 1] = pos;
        pos += roadWidth[ROADS - 1];
        if (pos != SIZE) throw new IllegalStateException("Trazado inválido: " + pos);
        for (int k = 0; k < ROADS; k++)
            for (int p = 0; p < roadWidth[k]; p++) {
                cellAt[roadStart[k] + p] = -(k + 1);
                posAt[roadStart[k] + p] = p;
            }
        for (int i = 0; i < LOTS; i++)
            for (int p = 0; p < lotSize[i]; p++) {
                cellAt[lotStart[i] + p] = i;
                posAt[lotStart[i] + p] = p;
            }
    }

    public static int width(int kind) {
        return switch (kind) {
            case STREET -> 13;
            case CENTRAL -> 24;
            default -> 23;
        };
    }

    /** Sección transversal de una calle en la posición p. */
    public static int section(int kind, int p) {
        if (kind == STREET) {
            if (p <= 2 || p >= 10) return SW;
            if (p == 6) return CENTER;
            return LANE;
        }
        int w = width(kind);
        if (p <= 2 || p >= w - 3) return SW;
        if (p == 6 || p == w - 7) return DIV;
        int m0 = 10, m1 = kind == CENTRAL ? 13 : 12;
        if (p >= m0 && p <= m1) return MEDIAN;
        return LANE;
    }

    public boolean isLot(int off) {
        return cellAt[off] >= 0;
    }

    public int lotAt(int off) {
        return cellAt[off];
    }

    public int roadAt(int off) {
        return -cellAt[off] - 1;
    }

    public int posAt(int off) {
        return posAt[off];
    }

    public int medianCenter(int k) {
        return roadKind[k] == CENTRAL ? 12 : 11;
    }
}
