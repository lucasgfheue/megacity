package com.megaciudad.core;

import com.megaciudad.core.little.LittleBlock;
import com.megaciudad.core.little.Model;

/**
 * Escritor recortado a una región (normalmente un chunk de 16x16). Todo el generador escribe
 * estructuras completas a través de esto y solo se materializa lo que cae dentro del chunk,
 * así cada chunk se genera de forma independiente y determinista.
 */
public final class Canvas {
    public static final int MIN_Y = -64, MAX_Y = 319;
    public final BlockSink sink;
    public final int x0, z0, x1, z1;

    public Canvas(BlockSink sink, int x0, int z0, int x1, int z1) {
        this.sink = sink;
        this.x0 = x0;
        this.z0 = z0;
        this.x1 = x1;
        this.z1 = z1;
    }

    public boolean contains(int x, int z) {
        return x >= x0 && x <= x1 && z >= z0 && z <= z1;
    }

    public boolean overlaps(int ax0, int az0, int ax1, int az1) {
        int mnx = Math.min(ax0, ax1), mxx = Math.max(ax0, ax1), mnz = Math.min(az0, az1), mxz = Math.max(az0, az1);
        return mxx >= x0 && mnx <= x1 && mxz >= z0 && mnz <= z1;
    }

    public void set(int x, int y, int z, BlockRef b) {
        if (x < x0 || x > x1 || z < z0 || z > z1 || y < MIN_Y || y > MAX_Y) return;
        sink.set(x, y, z, b);
    }

    public void fill(int ax, int ay, int az, int bx, int by, int bz, BlockRef b) {
        int mnx = Math.max(Math.min(ax, bx), x0), mxx = Math.min(Math.max(ax, bx), x1);
        int mnz = Math.max(Math.min(az, bz), z0), mxz = Math.min(Math.max(az, bz), z1);
        int mny = Math.max(Math.min(ay, by), MIN_Y), mxy = Math.min(Math.max(ay, by), MAX_Y);
        if (mnx > mxx || mnz > mxz || mny > mxy) return;
        for (int y = mny; y <= mxy; y++)
            for (int z = mnz; z <= mxz; z++)
                for (int x = mnx; x <= mxx; x++)
                    sink.set(x, y, z, b);
    }

    public void little(int x, int y, int z, LittleBlock lb) {
        if (lb == null || x < x0 || x > x1 || z < z0 || z > z1 || y < MIN_Y || y > MAX_Y) return;
        sink.little(x, y, z, lb);
    }

    public void sign(int x, int y, int z, BlockRef state, String[] lines, String color, boolean glow) {
        if (x < x0 || x > x1 || z < z0 || z > z1 || y < MIN_Y || y > MAX_Y) return;
        sink.sign(x, y, z, state, lines, color, glow);
    }

    /** Coloca un modelo de mini-bloques rotado k veces con su esquina mínima en (wx, y, wz). */
    public void model(Model m, int k, int wx, int y, int wz) {
        k &= 3;
        int sx = (k & 1) == 0 ? m.sx : m.sz;
        int sz = (k & 1) == 0 ? m.sz : m.sx;
        if (!overlaps(wx, wz, wx + sx - 1, wz + sz - 1)) return;
        Model.Compiled c = m.compiled(k);
        for (int by = 0; by < m.sy; by++)
            for (int bz = 0; bz < sz; bz++)
                for (int bx = 0; bx < sx; bx++) {
                    LittleBlock lb = c.blocks[(by * sz + bz) * sx + bx];
                    if (lb != null) little(wx + bx, y + by, wz + bz, lb);
                }
        for (int[] e : c.extras) set(wx + e[0], y + e[1], wz + e[2], BlockRef.byIndex(e[3]));
    }
}
