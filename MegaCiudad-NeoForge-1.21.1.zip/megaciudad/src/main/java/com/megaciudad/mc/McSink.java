package com.megaciudad.mc;

import com.megaciudad.core.BlockRef;
import com.megaciudad.core.BlockSink;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;

/** Escribe la salida del generador en el chunk que se está decorando. */
final class McSink implements BlockSink {
    private static final int FLAGS = 2;
    private final WorldGenLevel level;
    private final ChunkAccess chunk;
    private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

    McSink(WorldGenLevel level, ChunkAccess chunk) {
        this.level = level;
        this.chunk = chunk;
    }

    @Override
    public void set(int x, int y, int z, BlockRef b) {
        BlockState st = McBlocks.state(b);
        pos.set(x, y, z);
        level.setBlock(pos, st, FLAGS);
        if (b.connectable) chunk.markPosForPostprocessing(pos);
    }

    @Override
    public void sign(int x, int y, int z, BlockRef state, String[] lines, String color, boolean glowing) {
        set(x, y, z, state);
        CompoundTag tag = new CompoundTag();
        tag.putString("id", "minecraft:sign");
        tag.putInt("x", x);
        tag.putInt("y", y);
        tag.putInt("z", z);
        tag.putBoolean("is_waxed", true);
        tag.put("front_text", text(lines, color, glowing));
        tag.put("back_text", text(lines, color, glowing));
        chunk.setBlockEntityNbt(tag);
    }

    private static CompoundTag text(String[] lines, String color, boolean glowing) {
        CompoundTag t = new CompoundTag();
        ListTag msgs = new ListTag();
        for (int i = 0; i < 4; i++) {
            String s = i < lines.length && lines[i] != null ? lines[i] : "";
            msgs.add(StringTag.valueOf("{\"text\":\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}"));
        }
        t.put("messages", msgs);
        t.putString("color", color == null ? "black" : color);
        t.putBoolean("has_glowing_text", glowing);
        return t;
    }
}
