package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Industria, depósitos, talleres, estacionamientos, servicentros, gimnasio y estadio. */
public final class FInd {
    private FInd() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    private static final Mat PALLET = c(0xB08D57), PALLET_D = c(0x8A6E40);

    /** Pallet de madera de 14x14 con base en y. */
    private static void pallet(Model m, int x, int y, int z) {
        for (int dz : new int[]{0, 6, 12}) m.box(PALLET_D, x, y, z + dz, x + 14, y + 1, z + dz + 2);
        for (int dx = 0; dx < 14; dx += 3) m.box(PALLET, x + dx, y + 1, z, x + dx + 2, y + 2, z + 14);
    }

    /** Caja de cartón con cinta. */
    private static void box(Model m, int x0, int y0, int z0, int x1, int y1, int z1) {
        m.box(CARDBOARD, x0, y0, z0, x1, y1, z1);
        int mx = (x0 + x1) / 2;
        m.box(c(0xD9C9A3), mx, y1 - 1, z0, mx + 1, y1, z1);
    }

    // ================================================================== depósito

    public static final Model PALLET_RACK = reg(palletRack());

    private static Model palletRack() {
        Model m = new Model("rack_pallets", 3, 3, 1);
        Mat up = c(0xE67E22), beam = c(0x1F618D);
        for (int x : new int[]{0, 23, 46}) {
            m.box(up, x, 0, 1, x + 2, 46, 3);
            m.box(up, x, 0, 13, x + 2, 46, 15);
            m.box(up, x, 20, 3, x + 2, 21, 13);
        }
        Rng r = new Rng(7);
        int[] cols = {0xB88A55, 0x2E86C1, 0x7F8C8D, 0xC0392B};
        for (int lv = 0; lv < 3; lv++) {
            int y = 1 + lv * 15;
            if (lv > 0) {
                m.box(beam, 0, y - 2, 1, 48, y, 3);
                m.box(beam, 0, y - 2, 13, 48, y, 15);
            }
            for (int bay = 0; bay < 2; bay++) {
                int x = 3 + bay * 23;
                if (r.chance(0.15)) continue;
                m.box(PALLET_D, x + 2, y, 2, x + 18, y + 2, 14);
                int h = r.range(6, 11);
                Mat cargo = c(cols[r.nextInt(cols.length)]);
                m.box(cargo, x + 3, y + 2, 2, x + 17, y + 2 + h, 13);
                if (r.chance(0.5)) m.box(c(0xD9C9A3), x + 9, y + 2, 1, x + 11, y + 2 + h, 2);
                else m.box(GLASS_W, x + 3, y + 2, 1, x + 17, y + 2 + h / 2, 2);
            }
        }
        return m;
    }

    public static final Model PALLET_BOXES = reg(palletBoxes());

    private static Model palletBoxes() {
        Model m = new Model("pallet_cajas", 1, 1, 1);
        pallet(m, 1, 0, 1);
        box(m, 1, 2, 1, 8, 8, 8);
        box(m, 8, 2, 1, 15, 8, 8);
        box(m, 1, 2, 8, 8, 8, 15);
        box(m, 8, 2, 8, 15, 8, 15);
        box(m, 2, 8, 2, 14, 14, 14);
        m.box(GLASS_W, 1, 2, 0, 15, 12, 1);
        m.box(GLASS_W, 0, 2, 1, 1, 12, 15);
        return m;
    }

    public static final Model PALLETS = reg(pallets());

    private static Model pallets() {
        Model m = new Model("pallets", 1, 1, 1);
        for (int i = 0; i < 5; i++) pallet(m, 1 + (i % 2), i * 2 + (i > 0 ? 0 : 0), 1);
        return m;
    }

    public static final Model FORKLIFT = reg(forklift());

    private static Model forklift() {
        Model m = new Model("autoelevador", 1, 2, 2);
        Mat y = c(0xF1C40F);
        m.box(y, 1, 2, 9, 15, 10, 30);
        m.box(c(0x2C3E50), 1, 2, 26, 15, 12, 32);
        for (int z : new int[]{11, 26}) {
            m.cylX(BLACK, 3.5, z, 3.5, 0, 3);
            m.cylX(BLACK, 3.5, z, 3.5, 13, 16);
        }
        m.box(BLACK, 4, 10, 17, 12, 13, 24);
        m.box(BLACK, 4, 13, 22, 12, 18, 24);
        for (int[] p : new int[][]{{1, 10}, {14, 10}, {1, 25}, {14, 25}}) m.box(BLACK, p[0], 10, p[1], p[0] + 1, 26, p[1] + 1);
        m.box(BLACK, 1, 26, 10, 15, 27, 26);
        m.box(BLACK, 5, 12, 12, 11, 13, 14);
        m.box(BLACK, 7, 10, 13, 9, 14, 15);
        m.box(c(0x566573), 2, 1, 6, 4, 30, 8);
        m.box(c(0x566573), 12, 1, 6, 14, 30, 8);
        m.box(c(0x566573), 2, 14, 6, 14, 16, 8);
        m.box(STEEL, 3, 1, 0, 5, 2, 7);
        m.box(STEEL, 11, 1, 0, 13, 2, 7);
        m.box(STEEL, 3, 1, 5, 13, 8, 6);
        m.box(c(0xE67E22), 7, 27, 17, 9, 28, 19);
        return m;
    }

    public static final Model CRATES = reg(crates());

    private static Model crates() {
        Model m = new Model("cajones", 1, 1, 1);
        Mat wd = c(0xA67C52), dk = c(0x7A5A3A);
        int[][] cr = {{1, 0, 1, 8}, {8, 0, 6, 7}, {2, 8, 2, 7}};
        for (int[] q : cr) {
            int x = q[0], y = q[1], z = q[2], s = q[3];
            m.box(wd, x, y, z, x + s, y + s, z + s);
            m.box(dk, x, y, z - 0, x + s, y + 1, z + 1 > z + s ? z + s : z + 1);
            m.box(dk, x, y + s - 1, z, x + s, y + s, z + 1);
            m.box(dk, x, y, z, x + 1, y + s, z + 1);
            m.box(dk, x + s - 1, y, z, x + s, y + s, z + 1);
            for (int i = 0; i < s; i++) m.box(dk, x + i, y + i, z, x + i + 1, y + i + 1, z + 1);
        }
        return m;
    }

    public static final Model DRUMS = reg(drums());

    private static Model drums() {
        Model m = new Model("tambores", 1, 1, 1);
        pallet(m, 1, 0, 1);
        int[] cols = {0x1F618D, 0xC0392B, 0x1F618D, 0x1E8449};
        for (int i = 0; i < 4; i++) {
            double x = 4.5 + (i % 2) * 7, z = 4.5 + (i / 2) * 7;
            m.cylY(c(cols[i]), x, z, 3.2, 2, 15);
            m.cylY(c(0x2C3E50), x, z, 3.3, 6, 7);
            m.cylY(c(0x2C3E50), x, z, 3.3, 11, 12);
            m.box(STEEL, (int) x, 15, (int) z - 1, (int) x + 1, 16, (int) z);
        }
        return m;
    }

    public static final Model WORKBENCH = reg(workbench());

    private static Model workbench() {
        Model m = new Model("banco_trabajo", 2, 2, 1);
        m.box(c(0x9C6B30), 0, 13, 1, 32, 15, 14);
        legs(m, c(0x566573), 1, 2, 31, 13, 0, 13, 2);
        m.box(c(0x566573), 1, 3, 2, 31, 4, 13);
        m.box(c(0xA67C52), 0, 15, 14, 32, 32, 16);
        for (int x = 2; x < 32; x += 3)
            for (int y = 17; y < 32; y += 3) m.box(c(0x7A5A3A), x, y, 13, x + 1, y + 1, 14);
        m.box(c(0x1F618D), 2, 15, 3, 8, 19, 9);
        m.box(STEEL, 4, 19, 4, 6, 21, 8);
        m.box(STEEL, 8, 16, 5, 9, 17, 7);
        m.box(RED, 14, 15, 5, 22, 18, 10);
        m.box(BLACK, 14, 18, 7, 22, 19, 8);
        m.box(WALNUT, 4, 20, 12, 5, 28, 13);
        m.box(STEEL, 2, 27, 12, 7, 29, 13);
        m.box(STEEL, 11, 20, 12, 12, 29, 13);
        m.box(RED, 15, 22, 12, 21, 24, 13);
        m.box(STEEL, 21, 22, 12, 28, 23, 13);
        m.box(c(0xF39C12), 24, 16, 6, 29, 19, 11);
        m.box(BLACK, 26, 19, 7, 28, 22, 9);
        return m;
    }

    public static final Model TOOL_CHEST = reg(toolChest());

    private static Model toolChest() {
        Model m = new Model("carro_herramientas", 1, 1, 1);
        m.box(RED, 1, 1, 3, 15, 15, 14);
        drawers(m, c(0xE74C3C), STEEL, 2, 14, 2, 15, 5, 2);
        for (int[] p : new int[][]{{2, 4}, {12, 4}, {2, 11}, {12, 11}}) m.box(BLACK, p[0], 0, p[1], p[0] + 2, 1, p[1] + 2);
        m.box(STEEL, 1, 15, 3, 15, 16, 14);
        m.box(STEEL, 15, 9, 5, 16, 10, 12);
        return m;
    }

    public static final Model LATHE = reg(lathe());

    private static Model lathe() {
        Model m = new Model("torno", 2, 1, 1);
        Mat g = c(0x52796F);
        m.box(g, 1, 0, 4, 7, 9, 13);
        m.box(g, 25, 0, 4, 31, 9, 13);
        m.box(g, 1, 9, 5, 31, 11, 12);
        m.box(g, 1, 11, 4, 9, 16, 13);
        m.cylX(STEEL, 13, 8.5, 2.5, 9, 11);
        m.cylX(STEEL, 13, 8.5, 0.8, 11, 22);
        m.box(g, 22, 11, 5, 27, 15, 12);
        m.cylX(STEEL, 13, 8.5, 0.6, 18, 22);
        m.box(STEEL, 14, 11, 3, 18, 13, 10);
        m.box(BLACK, 3, 12, 3, 7, 15, 4);
        m.box(RED, 4, 13, 2, 5, 14, 3);
        m.box(c(0xF4D03F), 1, 1, 3, 31, 2, 4);
        return m;
    }

    public static final Model DRILL_PRESS = reg(drillPress());

    private static Model drillPress() {
        Model m = new Model("taladro_banco", 1, 2, 1);
        Mat g = c(0x2471A3);
        m.box(g, 3, 0, 4, 13, 2, 14);
        m.cylY(STEEL, 8, 11, 1.4, 2, 28);
        m.box(g, 4, 11, 4, 12, 12, 10);
        m.box(g, 4, 22, 5, 12, 29, 14);
        m.box(BLACK, 6, 29, 6, 10, 31, 13);
        m.cylY(STEEL, 8, 7, 1, 17, 22);
        m.box(STEEL, 7, 16, 6, 9, 17, 8);
        for (int k = 0; k < 3; k++) m.box(BLACK, 12, 24 + k * 2, 7, 15, 25 + k * 2, 8);
        return m;
    }

    public static final Model CONVEYOR = reg(conveyor());

    private static Model conveyor() {
        Model m = new Model("cinta_transportadora", 3, 1, 1);
        for (int x : new int[]{2, 22, 44}) {
            m.box(STEEL, x, 0, 3, x + 2, 9, 4);
            m.box(STEEL, x, 0, 12, x + 2, 9, 13);
        }
        m.box(c(0x566573), 0, 8, 2, 48, 10, 14);
        m.box(BLACK, 0, 10, 3, 48, 11, 13);
        for (int x = 1; x < 48; x += 4) m.box(c(0x2C3E50), x, 10, 3, x + 1, 11, 13);
        m.box(c(0xF4D03F), 0, 10, 2, 48, 11, 3);
        m.box(c(0xF4D03F), 0, 10, 13, 48, 11, 14);
        box(m, 6, 11, 5, 13, 16, 11);
        box(m, 27, 11, 4, 36, 15, 12);
        return m;
    }

    public static final Model CONTROL_PANEL = reg(controlPanel());

    private static Model controlPanel() {
        Model m = new Model("tablero_control", 1, 2, 1);
        Mat g = c(0x7F8C8D);
        m.box(g, 1, 0, 6, 15, 30, 15);
        m.box(g, 1, 12, 2, 15, 15, 15);
        for (int i = 0; i < 3; i++) m.box(g, 1, 15 + i, 3 + i * 2 - 1, 15, 16 + i, 15);
        m.box(BLACK, 3, 19, 5, 13, 26, 6);
        m.box(c(0x17A589), 4, 20, 4, 12, 25, 5);
        int[] lights = {0x2ECC71, 0xE74C3C, 0xF4D03F, 0x2ECC71, 0x3498DB};
        for (int i = 0; i < 5; i++) m.box(i % 2 == 0 ? GREEN_LIT : c(lights[i]), 3 + i * 2, 14, 2, 4 + i * 2, 15, 3);
        m.box(RED, 11, 15, 2, 13, 16, 4);
        m.box(STEEL, 4, 3, 5, 12, 4, 6);
        m.box(c(0xF4D03F), 1, 27, 5, 15, 30, 6);
        return m;
    }

    public static final Model GENERATOR = reg(generator());

    private static Model generator() {
        Model m = new Model("generador", 2, 1, 1);
        Mat y = c(0xF1C40F);
        m.box(BLACK, 1, 0, 2, 31, 2, 14);
        m.box(y, 2, 2, 3, 30, 13, 13);
        for (int x = 6; x < 18; x += 2) m.box(c(0x2C3E50), x, 4, 2, x + 1, 11, 3);
        m.box(BLACK, 21, 5, 2, 28, 11, 3);
        m.box(GREEN_LIT, 22, 9, 1, 24, 10, 2);
        m.box(RED, 25, 6, 1, 27, 8, 2);
        m.cylY(c(0x5D6D7E), 26, 10, 1.4, 13, 16);
        m.box(BLACK, 4, 13, 5, 10, 14, 11);
        return m;
    }

    public static final Model GAS_CYL = reg(gasCylinders());

    private static Model gasCylinders() {
        Model m = new Model("garrafas", 1, 1, 1);
        int[] cols = {0x1F618D, 0xF4D03F, 0x1E8449, 0xC0392B};
        for (int i = 0; i < 4; i++) {
            double x = 3 + i * 3.4;
            m.cylY(c(cols[i]), x, 11, 1.6, 0, 14);
            m.box(STEEL, (int) x, 14, 10, (int) x + 1, 16, 12);
        }
        m.box(c(0x566573), 1, 8, 13, 15, 9, 15);
        m.box(c(0x566573), 1, 0, 14, 15, 13, 15);
        return m;
    }

    public static final Model HAND_TRUCK = reg(handTruck());

    private static Model handTruck() {
        Model m = new Model("zorra", 1, 1, 1);
        m.box(RED, 3, 1, 12, 4, 16, 13);
        m.box(RED, 12, 1, 12, 13, 16, 13);
        for (int y = 4; y < 15; y += 5) m.box(RED, 3, y, 12, 13, y + 1, 13);
        m.box(STEEL, 3, 0, 5, 13, 1, 13);
        m.cylX(BLACK, 2.5, 13, 2.4, 1, 3);
        m.cylX(BLACK, 2.5, 13, 2.4, 13, 15);
        box(m, 4, 1, 5, 12, 7, 12);
        box(m, 5, 7, 6, 11, 12, 12);
        return m;
    }

    public static final Model ELECTRIC_CAB = reg(electricCabinet());

    private static Model electricCabinet() {
        Model m = new Model("tablero_electrico", 1, 2, 1);
        m.box(c(0xB3B6B7), 1, 0, 9, 15, 30, 16);
        m.box(c(0xC7CACB), 2, 1, 8, 14, 29, 9);
        m.box(BLACK, 12, 13, 7, 13, 17, 8);
        for (int y = 2; y < 6; y++) m.box(c(0x7F8C8D), 4, y * 2, 7, 10, y * 2 + 1, 8);
        m.box(YELLOW, 5, 20, 7, 11, 25, 8);
        m.box(BLACK, 7, 21, 6, 9, 24, 7);
        m.box(BLACK, 8, 22, 6, 9, 23, 7);
        return m;
    }

    public static final Model WELDER = reg(welder());

    private static Model welder() {
        Model m = new Model("soldadora", 1, 1, 1);
        m.box(c(0x2471A3), 3, 2, 4, 13, 11, 13);
        m.cylX(BLACK, 2, 5, 2, 2, 3);
        m.cylX(BLACK, 2, 5, 2, 13, 14);
        m.box(BLACK, 4, 6, 3, 9, 10, 4);
        m.box(c(0xE74C3C), 10, 7, 3, 12, 9, 4);
        m.box(STEEL, 6, 11, 7, 10, 12, 10);
        for (int i = 0; i < 6; i++) m.box(BLACK, 12 - i, 1 + (i % 2), 12 - i, 13 - i, 2 + (i % 2), 13 - i);
        m.box(c(0x2C3E50), 4, 11, 9, 10, 15, 13);
        m.box(GLASS_G, 5, 13, 8, 9, 14, 9);
        return m;
    }

    public static final Model CNC = reg(cnc());

    private static Model cnc() {
        Model m = new Model("centro_mecanizado", 2, 2, 1);
        m.box(c(0xD0D3D4), 0, 0, 2, 32, 28, 16);
        m.box(c(0x2471A3), 0, 0, 1, 32, 4, 2);
        m.box(c(0x2471A3), 0, 26, 1, 32, 28, 2);
        m.box(GLASS_G, 3, 8, 1, 21, 24, 2);
        m.box(STEEL, 10, 14, 4, 13, 24, 6);
        m.box(c(0x566573), 6, 8, 3, 18, 10, 12);
        m.box(BLACK, 23, 10, 1, 31, 24, 2);
        m.box(c(0x17A589), 24, 17, 0, 30, 22, 1);
        for (int y = 11; y < 16; y += 2) m.box(c(0xF4D03F), 24, y, 0, 30, y + 1, 1);
        m.box(RED, 26, 28, 7, 29, 30, 10);
        m.box(GREEN_LIT, 26, 30, 7, 29, 31, 10);
        return m;
    }

    public static final Model ROBOT_ARM = reg(robotArm());

    private static Model robotArm() {
        Model m = new Model("brazo_robot", 1, 2, 1);
        Mat o = c(0xE67E22);
        m.box(c(0x566573), 2, 0, 2, 14, 3, 14);
        m.cylY(o, 8, 8, 4, 3, 7);
        m.box(o, 6, 7, 6, 10, 18, 10);
        m.cylX(c(0x2C3E50), 18, 8, 2.6, 5, 11);
        m.box(o, 6, 16, 2, 10, 20, 9);
        m.box(o, 6, 18, 1, 10, 26, 5);
        m.cylX(c(0x2C3E50), 25, 3, 2, 5, 11);
        m.box(c(0x2C3E50), 7, 26, 2, 9, 30, 4);
        m.box(STEEL, 6, 28, 0, 7, 30, 4);
        m.box(STEEL, 9, 28, 0, 10, 30, 4);
        return m;
    }

    public static final Model BOX_STACK = reg(boxStack());

    private static Model boxStack() {
        Model m = new Model("cajas_carton", 1, 2, 1);
        box(m, 1, 0, 2, 15, 9, 14);
        box(m, 2, 9, 3, 13, 17, 13);
        box(m, 3, 17, 4, 12, 24, 12);
        m.box(c(0x1F618D), 5, 3, 1, 11, 5, 2);
        m.box(BLACK, 6, 12, 2, 10, 13, 3);
        m.box(RED, 5, 19, 3, 10, 21, 4);
        return m;
    }

    public static final Model TIRES = reg(tires());

    private static Model tires() {
        Model m = new Model("neumaticos", 1, 1, 1);
        for (int i = 0; i < 4; i++) {
            m.cylY(c(0x1C1C1C), 8, 8, 6, i * 4, i * 4 + 3);
            m.cylY(c(0x2E2E2E), 8, 8, 6.1, i * 4 + 1, i * 4 + 2);
            m.cylY(null, 8, 8, 3, i * 4, i * 4 + 3);
        }
        return m;
    }

    // ================================================================== estacionamiento y servicentro

    public static final Model EV_CHARGER = reg(evCharger());

    private static Model evCharger() {
        Model m = new Model("cargador_electrico", 1, 2, 1);
        m.box(c(0xD5D8DC), 3, 0, 6, 13, 2, 12);
        m.box(WHITE, 4, 2, 7, 12, 28, 11);
        m.box(c(0x27AE60), 4, 25, 6, 12, 28, 7);
        m.box(BLACK, 5, 16, 6, 11, 22, 7);
        m.box(c(0x58D68D), 6, 17, 5, 10, 21, 6);
        m.box(BLACK, 12, 12, 8, 14, 15, 10);
        for (int i = 0; i < 6; i++) m.box(BLACK, 13, 3 + i * 2, 9 - (i % 2), 14, 5 + i * 2, 10 - (i % 2));
        m.box(LIGHT, 7, 28, 8, 9, 29, 10);
        return m;
    }

    public static final Model PAY_STATION = reg(payStation());

    private static Model payStation() {
        Model m = new Model("cajero_estacionamiento", 1, 2, 1);
        m.box(c(0x1F618D), 2, 0, 4, 14, 28, 13);
        m.box(BLACK, 4, 18, 3, 12, 24, 4);
        m.box(c(0x5DADE2), 5, 19, 2, 11, 23, 3);
        m.box(STEEL, 4, 12, 3, 12, 16, 4);
        m.box(BLACK, 5, 8, 3, 11, 9, 4);
        m.box(WHITE, 4, 25, 3, 12, 27, 4);
        Kit.text(m, "P", c(0x1F618D), 8, 27, 2, 1);
        return m;
    }

    public static final Model OIL_RACK = reg(oilRack());

    private static Model oilRack() {
        Model m = new Model("exhibidor_aceites", 1, 2, 1);
        m.box(c(0xC0392B), 0, 0, 6, 1, 28, 16);
        m.box(c(0xC0392B), 15, 0, 6, 16, 28, 16);
        m.box(c(0xC0392B), 0, 26, 6, 16, 30, 16);
        m.box(WHITE, 2, 27, 5, 14, 29, 6);
        int[] cols = {0xF4D03F, 0x1F618D, 0x2C3E50, 0x27AE60};
        for (int lv = 0; lv < 4; lv++) {
            int y = 1 + lv * 6;
            m.box(STEEL, 1, y - 1, 6, 15, y, 16);
            for (int x = 2; x < 14; x += 4) {
                m.box(c(cols[lv]), x, y, 8, x + 3, y + 5, 12);
                m.box(BLACK, x + 1, y + 5, 9, x + 2, y + 6, 10);
            }
        }
        return m;
    }

    public static final Model AIR_PUMP = reg(airPump());

    private static Model airPump() {
        Model m = new Model("inflador", 1, 1, 1);
        m.box(c(0x2471A3), 3, 0, 5, 13, 15, 12);
        m.box(BLACK, 5, 9, 4, 11, 13, 5);
        m.box(GREEN_LIT, 6, 11, 3, 10, 12, 4);
        m.box(WHITE, 4, 14, 4, 12, 15, 5);
        for (int i = 0; i < 5; i++) m.box(BLACK, 13 + (i % 2), 3 + i * 2, 7, 14 + (i % 2), 5 + i * 2, 8);
        m.box(STEEL, 6, 5, 4, 10, 7, 5);
        return m;
    }

    public static final Model ICE_CHEST = reg(iceChest());

    private static Model iceChest() {
        Model m = new Model("conservadora_hielo", 1, 1, 1);
        m.box(WHITE, 1, 0, 2, 15, 14, 15);
        m.box(c(0x2E86C1), 1, 4, 1, 15, 10, 2);
        m.box(WHITE, 3, 5, 0, 5, 9, 1);
        m.box(WHITE, 7, 5, 0, 9, 9, 1);
        m.box(WHITE, 11, 5, 0, 13, 9, 1);
        m.box(STEEL, 6, 12, 1, 10, 13, 2);
        m.box(c(0xD6EAF8), 1, 14, 2, 15, 15, 15);
        return m;
    }

    // ================================================================== gimnasio

    public static final Model TREADMILL = reg(treadmill());

    private static Model treadmill() {
        Model m = new Model("cinta_correr", 1, 1, 2);
        m.box(c(0x2C3E50), 1, 0, 6, 15, 3, 32);
        m.box(BLACK, 3, 3, 8, 13, 4, 31);
        m.box(c(0x566573), 1, 3, 6, 3, 4, 32);
        m.box(c(0x566573), 13, 3, 6, 15, 4, 32);
        m.box(STEEL, 1, 3, 3, 2, 14, 5);
        m.box(STEEL, 14, 3, 3, 15, 14, 5);
        m.box(c(0x2C3E50), 1, 13, 1, 15, 16, 5);
        m.box(c(0x17A589), 4, 14, 0, 12, 16, 1);
        m.box(STEEL, 1, 10, 5, 2, 11, 12);
        m.box(STEEL, 14, 10, 5, 15, 11, 12);
        return m;
    }

    public static final Model EXERCISE_BIKE = reg(exerciseBike());

    private static Model exerciseBike() {
        Model m = new Model("bici_fija", 1, 1, 1);
        m.box(c(0x2C3E50), 6, 0, 1, 10, 2, 15);
        m.box(c(0x2C3E50), 3, 0, 1, 13, 1, 3);
        m.box(c(0x2C3E50), 3, 0, 13, 13, 1, 15);
        m.cylX(c(0x566573), 6, 4.5, 3.5, 7, 9);
        m.box(RED, 7, 2, 7, 9, 10, 9);
        m.box(BLACK, 6, 10, 7, 10, 11, 12);
        m.box(c(0x2C3E50), 7, 2, 3, 9, 14, 5);
        m.box(STEEL, 4, 13, 2, 12, 14, 4);
        m.box(BLACK, 6, 14, 3, 10, 16, 4);
        m.box(STEEL, 5, 5, 8, 6, 6, 11);
        m.box(STEEL, 10, 5, 8, 11, 6, 11);
        return m;
    }

    public static final Model BENCH_PRESS = reg(benchPress());

    private static Model benchPress() {
        Model m = new Model("banco_pesas", 1, 2, 2);
        m.box(BLACK, 5, 6, 4, 11, 8, 26);
        legs(m, STEEL, 6, 5, 10, 25, 0, 6, 1);
        for (int x : new int[]{1, 14}) {
            m.box(STEEL, x, 0, 22, x + 1, 22, 23);
            m.box(STEEL, x, 0, 18, x + 1, 1, 27);
            m.box(STEEL, x - 1 < 0 ? 0 : x - 1, 17, 21, x + 2 > 16 ? 16 : x + 2, 18, 23);
        }
        m.cylX(STEEL, 18.5, 22, 0.7, 0, 16);
        m.cylX(BLACK, 18.5, 22, 3.5, 0, 2);
        m.cylX(BLACK, 18.5, 22, 3.5, 14, 16);
        return m;
    }

    public static final Model DUMBBELLS = reg(dumbbells());

    private static Model dumbbells() {
        Model m = new Model("mancuernero", 2, 1, 1);
        m.box(BLACK, 1, 0, 4, 3, 10, 12);
        m.box(BLACK, 29, 0, 4, 31, 10, 12);
        m.box(BLACK, 1, 5, 4, 31, 6, 12);
        m.box(BLACK, 1, 9, 6, 31, 10, 12);
        for (int x = 4; x < 28; x += 5) {
            int r = 1 + (x / 5) % 2;
            m.cylZ(STEEL, x + 1, 7.5, 0.6, 4, 12);
            m.cylZ(c(0x2C3E50), x + 1, 7.5, 1.6 + r * 0.3, 4, 6);
            m.cylZ(c(0x2C3E50), x + 1, 7.5, 1.6 + r * 0.3, 10, 12);
            m.cylZ(STEEL, x + 1, 11.5, 0.6, 4, 12);
            m.cylZ(c(0x922B21), x + 1, 11.5, 1.4, 4, 6);
            m.cylZ(c(0x922B21), x + 1, 11.5, 1.4, 10, 12);
        }
        return m;
    }

    public static final Model PUNCHING_BAG = reg(punchingBag());

    private static Model punchingBag() {
        Model m = new Model("bolsa_boxeo", 1, 2, 1);
        m.box(STEEL, 7, 26, 7, 9, 32, 9);
        m.box(STEEL, 5, 24, 7, 11, 26, 9);
        m.cylY(c(0x922B21), 8, 8, 4, 6, 24);
        m.cylY(BLACK, 8, 8, 4.1, 20, 21);
        m.cylY(BLACK, 8, 8, 4.1, 9, 10);
        m.cylY(c(0x922B21), 8, 8, 3, 5, 6);
        return m;
    }

    // ================================================================== estadio

    public static final Model TEAM_BENCH = reg(teamBench());

    private static Model teamBench() {
        Model m = new Model("banco_suplentes", 3, 2, 1);
        m.box(c(0xD5D8DC), 0, 0, 14, 48, 26, 16);
        m.box(c(0xD5D8DC), 0, 0, 2, 2, 26, 16);
        m.box(c(0xD5D8DC), 46, 0, 2, 48, 26, 16);
        for (int i = 0; i < 6; i++) {
            int x = 3 + i * 7;
            m.box(c(0x1F618D), x, 5, 6, x + 6, 7, 13);
            m.box(c(0x1F618D), x, 7, 12, x + 6, 14, 14);
            m.box(STEEL, x + 2, 0, 8, x + 4, 5, 10);
        }
        for (int z = 1; z < 16; z++) {
            int y = 26 - (z < 4 ? 0 : 0);
            m.box(GLASS_W, 0, y, z, 48, y + 1, z + 1);
        }
        m.box(c(0xD5D8DC), 0, 26, 0, 48, 28, 2);
        m.box(STEEL, 0, 27, 13, 48, 28, 16);
        return m;
    }

    public static final Model CONCESSION = reg(concession());

    private static Model concession() {
        Model m = new Model("puesto_comida", 2, 2, 1);
        m.box(c(0xE5E7E9), 0, 0, 4, 32, 14, 16);
        m.box(c(0xC0392B), 0, 2, 3, 32, 6, 4);
        m.box(BIRCH, 0, 14, 2, 32, 15, 16);
        m.box(c(0xE5E7E9), 0, 15, 15, 32, 28, 16);
        m.box(STEEL, 0, 15, 2, 1, 26, 3);
        m.box(STEEL, 31, 15, 2, 32, 26, 3);
        for (int x = 0; x < 32; x += 4) {
            m.box(x % 8 == 0 ? RED : WHITE, x, 26, 0, x + 4, 28, 3);
            m.box(x % 8 == 0 ? RED : WHITE, x, 28, 2, x + 4, 30, 16);
        }
        m.box(c(0xF4D03F), 3, 15, 8, 9, 16, 12);
        m.ellipsoid(c(0xB9572A), 6, 16.5, 10, 2.5, 0.8, 1);
        m.cylY(c(0xC0392B), 14, 9, 1.3, 15, 19);
        m.cylY(c(0xF4D03F), 17, 9, 1.3, 15, 19);
        m.box(BLACK, 21, 15, 9, 30, 21, 14);
        m.box(c(0x5DADE2), 22, 19, 8, 29, 20, 9);
        m.box(c(0x922B21), 0, 17, 14, 32, 25, 15);
        Kit.text(m, "BAR", c(0xF4D03F), 16, 24, 13, 1);
        return m;
    }
}
