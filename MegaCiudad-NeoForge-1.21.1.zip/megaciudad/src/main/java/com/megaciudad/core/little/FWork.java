package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Oficinas, escuelas, salud, edificios públicos, culto, transporte y servicios de emergencia. */
public final class FWork {
    private FWork() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    /** Silla de oficina (16x16) con respaldo hacia dir (0 = respaldo al norte ... como Kit.chairDir invertido). */
    private static void officeChair(Model m, int ox, int oz, Mat seat, int backSide) {
        m.box(BLACK, ox + 3, 0, oz + 7, ox + 13, 1, oz + 9);
        m.box(BLACK, ox + 7, 0, oz + 3, ox + 9, 1, oz + 13);
        m.box(STEEL, ox + 7, 1, oz + 7, ox + 9, 5, oz + 9);
        m.box(seat, ox + 3, 5, oz + 3, ox + 13, 7, oz + 13);
        switch (backSide) {
            case 0 -> m.box(seat, ox + 3, 7, oz + 2, ox + 13, 14, oz + 4);
            case 1 -> m.box(seat, ox + 12, 7, oz + 3, ox + 14, 14, oz + 13);
            case 2 -> m.box(seat, ox + 3, 7, oz + 12, ox + 13, 14, oz + 14);
            default -> m.box(seat, ox + 2, 7, oz + 3, ox + 4, 14, oz + 13);
        }
    }

    // ================================================================== oficina

    public static final Model WORKSTATION = reg(workstation());

    private static Model workstation() {
        Model m = new Model("puesto_trabajo", 2, 1, 2);
        Mat top = c(0xF4F1EA);
        m.box(top, 0, 9, 17, 32, 10, 31);
        m.box(LGRAY, 0, 0, 17, 1, 9, 31);
        m.box(LGRAY, 31, 0, 17, 32, 9, 31);
        m.box(LGRAY, 22, 0, 18, 30, 9, 30);
        m.box(c(0xB0B6BB), 22, 1, 17, 30, 8, 18);
        m.box(w(0x7F8C8D), 0, 9, 31, 32, 16, 32);
        for (int[] s : new int[][]{{3, 14}, {17, 28}}) {
            m.box(BLACK, (s[0] + s[1]) / 2 - 1, 10, 26, (s[0] + s[1]) / 2 + 1, 12, 28);
            screen(m, s[0], 11, s[1], 16, 25, 1, c(0x2E86C1));
            m.box(c(0xD6EAF8), s[0] + 2, 13, 25, s[1] - 2, 14, 26);
        }
        m.box(c(0x2C3E50), 8, 10, 20, 20, 11, 23);
        m.box(BLACK, 22, 10, 21, 24, 11, 23);
        m.box(c(0xF5F5F5), 4, 10, 19, 6, 12, 21);
        officeChair(m, 8, 2, c(0x2C3E50), 0);
        return m;
    }

    public static final Model DESK_SIMPLE = reg(deskSimple());

    private static Model deskSimple() {
        Model m = new Model("escritorio_simple", 2, 1, 1);
        m.box(WHITE, 0, 9, 2, 32, 10, 16);
        for (int x : new int[]{1, 29}) {
            m.box(BLACK, x, 0, 3, x + 2, 9, 4);
            m.box(BLACK, x, 0, 14, x + 2, 9, 15);
            m.box(BLACK, x, 0, 3, x + 2, 1, 15);
        }
        m.box(c(0x7F8C8D), 10, 10, 6, 22, 11, 12);
        m.box(c(0x7F8C8D), 10, 11, 11, 22, 16, 12);
        m.box(c(0x5DADE2), 11, 12, 10, 21, 15, 11);
        m.box(c(0xF7DC6F), 2, 10, 4, 7, 11, 10);
        m.cylY(c(0x2C3E50), 26, 12, 1.5, 10, 13);
        m.box(RED, 25, 13, 11, 26, 15, 12);
        m.box(BLUE, 27, 13, 12, 28, 15, 13);
        return m;
    }

    public static final Model EXEC_DESK = reg(execDesk());

    private static Model execDesk() {
        Model m = new Model("escritorio_ejecutivo", 3, 1, 2);
        m.box(WALNUT, 1, 11, 3, 47, 13, 19);
        m.box(c(0x1E4D2B), 5, 13, 6, 43, 14, 17);
        m.box(WALNUT, 1, 0, 3, 47, 11, 5);
        for (int x : new int[]{4, 18, 32}) m.box(c(0x5A4030), x, 2, 2, x + 12, 9, 3);
        m.box(WALNUT, 1, 0, 5, 9, 11, 19);
        m.box(WALNUT, 39, 0, 5, 47, 11, 19);
        m.box(GOLD, 20, 13, 4, 28, 15, 5);
        m.box(BLACK, 21, 14, 3, 27, 15, 4);
        m.box(BLACK, 22, 13, 9, 26, 14, 12);
        m.box(BLACK, 23, 14, 9, 25, 16, 10);
        m.box(c(0x1F618D), 22, 14, 10, 26, 16, 11);
        m.box(GOLD, 9, 13, 14, 11, 16, 16);
        m.box(c(0x1E8449), 6, 14, 12, 14, 16, 16);
        m.box(BLACK, 34, 13, 12, 40, 14, 16);
        m.box(WHITE, 30, 13, 8, 34, 14, 12);
        return m;
    }

    public static final Model EXEC_CHAIR = reg(execChair());

    private static Model execChair() {
        Model m = new Model("sillon_ejecutivo", 1, 1, 1);
        m.box(BLACK, 3, 0, 7, 13, 1, 9);
        m.box(BLACK, 7, 0, 3, 9, 1, 13);
        m.box(STEEL, 7, 1, 7, 9, 5, 9);
        m.box(LEATHER_D, 3, 5, 3, 13, 8, 13);
        m.box(LEATHER_D, 3, 8, 11, 13, 16, 14);
        m.box(c(0x3A3230), 5, 10, 10, 11, 15, 11);
        m.box(STEEL, 2, 8, 5, 3, 10, 11);
        m.box(STEEL, 13, 8, 5, 14, 10, 11);
        m.box(LEATHER_D, 2, 10, 5, 3, 11, 11);
        m.box(LEATHER_D, 13, 10, 5, 14, 11, 11);
        return m;
    }

    public static final Model CONF_TABLE = reg(confTable());

    private static Model confTable() {
        Model m = new Model("mesa_reuniones", 4, 1, 2);
        m.box(WALNUT, 3, 9, 9, 61, 11, 23);
        m.box(BLACK, 12, 0, 13, 16, 9, 19);
        m.box(BLACK, 48, 0, 13, 52, 9, 19);
        m.box(BLACK, 10, 0, 12, 18, 1, 20);
        m.box(BLACK, 46, 0, 12, 54, 1, 20);
        int[] xs = {7, 20, 36, 49};
        for (int x : xs) {
            officeChair(m, x - 4, 0, BLACK, 0);
            officeChair(m, x - 4, 16, BLACK, 2);
            m.box(c(0x7F8C8D), x - 3, 11, 11, x + 3, 12, 14);
            m.box(c(0x7F8C8D), x - 3, 11, 18, x + 3, 12, 21);
            m.box(WHITE, x + 4, 11, 12, x + 7, 12, 15);
        }
        for (int x = 14; x < 56; x += 12) m.cylY(GLASS_B, x, 16, 1, 11, 15);
        return m;
    }

    public static final Model CONF_ROUND = reg(confRound());

    private static Model confRound() {
        Model m = new Model("mesa_reunion_chica", 2, 1, 2);
        m.cylY(WHITE, 16, 16, 8.5, 9, 11);
        m.cylY(STEEL, 16, 16, 1.6, 1, 9);
        m.cylY(STEEL, 16, 16, 5, 0, 1);
        officeChair(m, 8, 0, c(0x5D6D7E), 0);
        officeChair(m, 8, 16, c(0x5D6D7E), 2);
        officeChair(m, 0, 8, c(0x5D6D7E), 3);
        officeChair(m, 16, 8, c(0x5D6D7E), 1);
        m.cylY(c(0x2C3E50), 16, 16, 8.5, 9, 11);
        m.cylY(WHITE, 16, 16, 8.0, 10, 11);
        m.box(c(0x7F8C8D), 12, 11, 12, 18, 12, 16);
        cup(m, c(0xE74C3C), 19, 11, 18);
        return m;
    }

    public static final Model FILE_CABINET = reg(fileCabinet());

    private static Model fileCabinet() {
        Model m = new Model("archivero", 1, 1, 1);
        m.box(c(0x8E9AA3), 2, 0, 3, 14, 16, 15);
        drawers(m, c(0xA5B1BA), BLACK, 3, 13, 1, 16, 4, 2);
        for (int y = 2; y < 16; y += 4) m.box(WHITE, 6, y + 1, 1, 10, y + 2, 2);
        return m;
    }

    public static final Model BINDER_SHELF = reg(binderShelf());

    private static Model binderShelf() {
        Model m = new Model("estante_biblioratos", 1, 2, 1);
        Mat g = c(0x8E9AA3);
        m.box(g, 0, 0, 4, 1, 31, 16);
        m.box(g, 15, 0, 4, 16, 31, 16);
        m.box(g, 1, 0, 15, 15, 31, 16);
        Rng r = new Rng(7);
        int[] cols = {0xC0392B, 0x2471A3, 0x1E8449, 0xD4AC0D, 0x7D3C98, 0x2C3E50};
        for (int y : new int[]{0, 10, 20, 30}) m.box(g, 1, y, 4, 15, y + 1, 16);
        for (int y : new int[]{1, 11, 21}) {
            int col = r.nextInt(cols.length);
            for (int x = 1; x < 15; x += 2) {
                if (r.chance(0.12)) continue;
                m.box(c(cols[col]), x, y, 5, x + 2, y + 8, 15);
                m.box(WHITE, x, y + 4, 4, x + 2, y + 6, 5);
                if (r.chance(0.3)) col = r.nextInt(cols.length);
            }
        }
        return m;
    }

    public static final Model WATER_COOLER = reg(waterCooler());

    private static Model waterCooler() {
        Model m = new Model("dispensador_agua", 1, 2, 1);
        m.box(WHITE, 4, 0, 5, 12, 17, 13);
        m.box(LGRAY, 5, 8, 4, 11, 9, 5);
        m.box(BLUE, 5, 13, 4, 7, 15, 5);
        m.box(RED, 9, 13, 4, 11, 15, 5);
        m.box(BLACK, 5, 8, 3, 11, 9, 4);
        m.cylY(g(0x5DADE2, 150), 8, 9, 3.6, 17, 28);
        m.cylY(g(0x5DADE2, 150), 8, 9, 1.4, 28, 30);
        m.cylY(BLUE, 8, 9, 1.5, 30, 31);
        m.cylY(WHITE, 13.5, 9, 1.2, 9, 16);
        return m;
    }

    public static final Model PRINTER = reg(printer());

    private static Model printer() {
        Model m = new Model("impresora", 1, 1, 1);
        m.box(c(0x5D6D7E), 2, 0, 3, 14, 8, 14);
        m.box(c(0xD5D8DC), 2, 8, 3, 14, 14, 14);
        m.box(c(0x34495E), 3, 13, 5, 13, 14, 12);
        m.box(WHITE, 4, 14, 6, 12, 15, 11);
        m.box(BLACK, 4, 10, 2, 9, 11, 3);
        m.box(GREEN_LIT, 11, 12, 2, 12, 13, 3);
        m.box(c(0xC7CBCF), 3, 9, 2, 13, 10, 3);
        return m;
    }

    public static final Model COPIER = reg(copier());

    private static Model copier() {
        Model m = new Model("fotocopiadora", 1, 1, 1);
        m.box(c(0xE5E7E9), 1, 0, 2, 15, 13, 15);
        drawers(m, c(0xD0D3D4), c(0x5D6D7E), 2, 14, 1, 9, 3, 1);
        m.box(c(0x34495E), 1, 13, 2, 15, 15, 15);
        m.box(c(0x2C3E50), 2, 13, 1, 9, 14, 3);
        m.box(c(0x5DADE2), 3, 14, 1, 7, 15, 2);
        m.box(WHITE, 10, 15, 4, 15, 16, 12);
        return m;
    }

    public static final Model WHITEBOARD = reg(whiteboard());

    private static Model whiteboard() {
        Model m = new Model("pizarra_blanca", 2, 2, 1);
        for (int x : new int[]{2, 28}) {
            m.box(STEEL, x, 1, 7, x + 2, 30, 9);
            m.box(STEEL, x - 1, 0, 3, x + 3, 1, 13);
            m.box(BLACK, x - 1, 0, 3, x, 1, 4);
            m.box(BLACK, x + 2, 0, 12, x + 3, 1, 13);
        }
        m.box(STEEL, 1, 8, 7, 31, 30, 9);
        m.box(WHITE, 2, 9, 6, 30, 29, 7);
        int[][] bars = {{6, 12, 0xE74C3C}, {10, 17, 0x3498DB}, {14, 14, 0x27AE60}, {18, 21, 0xF39C12}};
        for (int[] b : bars) m.box(c(b[2]), b[0], 11, 5, b[0] + 3, b[1], 6);
        m.box(BLACK, 5, 11, 5, 23, 12, 6);
        m.box(BLACK, 5, 11, 5, 6, 26, 6);
        for (int i = 0; i < 6; i++) m.box(BLUE, 24 + i % 2, 15 + i * 2, 5, 26, 16 + i * 2, 6);
        m.box(STEEL, 4, 8, 4, 28, 9, 7);
        m.box(RED, 8, 9, 5, 11, 10, 6);
        m.box(BLUE, 13, 9, 5, 16, 10, 6);
        return m;
    }

    public static final Model PROJ_SCREEN = reg(projScreen());

    private static Model projScreen() {
        Model m = new Model("pantalla_proyector", 3, 2, 1);
        m.box(c(0xD5D8DC), 0, 28, 12, 48, 31, 16);
        m.box(BLACK, 2, 5, 14, 46, 28, 15);
        m.box(WHITE, 3, 6, 13, 45, 27, 14);
        m.box(c(0x1F618D), 6, 22, 13, 42, 25, 14);
        m.box(c(0xAED6F1), 6, 9, 13, 22, 19, 14);
        for (int y = 10; y < 20; y += 3) m.box(c(0x85929E), 25, y, 13, 42, y + 1, 14);
        m.box(BLACK, 22, 3, 14, 26, 5, 15);
        return m;
    }

    public static final Model PARTITION = reg(partition());

    private static Model partition() {
        Model m = new Model("mampara", 2, 1, 1);
        m.box(STEEL, 0, 0, 6, 32, 1, 10);
        m.box(STEEL, 0, 0, 7, 1, 16, 9);
        m.box(STEEL, 31, 0, 7, 32, 16, 9);
        m.box(w(0x7F8C8D), 1, 1, 7, 31, 12, 9);
        m.box(STEEL, 1, 12, 7, 31, 13, 9);
        m.box(GLASS_W, 1, 13, 7, 31, 16, 9);
        return m;
    }

    public static final Model SERVER_RACK = reg(serverRack());

    private static Model serverRack() {
        Model m = new Model("rack_servidores", 1, 2, 1);
        m.box(BLACK, 1, 0, 2, 15, 31, 16);
        m.box(c(0x1C2833), 2, 1, 1, 14, 30, 2);
        Rng r = new Rng(17);
        for (int y = 3; y < 29; y += 3) {
            m.box(c(0x2C3E50), 2, y, 1, 14, y + 2, 2);
            for (int x = 3; x < 13; x += 2)
                if (r.chance(0.55)) m.box(r.chance(0.7) ? GREEN_LIT : (r.chance(0.5) ? LIGHT : c(0xF39C12)), x, y + 1, 0, x + 1, y + 2, 1);
        }
        m.box(STEEL, 12, 12, 0, 13, 18, 1);
        return m;
    }

    public static final Model VENDING_SNACK = reg(vendingSnack());

    private static Model vendingSnack() {
        Model m = new Model("expendedora_snacks", 1, 2, 1);
        m.box(c(0x1C2833), 0, 0, 2, 16, 31, 16);
        m.box(c(0xC0392B), 0, 28, 1, 16, 31, 2);
        m.box(GLASS, 1, 6, 1, 11, 28, 2);
        Rng r = new Rng(29);
        for (int y = 8; y < 27; y += 5) {
            m.box(STEEL, 1, y - 1, 2, 11, y, 14);
            for (int x = 2; x < 10; x += 3) m.box(c(VIVID[r.nextInt(VIVID.length)]), x, y, 3, x + 2, y + 3, 6);
        }
        m.box(BLACK, 12, 18, 1, 15, 26, 2);
        for (int y = 19; y < 25; y += 2)
            for (int x = 12; x < 15; x++) m.box(LGRAY, x, y, 0, x + 1, y + 1, 1);
        m.box(BLACK, 2, 1, 1, 10, 5, 2);
        m.box(c(0x7DCEA0), 12, 25, 0, 15, 26, 1);
        return m;
    }

    public static final Model VENDING_DRINK = reg(vendingDrink());

    private static Model vendingDrink() {
        Model m = new Model("expendedora_bebidas", 1, 2, 1);
        m.box(c(0xC0392B), 0, 0, 2, 16, 31, 16);
        m.box(WHITE, 1, 6, 1, 11, 28, 2);
        for (int y = 8; y < 26; y++) {
            int x = 2 + (int) Math.round(3.5 + 3.5 * Math.sin(y * 0.45));
            m.box(c(0xC0392B), x, y, 0, x + 2, y + 1, 1);
        }
        m.cylY(c(0xC0392B), 6, 0.5, 1.2, 9, 12);
        for (int y = 9; y < 27; y += 3) m.box(LIGHT, 12, y, 1, 15, y + 2, 2);
        m.box(BLACK, 12, 6, 1, 15, 8, 2);
        m.box(BLACK, 2, 1, 1, 10, 4, 2);
        m.box(STEEL, 13, 5, 0, 14, 6, 1);
        return m;
    }

    public static final Model COFFEE_STATION = reg(coffeeStation());

    private static Model coffeeStation() {
        Model m = new Model("estacion_cafe", 2, 2, 1);
        m.box(c(0x2C3E50), 0, 0, 3, 32, 13, 16);
        m.box(c(0x34495E), 1, 1, 2, 15, 12, 3);
        m.box(c(0x34495E), 17, 1, 2, 31, 12, 3);
        m.box(STEEL, 13, 6, 1, 14, 9, 2);
        m.box(STEEL, 18, 6, 1, 19, 9, 2);
        m.box(BIRCH, 0, 13, 2, 32, 15, 16);
        m.box(BLACK, 2, 15, 8, 11, 25, 15);
        m.box(STEEL, 3, 18, 7, 10, 19, 8);
        m.box(BLACK, 5, 15, 5, 8, 16, 8);
        m.box(LIGHT, 4, 23, 7, 9, 24, 8);
        for (int i = 0; i < 4; i++) m.cylY(WHITE, 14, 10, 1.6, 15 + i * 2, 16 + i * 2);
        m.box(c(0x6E2C00), 18, 15, 9, 21, 19, 12);
        m.box(WHITE, 23, 15, 9, 26, 18, 12);
        m.box(c(0xF5F5F5), 27, 15, 5, 31, 16, 9);
        m.box(BIRCH, 0, 26, 11, 32, 27, 16);
        for (int x = 2; x < 30; x += 5) cup(m, c(VIVID[x % VIVID.length]), x, 27, 12);
        return m;
    }

    public static final Model RECEPTION_MOD = reg(receptionModern());

    private static Model receptionModern() {
        Model m = new Model("recepcion_moderna", 3, 1, 2);
        for (int x = 1; x < 47; x++) {
            double t = (x - 24) / 23.0;
            int z = 3 + (int) Math.round(6 * t * t);
            m.box(WHITE, x, 1, z, x + 1, 14, z + 3);
            m.box(OAK, x, 14, z - 1, x + 1, 16, z + 4);
            m.box(LIGHT, x, 0, z + 1, x + 1, 1, z + 2);
            m.box(WHITE, x, 9, z + 3, x + 1, 10, z + 9);
        }
        m.cylZ(GOLD, 24, 8, 3.2, 2, 3);
        m.cylZ(c(0x1F618D), 24, 8, 2.2, 1, 2);
        m.box(c(0x1F618D), 4, 6, 3, 18, 7, 4);
        m.box(c(0x1F618D), 30, 6, 3, 44, 7, 4);
        m.box(BLACK, 14, 10, 14, 20, 11, 17);
        m.box(BLACK, 16, 11, 16, 18, 12, 17);
        screen(m, 13, 12, 21, 16, 16, 1, c(0x5DADE2));
        m.box(BLACK, 30, 10, 13, 34, 11, 16);
        officeChair(m, 9, 18, BLACK, 2);
        officeChair(m, 26, 18, BLACK, 2);
        return m;
    }

    public static final Model LOCKERS = reg(lockers());

    private static Model lockers() {
        Model m = new Model("lockers", 2, 2, 1);
        Mat g = c(0x7F8C8D), d = c(0x95A5A6);
        m.box(g, 0, 0, 3, 32, 31, 16);
        for (int col = 0; col < 4; col++)
            for (int row = 0; row < 2; row++) {
                int x = col * 8, y = 1 + row * 15;
                m.box(d, x + 1, y, 2, x + 7, y + 14, 3);
                for (int vy = y + 10; vy < y + 13; vy++) if (vy % 2 == 0) m.box(c(0x566573), x + 2, vy, 1, x + 6, vy + 1, 2);
                m.box(STEEL, x + 5, y + 6, 1, x + 6, y + 8, 2);
            }
        return m;
    }

    public static final Model SAFE = reg(safe());

    private static Model safe() {
        Model m = new Model("caja_fuerte", 1, 1, 1);
        m.box(c(0x3D4B57), 2, 0, 3, 14, 13, 15);
        m.box(c(0x4D5D6B), 3, 1, 2, 13, 12, 3);
        m.cylZ(GOLD, 6, 7, 2, 1, 2);
        m.cylZ(BLACK, 6, 7, 0.9, 0, 1);
        m.box(STEEL, 10, 5, 1, 11, 9, 2);
        m.box(STEEL, 10, 7, 0, 12, 8, 1);
        return m;
    }

    public static final Model RECYCLE_BINS = reg(recycleBins());

    private static Model recycleBins() {
        Model m = new Model("contenedores_reciclaje", 1, 1, 1);
        int[] cols = {0x2471A3, 0xD4AC0D, 0x1E8449};
        for (int i = 0; i < 3; i++) {
            int x = 1 + i * 5;
            m.box(c(cols[i]), x, 0, 5, x + 4, 11, 13);
            m.box(c(cols[i]), x, 11, 4, x + 4, 12, 13);
            m.box(BLACK, x + 1, 11, 6, x + 3, 12, 8);
            m.box(WHITE, x + 1, 6, 4, x + 3, 8, 5);
        }
        return m;
    }

    public static final Model FOOSBALL = reg(foosball());

    private static Model foosball() {
        Model m = new Model("metegol", 2, 1, 1);
        m.box(WALNUT, 2, 0, 3, 5, 9, 6);
        m.box(WALNUT, 27, 0, 3, 30, 9, 6);
        m.box(WALNUT, 2, 0, 10, 5, 9, 13);
        m.box(WALNUT, 27, 0, 10, 30, 9, 13);
        m.box(WALNUT, 0, 9, 2, 32, 14, 14);
        m.box(GREEN, 1, 11, 3, 31, 12, 13);
        m.box(WHITE, 15, 11, 3, 16, 12, 13);
        m.cut(1, 12, 3, 31, 14, 13);
        int[] rods = {5, 9, 13, 18, 22, 26};
        for (int i = 0; i < rods.length; i++) {
            int x = rods[i];
            m.box(STEEL, x, 13, 0, x + 1, 14, 16);
            m.box(BLACK, x, 13, 0, x + 1, 14, 2);
            Mat p = i % 2 == 0 ? RED : BLUE;
            for (int z = 4; z < 13; z += 4) m.box(p, x, 11, z, x + 1, 14, z + 1);
        }
        return m;
    }

    public static final Model PING_PONG = reg(pingPong());

    private static Model pingPong() {
        Model m = new Model("ping_pong", 3, 1, 2);
        Mat top = c(0x1F4E79);
        m.box(top, 1, 10, 4, 47, 11, 28);
        m.box(WHITE, 1, 10, 4, 47, 11, 5);
        m.box(WHITE, 1, 10, 27, 47, 11, 28);
        m.box(WHITE, 1, 10, 4, 2, 11, 28);
        m.box(WHITE, 46, 10, 4, 47, 11, 28);
        m.box(WHITE, 1, 10, 15, 47, 11, 17);
        m.box(BLACK, 23, 11, 3, 25, 14, 29);
        m.box(WHITE, 23, 13, 3, 25, 14, 29);
        for (int x : new int[]{6, 40}) {
            m.box(c(0x2C3E50), x, 0, 6, x + 2, 10, 8);
            m.box(c(0x2C3E50), x, 0, 24, x + 2, 10, 26);
            m.box(c(0x2C3E50), x, 2, 8, x + 2, 3, 24);
        }
        m.box(RED, 10, 11, 9, 14, 12, 13);
        m.box(WALNUT, 12, 11, 13, 13, 12, 16);
        m.box(BLACK, 34, 11, 19, 38, 12, 23);
        m.box(WALNUT, 35, 11, 16, 36, 12, 19);
        m.box(WHITE, 30, 11, 10, 31, 12, 11);
        return m;
    }

    public static final Model BULLETIN = reg(bulletin());

    private static Model bulletin() {
        Model m = new Model("cartelera", 2, 1, 1);
        m.box(WALNUT, 1, 2, 14, 31, 15, 16);
        m.box(CORK, 2, 3, 13, 30, 14, 14);
        int[][] notes = {{4, 9, 0xFFF59D}, {10, 6, 0xFFFFFF}, {16, 9, 0xF8BBD0}, {22, 5, 0xB3E5FC}, {5, 4, 0xC8E6C9}, {24, 10, 0xFFFFFF}, {14, 4, 0xFFF59D}};
        for (int[] n : notes) {
            m.box(c(n[2]), n[0], n[1], 12, n[0] + 5, n[1] + 4, 13);
            m.box(RED, n[0] + 2, n[1] + 3, 11, n[0] + 3, n[1] + 4, 12);
        }
        return m;
    }

    public static final Model PODIUM = reg(podium());

    private static Model podium() {
        Model m = new Model("atril", 1, 2, 1);
        m.box(WALNUT, 2, 0, 3, 14, 2, 14);
        m.box(WALNUT, 3, 2, 4, 13, 18, 13);
        m.box(c(0x5A4030), 4, 4, 3, 12, 16, 4);
        m.cylZ(GOLD, 8, 11, 2.6, 2, 3);
        m.cylZ(c(0x1F618D), 8, 11, 1.6, 1, 2);
        m.box(WALNUT, 2, 18, 2, 14, 19, 14);
        m.box(WALNUT, 2, 19, 8, 14, 20, 14);
        m.box(BLACK, 7, 19, 3, 8, 23, 4);
        m.box(BLACK, 7, 22, 4, 8, 23, 7);
        m.sphere(c(0x2C3E50), 7.5, 23, 7.5, 1.1);
        m.box(WHITE, 4, 20, 9, 10, 21, 13);
        return m;
    }

    public static final Model WAIT_SOFA = reg(waitSofa());

    private static Model waitSofa() {
        Model m = new Model("sofa_espera", 2, 1, 1);
        for (int x : new int[]{1, 30}) {
            m.box(STEEL, x, 0, 2, x + 1, 9, 3);
            m.box(STEEL, x, 0, 13, x + 1, 9, 14);
            m.box(STEEL, x, 9, 2, x + 1, 10, 14);
        }
        m.box(STEEL, 1, 3, 2, 31, 4, 14);
        m.box(LEATHER_D, 2, 4, 2, 15, 7, 13);
        m.box(LEATHER_D, 17, 4, 2, 30, 7, 13);
        m.box(LEATHER_D, 2, 7, 12, 15, 14, 14);
        m.box(LEATHER_D, 17, 7, 12, 30, 14, 14);
        m.box(STEEL, 15, 4, 3, 17, 10, 14);
        return m;
    }

    // ================================================================== escuela

    public static final Model TEACHER_DESK = reg(teacherDesk());

    private static Model teacherDesk() {
        Model m = new Model("escritorio_maestra", 2, 1, 1);
        m.box(OAK, 0, 11, 1, 32, 13, 15);
        m.box(OAK, 1, 0, 2, 31, 11, 3);
        m.box(OAK, 1, 0, 2, 9, 11, 14);
        drawers(m, BIRCH, STEEL, 2, 8, 1, 10, 3, 14 + 1);
        m.box(OAK, 30, 0, 2, 31, 11, 14);
        m.sphere(RED, 6, 14.5, 7, 1.6);
        m.box(c(0x4E8C3A), 6, 15, 7, 7, 16, 8);
        Rng r = new Rng(3);
        for (int y = 13; y < 16; y++) m.box(c(BOOK[r.nextInt(BOOK.length)]), 22, y, 4, 30, y + 1, 11);
        m.cylY(c(0xF4D03F), 14, 6, 1.5, 13, 16);
        m.box(WHITE, 12, 13, 9, 19, 14, 14);
        m.box(BLACK, 13, 14, 10, 18, 15, 11);
        return m;
    }

    public static final Model LIB_SHELF = reg(libShelf());

    private static Model libShelf() {
        Model m = new Model("estante_biblioteca", 3, 2, 1);
        Rng r = new Rng(88);
        Mat wood = OAK;
        m.box(wood, 0, 0, 2, 1, 31, 16);
        m.box(wood, 47, 0, 2, 48, 31, 16);
        m.box(wood, 23, 0, 2, 25, 31, 16);
        m.box(wood, 0, 30, 2, 48, 31, 16);
        m.box(wood, 1, 0, 15, 47, 30, 16);
        for (int y : new int[]{0, 8, 16, 23}) m.box(wood, 1, y, 2, 47, y + 1, 16);
        for (int y : new int[]{1, 9, 17}) {
            books(m, r, 1, 23, y, 4, 15, 4, 6);
            books(m, r, 25, 47, y, 4, 15, 4, 6);
        }
        books(m, r, 1, 23, 24, 4, 15, 4, 5);
        books(m, r, 25, 40, 24, 4, 15, 4, 5);
        m.box(c(0x1F3A5F), 6, 31, 6, 42, 32, 10);
        m.box(GOLD, 20, 27, 1, 28, 29, 2);
        return m;
    }

    public static final Model LAB_TABLE = reg(labTable());

    private static Model labTable() {
        Model m = new Model("mesa_laboratorio", 2, 1, 1);
        m.box(WHITE, 0, 0, 2, 32, 11, 16);
        for (int x : new int[]{1, 11, 21}) m.box(c(0xEAEDED), x, 1, 1, x + 9, 10, 2);
        for (int x : new int[]{8, 18, 28}) m.box(STEEL, x, 6, 0, x + 1, 9, 1);
        m.box(BLACK, 0, 11, 1, 32, 12, 16);
        m.cylY(GLASS, 5, 6, 2.2, 12, 14);
        m.cylY(GLASS, 5, 6, 1, 14, 16);
        m.cylY(c(0x27AE60), 5, 6, 1.8, 12, 13);
        m.cylY(GLASS, 10, 8, 1.6, 12, 16);
        m.cylY(c(0xE74C3C), 10, 8, 1.3, 12, 14);
        m.box(WALNUT, 14, 12, 5, 22, 13, 8);
        for (int x = 15; x < 22; x += 2) {
            m.box(GLASS, x, 13, 6, x + 1, 16, 7);
            m.box(c(VIVID[x % 6]), x, 13, 6, x + 1, 14, 7);
        }
        m.cylY(STEEL, 26, 8, 1.2, 12, 15);
        m.box(c(0x3498DB), 25, 15, 7, 27, 16, 9);
        m.box(STEEL, 28, 12, 12, 30, 16, 14);
        return m;
    }

    public static final Model MICROSCOPE = reg(microscope());

    private static Model microscope() {
        Model m = new Model("mesa_microscopio", 1, 1, 1);
        m.box(WHITE, 1, 8, 2, 15, 9, 15);
        legs(m, STEEL, 1, 2, 15, 15, 0, 8, 1);
        m.box(BLACK, 4, 9, 6, 10, 10, 12);
        m.box(BLACK, 8, 10, 9, 10, 15, 11);
        m.box(BLACK, 5, 12, 7, 9, 13, 10);
        m.box(BLACK, 5, 13, 8, 7, 16, 10);
        m.box(STEEL, 6, 11, 8, 7, 12, 9);
        m.box(GLASS_B, 11, 9, 4, 14, 10, 6);
        return m;
    }

    public static final Model MAP_WALL = reg(mapWall());

    private static Model mapWall() {
        Model m = new Model("mapa", 2, 1, 1);
        m.box(WALNUT, 1, 2, 14, 31, 15, 16);
        m.box(c(0x5DADE2), 2, 3, 13, 30, 14, 14);
        int[][] land = {{4, 9, 9, 13}, {6, 5, 9, 9}, {12, 9, 18, 13}, {13, 5, 16, 9}, {18, 8, 27, 13}, {23, 4, 27, 7}, {9, 3, 11, 4}};
        int[] cols = {0x58A55C, 0x6AA84F, 0xC9B458, 0x58A55C, 0x8FBC5A, 0xC9B458, 0xFFFFFF};
        for (int i = 0; i < land.length; i++) m.box(c(cols[i]), land[i][0], land[i][1], 12, land[i][2], land[i][3], 13);
        return m;
    }

    public static final Model SCHOOL_LOCKERS = reg(schoolLockers());

    private static Model schoolLockers() {
        Model m = new Model("casilleros", 2, 2, 1);
        int[] cols = {0x2471A3, 0xC0392B, 0xD4AC0D, 0x1E8449};
        m.box(c(0x566573), 0, 0, 3, 32, 31, 16);
        for (int col = 0; col < 5; col++) {
            int x = 1 + col * 6;
            Mat d = c(cols[col % cols.length]);
            m.box(d, x, 2, 2, x + 5, 29, 3);
            for (int vy = 24; vy < 28; vy += 2) m.box(c(0x2C3E50), x + 1, vy, 1, x + 4, vy + 1, 2);
            m.box(STEEL, x + 3, 13, 1, x + 4, 16, 2);
            m.box(WHITE, x + 1, 19, 1, x + 4, 21, 2);
        }
        return m;
    }

    public static final Model HOOP = reg(hoop());

    private static Model hoop() {
        Model m = new Model("aro_basquet", 1, 3, 1);
        m.box(STEEL, 6, 30, 13, 10, 32, 16);
        m.box(WHITE, 0, 32, 12, 16, 44, 13);
        m.box(RED, 4, 34, 11, 12, 35, 12);
        m.box(RED, 4, 34, 11, 5, 39, 12);
        m.box(RED, 11, 34, 11, 12, 39, 12);
        m.box(RED, 4, 38, 11, 12, 39, 12);
        m.box(BLACK, 0, 32, 12, 16, 33, 13);
        m.box(BLACK, 0, 43, 12, 16, 44, 13);
        m.box(ORANGE, 7, 33, 9, 9, 34, 11);
        m.cylY(ORANGE, 8, 6, 3.5, 33, 34);
        m.cylY(null, 8, 6, 2.6, 33, 34);
        for (int[] p : new int[][]{{5, 5}, {11, 5}, {8, 3}, {8, 9}, {6, 8}, {10, 8}}) m.box(WHITE, p[0], 27, p[1], p[0] + 1, 33, p[1] + 1);
        return m;
    }

    public static final Model CAFETERIA_TABLE = reg(cafeteriaTable());

    private static Model cafeteriaTable() {
        Model m = new Model("mesa_comedor_escolar", 3, 1, 2);
        m.box(c(0xE5E1DA), 2, 10, 9, 46, 11, 23);
        for (int x : new int[]{6, 40}) {
            m.box(STEEL, x, 0, 4, x + 2, 10, 6);
            m.box(STEEL, x, 0, 26, x + 2, 10, 28);
            m.box(STEEL, x, 0, 4, x + 2, 1, 28);
        }
        m.box(c(0x1F618D), 2, 6, 1, 46, 7, 7);
        m.box(c(0x1F618D), 2, 6, 25, 46, 7, 31);
        m.box(STEEL, 2, 5, 3, 46, 6, 5);
        m.box(STEEL, 2, 5, 27, 46, 6, 29);
        int[] trays = {6, 20, 34};
        for (int x : trays) {
            for (int z : new int[]{10, 17}) {
                m.box(c(0xE67E22), x, 11, z, x + 8, 12, z + 5);
                m.box(WHITE, x + 1, 12, z + 1, x + 4, 13, z + 4);
                m.box(c(0xF4D03F), x + 5, 12, z + 1, x + 7, 13, z + 3);
                m.box(RED, x + 5, 12, z + 3, x + 7, 14, z + 4);
            }
        }
        return m;
    }

    public static final Model EASEL = reg(easel());

    private static Model easel() {
        Model m = new Model("atril_pintura", 1, 2, 1);
        m.box(OAK, 3, 0, 7, 4, 29, 8);
        m.box(OAK, 12, 0, 7, 13, 29, 8);
        m.box(OAK, 7, 0, 12, 9, 26, 13);
        m.box(OAK, 3, 26, 7, 13, 28, 8);
        m.box(OAK, 2, 10, 5, 14, 11, 8);
        m.box(WHITE, 2, 11, 6, 14, 27, 7);
        m.box(c(0x87CEEB), 3, 18, 5, 13, 26, 6);
        m.box(c(0x6AA84F), 3, 12, 5, 13, 16, 6);
        m.box(c(0xF7DC6F), 9, 21, 4, 12, 24, 5);
        m.box(c(0xE74C3C), 5, 15, 4, 7, 19, 5);
        return m;
    }

    public static final Model SKELETON = reg(skeleton());

    private static Model skeleton() {
        Model m = new Model("esqueleto", 1, 2, 1);
        Mat b = c(0xF5F0E1);
        m.cylY(STEEL, 8, 9, 3, 0, 1);
        m.box(STEEL, 8, 1, 9, 9, 5, 10);
        m.box(b, 7, 5, 8, 10, 7, 11);
        m.box(b, 5, 1, 9, 6, 6, 10);
        m.box(b, 10, 1, 9, 11, 6, 10);
        m.box(b, 6, 6, 9, 11, 7, 10);
        m.box(b, 8, 7, 9, 9, 17, 10);
        for (int y = 10; y < 17; y += 2) m.box(b, 5, y, 7, 12, y + 1, 11);
        m.box(b, 4, 17, 8, 13, 18, 10);
        m.box(b, 4, 9, 9, 5, 17, 10);
        m.box(b, 12, 9, 9, 13, 17, 10);
        m.box(b, 8, 18, 9, 9, 19, 10);
        m.sphere(b, 8.5, 21.5, 9.5, 2.6);
        m.box(BLACK, 7, 21, 7, 8, 22, 8);
        m.box(BLACK, 9, 21, 7, 10, 22, 8);
        return m;
    }

    public static final Model KIDS_TABLE = reg(kidsTable());

    private static Model kidsTable() {
        Model m = new Model("mesa_infantil", 2, 1, 1);
        m.box(YELLOW, 7, 7, 4, 25, 8, 12);
        legs(m, WHITE, 8, 5, 24, 11, 0, 7, 1);
        int[][] ch = {{1, 5, 0xE74C3C}, {26, 5, 0x3498DB}, {11, 0, 0x2ECC71}, {11, 12, 0xF39C12}};
        for (int[] p : ch) {
            int x = p[0], z = p[1], w = p[1] == 0 || p[1] == 12 ? 10 : 5, d = p[1] == 0 || p[1] == 12 ? 4 : 6;
            Mat cc = c(p[2]);
            m.box(cc, x, 4, z, x + w, 5, z + d);
            legs(m, cc, x, z, x + w, z + d, 0, 4, 1);
        }
        m.box(c(0xE74C3C), 12, 8, 6, 15, 9, 9);
        m.box(c(0x3498DB), 18, 8, 7, 21, 10, 10);
        return m;
    }

    // ================================================================== salud

    public static final Model IV_STAND = reg(ivStand());

    private static Model ivStand() {
        Model m = new Model("porta_suero", 1, 2, 1);
        m.box(STEEL, 3, 1, 7, 13, 2, 9);
        m.box(STEEL, 7, 1, 3, 9, 2, 13);
        for (int[] p : new int[][]{{3, 7}, {12, 7}, {7, 3}, {7, 12}}) m.box(BLACK, p[0], 0, p[1], p[0] + 1, 1, p[1] + 2);
        m.box(STEEL, 7, 2, 7, 9, 30, 9);
        m.box(STEEL, 4, 29, 7, 12, 30, 9);
        m.box(g(0xE8F8F5, 160), 3, 21, 7, 6, 28, 9);
        m.box(c(0xF7DC6F), 3, 23, 7, 6, 24, 9);
        m.box(g(0xFFFFFF, 140), 4, 10, 8, 5, 21, 9);
        m.box(STEEL, 9, 18, 7, 12, 22, 9);
        m.box(c(0x48C9B0), 10, 19, 6, 11, 21, 7);
        return m;
    }

    public static final Model MONITOR_STAND = reg(monitorStand());

    private static Model monitorStand() {
        Model m = new Model("monitor_signos", 1, 2, 1);
        m.box(STEEL, 3, 1, 7, 13, 2, 9);
        m.box(STEEL, 7, 1, 3, 9, 2, 13);
        m.box(STEEL, 7, 2, 7, 9, 20, 9);
        m.box(c(0xE5E7E9), 2, 20, 6, 14, 29, 10);
        m.box(BLACK, 3, 21, 5, 13, 28, 6);
        int[] beat = {24, 24, 24, 27, 22, 24, 24, 25, 24, 24};
        for (int i = 0; i < beat.length; i++) m.box(GREEN_LIT, 3 + i, beat[i], 4, 4 + i, beat[i] + 1, 5);
        m.box(c(0xF39C12), 10, 22, 4, 12, 23, 5);
        m.box(LIGHT, 4, 22, 4, 6, 23, 5);
        m.box(STEEL, 4, 11, 9, 12, 12, 13);
        return m;
    }

    public static final Model WHEELCHAIR = reg(wheelchair());

    private static Model wheelchair() {
        Model m = new Model("silla_ruedas", 1, 1, 1);
        for (int x : new int[]{1, 14}) {
            m.cylX(BLACK, 6, 10, 5.5, x, x + 1);
            m.cylX(null, 6, 10, 4.3, x, x + 1);
            m.cylX(STEEL, 6, 10, 4.6, x, x + 1);
            m.cylX(null, 6, 10, 4.0, x, x + 1);
            m.box(STEEL, x, 5, 9, x + 1, 7, 11);
        }
        m.box(STEEL, 2, 6, 5, 14, 7, 13);
        m.box(LEATHER_D, 3, 7, 5, 13, 8, 13);
        m.box(LEATHER_D, 3, 8, 12, 13, 14, 13);
        m.box(STEEL, 3, 8, 13, 4, 15, 14);
        m.box(STEEL, 12, 8, 13, 13, 15, 14);
        m.box(BLACK, 3, 14, 13, 4, 15, 16);
        m.box(BLACK, 12, 14, 13, 13, 15, 16);
        m.box(STEEL, 4, 1, 1, 5, 6, 2);
        m.box(STEEL, 11, 1, 1, 12, 6, 2);
        m.box(BLACK, 3, 1, 0, 6, 2, 3);
        m.box(BLACK, 10, 1, 0, 13, 2, 3);
        m.box(BLACK, 4, 0, 4, 5, 2, 5);
        m.box(BLACK, 11, 0, 4, 12, 2, 5);
        return m;
    }

    public static final Model GURNEY = reg(gurney());

    private static Model gurney() {
        Model m = new Model("camilla", 1, 1, 2);
        for (int[] p : new int[][]{{2, 3}, {13, 3}, {2, 28}, {13, 28}}) {
            m.box(BLACK, p[0], 0, p[1], p[0] + 1, 2, p[1] + 1);
            m.box(STEEL, p[0], 2, p[1], p[0] + 1, 7, p[1] + 1);
        }
        m.box(STEEL, 1, 7, 1, 15, 8, 31);
        m.box(c(0xD6EAF8), 2, 8, 2, 14, 10, 30);
        m.box(WHITE, 4, 10, 25, 12, 12, 29);
        m.box(w(0x85C1E9), 2, 10, 2, 14, 11, 18);
        m.box(STEEL, 0, 10, 6, 1, 11, 24);
        m.box(STEEL, 15, 10, 6, 16, 11, 24);
        m.box(STEEL, 0, 8, 6, 1, 10, 7);
        m.box(STEEL, 15, 8, 6, 16, 10, 7);
        m.box(STEEL, 0, 8, 23, 1, 10, 24);
        m.box(STEEL, 15, 8, 23, 16, 10, 24);
        return m;
    }

    public static final Model MED_CABINET = reg(medCabinet());

    private static Model medCabinet() {
        Model m = new Model("vitrina_medica", 1, 2, 1);
        m.box(WHITE, 0, 0, 3, 16, 31, 16);
        m.box(c(0xF2F3F4), 1, 1, 2, 15, 13, 3);
        m.box(STEEL, 7, 6, 1, 8, 9, 2);
        m.box(STEEL, 8, 6, 1, 9, 9, 2);
        m.box(RED, 6, 9, 1, 10, 11, 2);
        m.box(RED, 7, 8, 1, 9, 12, 2);
        m.cut(1, 14, 3, 15, 30, 14);
        m.box(GLASS, 1, 14, 3, 15, 30, 4);
        Rng r = new Rng(41);
        for (int y : new int[]{14, 19, 24}) {
            m.box(GLASS_W, 1, y, 4, 15, y + 1, 14);
            for (int x = 2; x < 14; x += 3) {
                if (r.chance(0.5)) m.cylY(c(new int[]{0xF39C12, 0x922B21, 0x1F618D, 0xFFFFFF}[r.nextInt(4)]), x + 1, 9, 1.2, y + 1, y + 4);
                else m.box(c(new int[]{0xFFFFFF, 0xAED6F1, 0xFADBD8}[r.nextInt(3)]), x, y + 1, 7, x + 2, y + 4, 12);
            }
        }
        return m;
    }

    public static final Model WAIT_CHAIRS = reg(waitChairs());

    private static Model waitChairs() {
        Model m = new Model("sillas_espera", 3, 1, 1);
        m.box(STEEL, 1, 4, 7, 47, 5, 9);
        for (int x : new int[]{3, 44}) {
            m.box(STEEL, x, 0, 7, x + 1, 4, 9);
            m.box(STEEL, x - 2, 0, 4, x + 3, 1, 12);
        }
        for (int i = 0; i < 3; i++) {
            int x = 2 + i * 15;
            Mat s = c(0x1F618D);
            m.box(s, x, 5, 3, x + 13, 7, 13);
            m.box(s, x, 7, 12, x + 13, 15, 14);
            m.box(STEEL, x + 13, 5, 6, x + 15 > 47 ? 47 : x + 15, 10, 10);
        }
        return m;
    }

    public static final Model EXAM_BED = reg(examBed());

    private static Model examBed() {
        Model m = new Model("camilla_consultorio", 1, 1, 2);
        m.box(WHITE, 1, 0, 3, 15, 8, 29);
        drawers(m, c(0xF2F3F4), STEEL, 2, 14, 1, 8, 2, 2);
        Mat pad = c(0x1A5E63);
        m.box(pad, 1, 8, 2, 15, 10, 24);
        for (int i = 0; i < 6; i++) m.box(pad, 1, 10 + i, 24 + i, 15, 11 + i, 25 + i);
        m.box(pad, 1, 9, 24, 15, 10, 31);
        m.box(WHITE, 4, 10, 2, 12, 11, 24);
        m.cylX(WHITE, 13, 30, 1.5, 3, 13);
        m.box(STEEL, 3, 0, -0 + 0, 13, 3, 3);
        return m;
    }

    public static final Model SURGICAL_LAMP = reg(surgicalLamp());

    private static Model surgicalLamp() {
        Model m = new Model("lampara_quirofano", 2, 1, 2);
        m.cylY(STEEL, 16, 16, 3, 14, 16);
        m.box(STEEL, 15, 10, 15, 17, 14, 17);
        m.box(STEEL, 8, 10, 15, 24, 11, 17);
        for (int x : new int[]{8, 24}) {
            m.box(STEEL, x - 1, 7, 15, x + 1, 10, 17);
            m.cylY(c(0xE5E7E9), x, 16, 6, 4, 7);
            m.cylY(c(0xE5E7E9), x, 16, 4.5, 7, 8);
            m.cylY(LIGHT, x, 16, 4.6, 3, 4);
            m.cylY(STEEL, x, 16, 1, 2, 3);
        }
        return m;
    }

    public static final Model XRAY = reg(xray());

    private static Model xray() {
        Model m = new Model("negatoscopio", 2, 1, 1);
        m.box(c(0xE5E7E9), 1, 3, 13, 31, 15, 16);
        m.box(PEARL, 2, 4, 12, 30, 14, 13);
        for (int x0 : new int[]{3, 17}) {
            m.box(c(0x1B2631), x0, 5, 11, x0 + 12, 13, 12);
            m.box(c(0xD5D8DC), x0 + 5, 6, 11, x0 + 7, 12, 11 + 1);
            for (int y = 7; y < 12; y += 2) m.box(c(0xAEB6BF), x0 + 2, y, 11, x0 + 10, y + 1, 12);
        }
        return m;
    }

    public static final Model OXYGEN = reg(oxygen());

    private static Model oxygen() {
        Model m = new Model("tubos_oxigeno", 1, 1, 1);
        m.box(STEEL, 2, 0, 4, 14, 2, 12);
        m.box(STEEL, 2, 2, 11, 14, 12, 12);
        for (int x : new int[]{5, 11}) {
            m.cylY(c(0x1E8449), x, 8, 2.6, 2, 13);
            m.sphere(c(0x1E8449), x, 13, 8, 2.4);
            m.box(STEEL, x - 1, 14, 7, x + 1, 16, 9);
            m.cylZ(WHITE, x, 15, 1, 5, 6);
        }
        return m;
    }

    public static final Model DIVIDER = reg(divider());

    private static Model divider() {
        Model m = new Model("biombo", 2, 2, 1);
        Mat fab = w(0xA9DFBF);
        int[][] panels = {{0, 4}, {11, 10}, {22, 4}};
        for (int[] p : panels) {
            int x = p[0], z = p[1];
            m.box(STEEL, x, 2, z, x + 10, 3, z + 1);
            m.box(STEEL, x, 27, z, x + 10, 28, z + 1);
            m.box(STEEL, x, 0, z, x + 1, 28, z + 1);
            m.box(STEEL, x + 9, 0, z, x + 10, 28, z + 1);
            m.box(fab, x + 1, 3, z, x + 9, 27, z + 1);
        }
        m.box(STEEL, 10, 2, 5, 11, 28, 10);
        m.box(STEEL, 21, 2, 5, 22, 28, 10);
        return m;
    }

    public static final Model FIRST_AID = reg(firstAid());

    private static Model firstAid() {
        Model m = new Model("botiquin_pared", 1, 1, 1);
        m.box(WHITE, 3, 4, 12, 13, 13, 16);
        m.box(RED, 7, 6, 11, 9, 11, 12);
        m.box(RED, 5, 8, 11, 11, 10, 12);
        m.box(STEEL, 12, 7, 11, 13, 10, 12);
        return m;
    }

    public static final Model NURSE_DESK = reg(nurseDesk());

    private static Model nurseDesk() {
        Model m = new Model("mostrador_enfermeria", 3, 1, 1);
        m.box(WHITE, 0, 0, 2, 48, 14, 6);
        m.box(BIRCH, 0, 14, 1, 48, 16, 7);
        m.box(c(0x48C9B0), 0, 3, 1, 48, 5, 2);
        m.box(RED, 22, 7, 1, 26, 13, 2);
        m.box(RED, 21, 9, 1, 27, 11, 2);
        m.box(WHITE, 0, 9, 6, 48, 10, 16);
        for (int x : new int[]{8, 34}) {
            m.box(BLACK, x + 2, 10, 12, x + 6, 11, 14);
            screen(m, x, 11, x + 8, 16, 11, 1, c(0x5DADE2));
        }
        m.box(c(0xF7DC6F), 20, 10, 9, 28, 11, 14);
        return m;
    }

    // ================================================================== público, culto y transporte

    public static final Model PEW = reg(pew());

    private static Model pew() {
        Model m = new Model("banco_iglesia", 3, 1, 1);
        Mat wd = WALNUT;
        m.box(wd, 0, 0, 2, 2, 15, 14);
        m.box(wd, 46, 0, 2, 48, 15, 14);
        m.box(wd, 0, 15, 4, 2, 16, 14);
        m.box(wd, 46, 15, 4, 48, 16, 14);
        m.box(wd, 2, 6, 4, 46, 7, 12);
        m.box(wd, 2, 7, 12, 46, 16, 14);
        m.box(c(0x5A4030), 2, 3, 6, 46, 6, 7);
        m.box(w(0x7B241C), 2, 2, 0, 46, 3, 3);
        m.box(wd, 2, 0, 1, 46, 2, 2);
        m.box(c(0x5A4030), 2, 12, 14, 46, 13, 16);
        return m;
    }

    public static final Model ALTAR = reg(altar());

    private static Model altar() {
        Model m = new Model("altar", 3, 2, 1);
        m.box(MARBLE, 3, 0, 4, 45, 14, 14);
        m.box(QUARTZ, 2, 14, 3, 46, 15, 15);
        m.box(w(0xFFFFFF), 2, 8, 2, 46, 15, 3);
        m.box(GOLD, 2, 8, 2, 46, 9, 3);
        m.box(GOLD, 22, 9, 1, 26, 14, 2);
        for (int x : new int[]{8, 40}) {
            m.cylY(GOLD, x, 9, 1.6, 15, 17);
            m.cylY(GOLD, x, 9, 0.6, 17, 21);
            m.cylY(WHITE, x, 9, 0.9, 21, 27);
            m.box(WARM, x - 1, 27, 8, x, 28, 9);
        }
        m.box(GOLD, 23, 15, 11, 25, 31, 13);
        m.box(GOLD, 19, 25, 11, 29, 27, 13);
        m.cylY(c(0x2E4A7A), 15, 9, 1.5, 15, 19);
        m.sphere(c(0xF5F5F5), 15, 20, 9, 1.8);
        m.cylY(c(0x2E4A7A), 33, 9, 1.5, 15, 19);
        m.sphere(c(0xF5F5F5), 33, 20, 9, 1.8);
        m.box(c(0x922B21), 20, 15, 4, 28, 16, 9);
        return m;
    }

    public static final Model CANDLE_STAND = reg(candleStand());

    private static Model candleStand() {
        Model m = new Model("candelabro", 1, 2, 1);
        m.cylY(GOLD, 8, 8, 3.6, 0, 1);
        m.cylY(GOLD, 8, 8, 1.6, 1, 3);
        m.cylY(GOLD, 8, 8, 0.8, 3, 20);
        m.box(GOLD, 2, 19, 7, 14, 20, 9);
        for (int x : new int[]{2, 7, 13}) {
            m.box(GOLD, x, 20, 7, x + 1, 22, 9);
            m.box(WHITE, x, 22, 7, x + 1, 27, 9);
            m.box(WARM, x, 27, 7, x + 1, 28, 8);
        }
        m.box(GOLD, 7, 19, 2, 9, 20, 14);
        for (int z : new int[]{2, 13}) {
            m.box(GOLD, 7, 20, z, 9, 22, z + 1);
            m.box(WHITE, 7, 22, z, 9, 26, z + 1);
            m.box(WARM, 7, 26, z, 8, 27, z + 1);
        }
        return m;
    }

    public static final Model ORGAN = reg(organ());

    private static Model organ() {
        Model m = new Model("organo", 3, 3, 1);
        m.box(WALNUT, 0, 0, 6, 48, 16, 16);
        m.box(WALNUT, 0, 16, 10, 48, 18, 16);
        m.box(WALNUT, 4, 7, 2, 44, 9, 6);
        m.box(WHITE, 6, 9, 2, 42, 10, 6);
        for (int x = 6; x < 42; x++) if ((x % 7) % 3 != 2) m.box(BLACK, x, 10, 4, x + 1, 11, 6);
        m.box(WALNUT, 6, 11, 5, 42, 16, 6);
        for (int i = 0; i < 15; i++) {
            int x = 2 + i * 3;
            int h = 32 + (int) Math.round(12 * (1 - Math.abs(i - 7) / 7.0));
            m.cylY(STEEL, x + 1, 12, 1.3, 18, Math.min(47, 18 + h - 16));
            m.box(BLACK, x + 1, 22, 10, x + 2, 23, 11);
        }
        m.box(GOLD, 0, 18, 9, 48, 19, 10);
        m.box(WALNUT, 10, 0, 0, 38, 5, 3);
        return m;
    }

    public static final Model FONT = reg(baptismalFont());

    private static Model baptismalFont() {
        Model m = new Model("pila_bautismal", 1, 1, 1);
        m.cylY(STONE, 8, 8, 4.5, 0, 2);
        m.cylY(STONE, 8, 8, 2, 2, 9);
        m.cylY(MARBLE, 8, 8, 6.5, 9, 13);
        m.cylY(null, 8, 8, 5.3, 11, 13);
        m.cylY(WATER, 8, 8, 5.3, 11, 12);
        m.cylY(GOLD, 8, 8, 6.6, 12, 13);
        m.cylY(null, 8, 8, 5.9, 12, 13);
        return m;
    }

    public static final Model FLAG = reg(flag());

    private static Model flag() {
        Model m = new Model("bandera", 1, 3, 1);
        m.cylY(GOLD, 8, 8, 3.6, 0, 2);
        m.cylY(WALNUT, 8, 8, 0.9, 2, 44);
        m.sphere(GOLD, 8, 45, 8, 1.6);
        for (int i = 0; i < 9; i++) {
            Mat s = i % 2 == 0 ? WHITE : c(0x2E6DB4);
            m.box(s, 0, 42 - (i + 1) * 2, 7, 7, 42 - i * 2, 9);
        }
        m.box(WHITE, 0, 32, 7, 4, 42, 9);
        m.sphere(c(0xF4D03F), 2, 37, 8, 1.6);
        return m;
    }

    public static final Model TURNSTILE = reg(turnstile());

    private static Model turnstile() {
        Model m = new Model("molinete", 1, 1, 1);
        m.box(STEEL, 0, 0, 2, 5, 15, 14);
        m.box(c(0x2C3E50), 0, 15, 2, 5, 16, 14);
        m.box(GREEN_LIT, 1, 15, 3, 4, 16, 5);
        m.box(BLACK, 1, 15, 8, 4, 16, 11);
        m.box(STEEL, 5, 9, 7, 7, 11, 9);
        m.box(STEEL, 7, 9, 7, 15, 10, 8);
        m.box(STEEL, 6, 10, 7, 7, 15, 8);
        m.box(STEEL, 6, 4, 7, 7, 9, 8);
        return m;
    }

    public static final Model INFO_KIOSK = reg(infoKiosk());

    private static Model infoKiosk() {
        Model m = new Model("totem_info", 1, 2, 1);
        m.box(STEEL, 2, 0, 4, 14, 2, 12);
        m.box(c(0x2C3E50), 4, 2, 6, 12, 28, 11);
        screen(m, 4, 12, 12, 26, 5, 1, c(0x1F618D));
        for (int y = 14; y < 22; y += 2) m.box(WHITE, 6, y, 4, 10, y + 1, 5);
        m.cylZ(c(0x5DADE2), 8, 30.5, 1.5, 6, 11);
        m.box(c(0x5DADE2), 4, 28, 6, 12, 29, 11);
        m.box(WHITE, 8, 23, 4, 9, 25, 5);
        return m;
    }

    public static final Model LUGGAGE_CART = reg(luggageCart());

    private static Model luggageCart() {
        Model m = new Model("carro_equipaje", 1, 1, 2);
        m.box(STEEL, 2, 2, 2, 14, 3, 28);
        for (int[] p : new int[][]{{2, 3}, {13, 3}, {2, 26}, {13, 26}}) m.box(BLACK, p[0], 0, p[1], p[0] + 1, 2, p[1] + 2);
        m.box(STEEL, 2, 3, 27, 3, 15, 28);
        m.box(STEEL, 13, 3, 27, 14, 15, 28);
        m.box(BLACK, 2, 14, 27, 14, 15, 29);
        m.box(c(0x1F618D), 3, 3, 4, 13, 10, 16);
        m.box(c(0xC0392B), 4, 10, 6, 12, 14, 14);
        m.box(c(0x2C3E50), 3, 3, 17, 13, 8, 26);
        m.box(BLACK, 7, 14, 9, 9, 15, 11);
        return m;
    }

    public static final Model SUITCASES = reg(suitcases());

    private static Model suitcases() {
        Model m = new Model("valijas", 1, 1, 1);
        m.box(c(0x1F618D), 2, 0, 5, 12, 12, 10);
        m.box(STEEL, 6, 12, 7, 8, 14, 8);
        m.box(STEEL, 5, 13, 7, 9, 14, 8);
        for (int y = 3; y < 12; y += 4) m.box(c(0x1B4F72), 2, y, 4, 12, y + 1, 5);
        m.box(c(0xE74C3C), 10, 0, 6, 15, 9, 10);
        m.box(BLACK, 11, 9, 7, 14, 10, 9);
        m.ellipsoid(c(0x145A32), 8, 2.2, 13, 5.5, 2.2, 2.4);
        m.box(BLACK, 6, 4, 12, 10, 5, 14);
        return m;
    }

    public static final Model STANCHIONS = reg(stanchions());

    private static Model stanchions() {
        Model m = new Model("postes_fila", 2, 1, 1);
        for (int x : new int[]{1, 15, 29}) {
            m.cylY(STEEL, x + 1, 8, 2.5, 0, 1);
            m.cylY(STEEL, x + 1, 8, 0.8, 1, 14);
            m.cylY(STEEL, x + 1, 8, 1.2, 13, 15);
        }
        m.box(c(0xB03A2E), 3, 11, 7, 15, 13, 8);
        m.box(c(0xB03A2E), 17, 11, 7, 29, 13, 8);
        return m;
    }

    public static final Model DRINK_FOUNTAIN = reg(drinkFountain());

    private static Model drinkFountain() {
        Model m = new Model("bebedero", 1, 1, 1);
        m.box(STEEL, 4, 0, 9, 12, 10, 16);
        m.box(STEEL, 2, 10, 4, 14, 13, 16);
        m.cut(4, 12, 6, 12, 13, 13);
        m.box(c(0xBFC5C9), 4, 12, 6, 12, 13, 13);
        m.box(STEEL, 7, 13, 11, 9, 15, 13);
        m.box(STEEL, 7, 14, 9, 8, 15, 11);
        m.box(BLACK, 12, 11, 3, 14, 12, 4);
        return m;
    }

    public static final Model DEPARTURES = reg(departures());

    private static Model departures() {
        Model m = new Model("pantalla_salidas", 2, 1, 1);
        m.box(BLACK, 6, 12, 7, 7, 16, 8);
        m.box(BLACK, 25, 12, 7, 26, 16, 8);
        m.box(c(0x1C2833), 1, 3, 6, 31, 12, 10);
        m.box(BLACK, 2, 4, 5, 30, 11, 6);
        for (int y = 5; y < 11; y += 2) {
            m.box(c(0xF4D03F), 3, y, 5, 8, y + 1, 6);
            m.box(WHITE, 9, y, 5, 22, y + 1, 6);
            m.box(GREEN_LIT, 24, y, 5, 29, y + 1, 6);
        }
        m.box(BLACK, 2, 4, 10, 30, 11, 11);
        for (int y = 5; y < 11; y += 2) m.box(WHITE, 9, y, 10, 22, y + 1, 11);
        return m;
    }

    public static final Model BENCH_METAL = reg(benchMetal());

    private static Model benchMetal() {
        Model m = new Model("banco_metalico", 3, 1, 1);
        Mat st = c(0x85929E);
        for (int x : new int[]{2, 45}) {
            m.box(BLACK, x, 0, 3, x + 1, 6, 13);
            m.box(BLACK, x, 6, 4, x + 1, 7, 12);
        }
        m.box(st, 1, 6, 3, 47, 7, 12);
        m.box(st, 1, 7, 11, 47, 15, 13);
        for (int x = 2; x < 47; x += 2)
            for (int z = 4; z < 11; z += 2) m.box(c(0x5D6D7E), x, 6, z, x + 1, 7, z + 1);
        for (int x : new int[]{16, 31}) m.box(BLACK, x, 7, 4, x + 1, 10, 12);
        return m;
    }

    public static final Model METAL_DETECTOR = reg(metalDetector());

    private static Model metalDetector() {
        Model m = new Model("detector_metales", 1, 3, 1);
        Mat g = c(0x7F8C8D);
        m.box(g, 0, 0, 4, 2, 36, 12);
        m.box(g, 14, 0, 4, 16, 36, 12);
        m.box(g, 0, 36, 4, 16, 41, 12);
        m.box(BLACK, 2, 37, 3, 14, 40, 4);
        m.box(GREEN_LIT, 4, 38, 3, 6, 39, 4);
        m.box(REDSTONE, 10, 38, 3, 12, 39, 4);
        for (int y = 6; y < 34; y += 7) {
            m.box(c(0x566573), 0, y, 3, 2, y + 1, 13);
            m.box(c(0x566573), 14, y, 3, 16, y + 1, 13);
        }
        return m;
    }

    public static final Model FIRE_GEAR = reg(fireGear());

    private static Model fireGear() {
        Model m = new Model("equipo_bomberos", 2, 2, 1);
        m.box(c(0x922B21), 0, 0, 12, 32, 31, 16);
        m.box(c(0x922B21), 0, 22, 4, 32, 23, 16);
        m.box(STEEL, 0, 20, 10, 32, 21, 11);
        for (int i = 0; i < 3; i++) {
            int x = 2 + i * 10;
            Mat coat = c(0xC9A646);
            m.box(coat, x, 6, 6, x + 8, 20, 11);
            m.box(c(0xF4D03F), x, 9, 5, x + 8, 10, 11);
            m.box(STEEL, x, 10, 5, x + 8, 11, 11);
            m.box(c(0xF4D03F), x, 15, 5, x + 8, 16, 11);
            m.box(BLACK, x + 1, 0, 5, x + 4, 4, 10);
            m.box(BLACK, x + 5, 0, 5, x + 8, 4, 10);
            m.ellipsoid(i == 1 ? RED : YELLOW, x + 4, 25, 9, 3.4, 2.4, 3.6);
            m.box(i == 1 ? RED : YELLOW, x, 23, 5, x + 8, 24, 13);
        }
        return m;
    }

    public static final Model HOSE_REEL = reg(hoseReel());

    private static Model hoseReel() {
        Model m = new Model("carrete_manguera", 1, 1, 1);
        m.box(RED, 3, 0, 6, 4, 6, 10);
        m.box(RED, 12, 0, 6, 13, 6, 10);
        for (int x : new int[]{2, 13}) m.cylX(RED, 8, 8, 6.5, x, x + 1);
        m.cylX(c(0xC0392B), 8, 8, 5, 3, 13);
        for (int x = 3; x < 13; x += 2) m.cylX(c(0xE5E7E9), 8, 8, 5.3, x, x + 1);
        m.cylX(STEEL, 8, 8, 1.5, 1, 15);
        m.box(STEEL, 6, 2, 1, 10, 4, 3);
        return m;
    }

    public static final Model EXTINGUISHER = reg(extinguisher());

    private static Model extinguisher() {
        Model m = new Model("matafuegos", 1, 1, 1);
        m.box(STEEL, 6, 6, 14, 10, 7, 16);
        m.cylY(RED, 8, 12.5, 2.3, 1, 11);
        m.sphere(RED, 8, 11, 12.5, 2.2);
        m.box(BLACK, 7, 12, 12, 9, 14, 13);
        m.box(BLACK, 6, 13, 11, 10, 14, 12);
        m.box(BLACK, 5, 4, 11, 6, 13, 12);
        m.box(WHITE, 7, 5, 10, 9, 8, 11);
        return m;
    }

    public static final Model CONES = reg(cones());

    private static Model cones() {
        Model m = new Model("conos", 1, 1, 1);
        for (int[] p : new int[][]{{5, 5, 0}, {11, 10, 0}, {5, 5, 2}}) {
            int x = p[0], z = p[1], y0 = p[2];
            m.box(ORANGE, x - 3, y0, z - 3, x + 3, y0 + 1, z + 3);
            for (int y = 1; y < 10; y++) {
                double r = 2.4 - y * 0.2;
                m.cylY(y >= 4 && y <= 6 ? WHITE : ORANGE, x, z, r, y0 + y, y0 + y + 1);
            }
        }
        return m;
    }

    public static final Model POLICE_MOTO = reg(motorbike("moto_policial", WHITE, c(0x1F3A93)));
    public static final Model SCOOTER = reg(scooter());

    private static Model motorbike(String name, Mat body, Mat accent) {
        Model m = new Model(name, 1, 1, 2);
        for (int z : new int[]{5, 26}) {
            m.cylX(BLACK, 5, z, 4.8, 7, 9);
            m.cylX(STEEL, 5, z, 2, 6, 10);
        }
        m.box(STEEL, 7, 5, 5, 9, 11, 7);
        m.box(STEEL, 7, 9, 6, 9, 11, 10);
        m.box(body, 5, 6, 8, 11, 12, 22);
        m.box(accent, 5, 9, 8, 11, 10, 22);
        m.box(BLACK, 6, 12, 15, 10, 14, 24);
        m.box(body, 5, 9, 22, 11, 13, 29);
        m.box(STEEL, 3, 15, 6, 13, 16, 7);
        m.box(GLASS_B, 5, 15, 7, 11, 21, 8);
        m.box(LIGHT, 7, 11, 3, 9, 13, 5);
        m.box(BLUE, 5, 13, 28, 7, 15, 29);
        m.box(RED, 9, 13, 28, 11, 15, 29);
        m.box(STEEL, 4, 4, 16, 5, 6, 26);
        return m;
    }

    private static Model scooter() {
        Model m = new Model("moto", 1, 1, 2);
        Mat body = c(0x76D7C4);
        for (int z : new int[]{5, 26}) {
            m.cylX(BLACK, 3.5, z, 3.4, 7, 9);
            m.cylX(STEEL, 3.5, z, 1.4, 6, 10);
        }
        m.box(body, 6, 2, 3, 10, 14, 7);
        m.box(body, 5, 4, 7, 11, 5, 20);
        m.ellipsoid(body, 8, 7, 24, 3.5, 4, 6);
        m.box(c(0x6E2C00), 6, 10, 17, 10, 12, 27);
        m.box(STEEL, 3, 14, 4, 13, 15, 6);
        m.box(LIGHT, 7, 12, 2, 9, 14, 3);
        m.box(BLACK, 6, 14, 4, 10, 16, 6);
        m.box(RED, 7, 7, 30, 9, 9, 31);
        return m;
    }

    public static final Model BICYCLE = reg(bicycle());

    private static Model bicycle() {
        Model m = new Model("bicicleta", 2, 1, 1);
        Mat fr = c(0xC0392B);
        for (int x : new int[]{6, 26}) {
            m.cylZ(BLACK, x, 6, 5.5, 7, 9);
            m.cylZ(null, x, 6, 4.4, 7, 9);
            m.cylZ(STEEL, x, 6, 1, 7, 9);
        }
        for (int i = 0; i <= 10; i++) {
            int x = 6 + i * 2, y = 6 + (int) Math.round(i * 0.5);
            m.box(fr, x, y, 7, x + 2, y + 1, 9);
        }
        for (int i = 0; i <= 6; i++) m.box(fr, 15 - i, 6 + i, 7, 16 - i, 7 + i, 9);
        m.box(fr, 15, 6, 7, 17, 13, 9);
        m.box(fr, 9, 11, 7, 24, 12, 9);
        m.box(fr, 24, 6, 7, 25, 14, 9);
        m.box(BLACK, 13, 13, 6, 18, 14, 10);
        m.box(STEEL, 23, 14, 4, 26, 15, 12);
        m.box(BLACK, 23, 14, 3, 26, 15, 4);
        m.box(BLACK, 23, 14, 12, 26, 15, 13);
        m.cylZ(STEEL, 16, 6, 1.6, 6, 10);
        return m;
    }
}
