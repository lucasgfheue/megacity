package com.megaciudad.core.gen;

import com.megaciudad.core.B;
import com.megaciudad.core.BlockRef;
import com.megaciudad.core.Canvas;
import com.megaciudad.core.Rng;

/** Árboles deterministas con bloques vanilla (hojas persistentes), recortados por chunk. */
public final class Trees {
    private Trees() {
    }

    private static final String[] WOODS = {"oak", "birch", "spruce", "cherry", "dark_oak", "jungle", "acacia"};

    /** Copa elipsoidal irregular. No pisa troncos. */
    static void canopy(Canvas c, double cx, double cy, double cz, double rx, double ry, double rz, BlockRef leaf, long seed) {
        int x0 = (int) Math.floor(cx - rx), x1 = (int) Math.ceil(cx + rx);
        int y0 = (int) Math.floor(cy - ry), y1 = (int) Math.ceil(cy + ry);
        int z0 = (int) Math.floor(cz - rz), z1 = (int) Math.ceil(cz + rz);
        if (!c.overlaps(x0, z0, x1, z1)) return;
        for (int y = y0; y <= y1; y++)
            for (int z = z0; z <= z1; z++)
                for (int x = x0; x <= x1; x++) {
                    double dx = (x - cx) / rx, dy = (y - cy) / ry, dz = (z - cz) / rz;
                    double d = dx * dx + dy * dy + dz * dz;
                    double n = Rng.unit(seed, x, y, z) * 0.45;
                    if (d <= 0.78 + n) c.set(x, y, z, leaf);
                }
    }

    /** Árbol de vereda: tronco fino de 4 y copa redondeada. */
    public static void street(Canvas c, int x, int y, int z, long seed) {
        Rng r = new Rng(seed);
        int kind = r.nextInt(4);
        String wood = kind == 0 ? "oak" : kind == 1 ? "birch" : kind == 2 ? "oak" : "cherry";
        BlockRef leaf = B.leaves(kind == 3 ? "cherry" : kind == 1 ? "birch" : r.chance(0.5) ? "oak" : "azalea");
        int h = r.range(4, 5);
        canopy(c, x + 0.5, y + h - 0.4, z + 0.5, 1.95, 1.6, 1.95, leaf, seed);
        c.fill(x, y, z, x, y + h - 1, z, B.log(wood, "y"));
    }

    /** Árbol de parque grande. */
    public static void park(Canvas c, int x, int y, int z, long seed) {
        Rng r = new Rng(seed);
        String wood = WOODS[r.nextInt(WOODS.length)];
        String leafType = wood.equals("jungle") ? "jungle" : wood.equals("acacia") ? "acacia" : wood;
        BlockRef log = B.log(wood, "y");
        BlockRef leaf = B.leaves(leafType);
        if (!c.overlaps(x - 6, z - 6, x + 6, z + 6)) return;
        switch (wood) {
            case "spruce" -> {
                int h = r.range(9, 13);
                for (int i = 0; i < h - 2; i++) {
                    double rad = Math.max(0.8, (h - i) * 0.32);
                    if (i < 3) continue;
                    canopy(c, x + 0.5, y + i, z + 0.5, rad, 0.6, rad, leaf, seed + i);
                }
                c.set(x, y + h, z, leaf);
                c.fill(x, y, z, x, y + h - 1, z, log);
            }
            case "birch" -> {
                int h = r.range(7, 9);
                canopy(c, x + 0.5, y + h - 1.5, z + 0.5, 2.4, 3, 2.4, leaf, seed);
                c.fill(x, y, z, x, y + h - 1, z, log);
            }
            case "dark_oak" -> {
                int h = r.range(6, 8);
                canopy(c, x + 1, y + h - 0.5, z + 1, 4.2, 2.5, 4.2, leaf, seed);
                c.fill(x, y, z, x + 1, y + h - 1, z + 1, log);
            }
            default -> {
                int h = r.range(5, 8);
                double rad = r.range(28, 38) / 10.0;
                canopy(c, x + 0.5, y + h - 0.5, z + 0.5, rad, rad * 0.75, rad, leaf, seed);
                if (r.chance(0.5)) canopy(c, x + 1.8, y + h - 2, z + 0.2, rad * 0.6, rad * 0.5, rad * 0.6, leaf, seed + 7);
                c.fill(x, y, z, x, y + h - 1, z, log);
                if (h > 6) {
                    c.set(x + 1, y + h - 3, z, B.log(wood, "x"));
                    c.set(x - 1, y + h - 2, z, B.log(wood, "x"));
                }
            }
        }
    }

    /** Arbusto chico de hojas. */
    public static void bush(Canvas c, int x, int y, int z, long seed) {
        Rng r = new Rng(seed);
        BlockRef leaf = B.leaves(r.chance(0.5) ? "azalea" : r.chance(0.5) ? "flowering_azalea" : "oak");
        canopy(c, x + 0.5, y + 0.3, z + 0.5, 1.4, 1.0, 1.4, leaf, seed);
    }
}
