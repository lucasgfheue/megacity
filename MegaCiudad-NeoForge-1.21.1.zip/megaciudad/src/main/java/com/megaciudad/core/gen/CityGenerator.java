package com.megaciudad.core.gen;

import com.megaciudad.core.BlockSink;
import com.megaciudad.core.Canvas;
import com.megaciudad.core.build.Buildings;
import com.megaciudad.core.layout.AxisLayout;
import com.megaciudad.core.layout.CityLayout;
import com.megaciudad.core.layout.LotPlanner;
import com.megaciudad.core.layout.Plot;

import java.util.List;

/**
 * Punto de entrada del generador: produce todo el contenido de la ciudad que cae dentro de un
 * chunk. Es puro Java (sin Minecraft): el mod y el renderizador de prueba usan el mismo código.
 */
public final class CityGenerator {
    public final CityLayout L;
    private final LotPlanner planner;
    private final Streets streets;
    private final Metro metro;
    @SuppressWarnings("unchecked")
    private final List<Plot>[] plans = new List[AxisLayout.LOTS * AxisLayout.LOTS];

    public CityGenerator(int centerX, int centerZ, long seed) {
        this.L = new CityLayout(centerX, centerZ, seed);
        this.planner = new LotPlanner(L);
        this.streets = new Streets(L);
        this.metro = new Metro(L);
    }

    public List<Plot> plan(int i, int j) {
        int idx = i * AxisLayout.LOTS + j;
        List<Plot> p = plans[idx];
        if (p == null) {
            p = List.copyOf(planner.plan(i, j));
            plans[idx] = p;
        }
        return p;
    }

    public void generateChunk(BlockSink sink, int cx, int cz) {
        Canvas c = new Canvas(sink, cx * 16, cz * 16, cx * 16 + 15, cz * 16 + 15);
        if (!c.overlaps(L.minX, L.minZ, L.minX + CityLayout.SIZE - 1, L.minZ + CityLayout.SIZE - 1)) return;
        streets.pave(c);
        AxisLayout A = CityLayout.A;
        for (int i = 0; i < AxisLayout.LOTS; i++) {
            if (!c.overlaps(L.lotX0(i), c.z0, L.lotX1(i), c.z1)) continue;
            for (int j = 0; j < AxisLayout.LOTS; j++) {
                if (!c.overlaps(L.lotX0(i), L.lotZ0(j), L.lotX1(i), L.lotZ1(j))) continue;
                for (Plot p : plan(i, j)) {
                    if (c.overlaps(p.x0, p.z0, p.x1, p.z1)) Buildings.build(c, p, this);
                }
            }
        }
        streets.furnish(c);
        metro.build(c);
    }

    /** Punto de aparición sugerido: en la plaza central, frente a la fuente. */
    public int[] spawnPoint() {
        int i = 12, j = 11;
        int x = (L.lotX0(i) + L.lotX1(i)) / 2;
        int z = L.lotZ1(j) - 6;
        return new int[]{x, CityLayout.FLOOR, z};
    }
}
