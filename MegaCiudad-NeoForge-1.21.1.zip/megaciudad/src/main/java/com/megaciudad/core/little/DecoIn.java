package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.concurrent.ConcurrentHashMap;

import static com.megaciudad.core.little.Deco.*;

/** Mobiliario interior y de plazas hecho con mini-bloques (frente al norte, sin losa de vereda). */
public final class DecoIn {
    private DecoIn() {
    }

    private static final ConcurrentHashMap<String, Model> CACHE = new ConcurrentHashMap<>();

    static Mat t(int rgb) {
        return Mat.tint("white_concrete", rgb);
    }

    // ------------------------------------------------------------------ oficinas y halls

    public static final Model RECEPTION = reception();

    private static Model reception() {
        Model m = new Model("recepcion", 3, 2, 1);
        m.box(QUARTZ, 0, 0, 2, 48, 17, 6);
        m.box(QUARTZ, 0, 0, 6, 2, 17, 16);
        m.box(QUARTZ, 46, 0, 6, 48, 17, 16);
        m.box(DARK_OAK, 0, 17, 1, 48, 19, 8);
        m.box(DARK_OAK, 2, 11, 6, 46, 12, 15);
        m.box(SEA, 2, 2, 1, 46, 3, 2);
        Deco.text(m, "INFO", GOLD, 1, 24, 14, 1, 1);
        for (int x : new int[]{12, 30}) {
            m.box(GRAY, x + 2, 12, 11, x + 4, 14, 13);
            m.box(BLACK, x - 1, 14, 10, x + 7, 20, 11);
            m.box(LBLUE, x, 15, 11, x + 6, 19, 12);
            m.box(GRAY, x, 12, 8, x + 6, 13, 10);
        }
        m.box(GOLD, 40, 19, 3, 42, 20, 5);
        m.box(BLACK, 22, 0, 18, 26, 6, 22);
        return m;
    }

    public static final Model SOFA = sofa(Mat.of("gray_wool"), Mat.of("light_gray_wool"), "sofa");
    public static final Model SOFA_RED = sofa(Mat.of("red_wool"), Mat.of("white_wool"), "sofa_rojo");
    public static final Model SOFA_BLUE = sofa(Mat.of("blue_wool"), Mat.of("light_blue_wool"), "sofa_azul");

    private static Model sofa(Mat fab, Mat cush, String name) {
        Model m = new Model(name, 2, 1, 1);
        for (int x : new int[]{1, 29})
            for (int z : new int[]{3, 12}) m.box(DARK_OAK, x, 0, z, x + 2, 2, z + 2);
        m.box(fab, 0, 2, 2, 32, 7, 15);
        m.box(cush, 2, 7, 2, 15, 9, 12);
        m.box(cush, 17, 7, 2, 30, 9, 12);
        m.box(fab, 0, 7, 12, 32, 15, 16);
        m.box(fab, 0, 7, 2, 2, 11, 12);
        m.box(fab, 30, 7, 2, 32, 11, 12);
        m.box(cush, 3, 9, 11, 15, 14, 12);
        m.box(cush, 17, 9, 11, 29, 14, 12);
        return m;
    }

    public static final Model ARMCHAIR = armchair();

    private static Model armchair() {
        Model m = new Model("sillon", 1, 1, 1);
        Mat fab = Mat.of("brown_wool"), cush = Mat.of("white_wool");
        m.box(DARK_OAK, 2, 0, 3, 4, 2, 5).box(DARK_OAK, 12, 0, 3, 14, 2, 5).box(DARK_OAK, 2, 0, 12, 4, 2, 14).box(DARK_OAK, 12, 0, 12, 14, 2, 14);
        m.box(fab, 1, 2, 2, 15, 7, 15);
        m.box(cush, 3, 7, 2, 13, 9, 12);
        m.box(fab, 1, 7, 12, 15, 15, 15);
        m.box(fab, 1, 7, 2, 3, 11, 12);
        m.box(fab, 13, 7, 2, 15, 11, 12);
        return m;
    }

    public static final Model COFFEE_TABLE = coffeeTable();

    private static Model coffeeTable() {
        Model m = new Model("mesa_ratona", 1, 1, 1);
        for (int x : new int[]{2, 13})
            for (int z : new int[]{2, 13}) m.box(IRON, x, 0, z, x + 1, 6, z + 1);
        m.box(IRON, 2, 5, 2, 14, 6, 14);
        m.box(GLASS, 1, 6, 1, 15, 7, 15);
        m.box(RED, 3, 7, 4, 8, 8, 9);
        m.box(BLUE, 3, 8, 5, 7, 9, 8);
        m.cylY(WHITE, 11, 10, 1.6, 7, 11);
        m.sphere(LEAF, 11, 12, 10, 2);
        return m;
    }

    public static final Model PLANT = plant();

    private static Model plant() {
        Model m = new Model("planta", 1, 2, 1);
        m.box(TERRA, 4, 0, 4, 12, 8, 12);
        m.box(TERRA, 3, 7, 3, 13, 9, 13);
        m.box(SOIL, 5, 8, 5, 11, 9, 11);
        m.box(BROWN, 7, 9, 7, 9, 16, 9);
        m.box(LEAF, 3, 15, 3, 13, 25, 13);
        m.box(LEAF_DARK, 2, 17, 5, 14, 23, 11);
        m.box(LEAF_DARK, 5, 17, 2, 11, 23, 14);
        m.box(LEAF, 5, 25, 5, 11, 28, 11);
        return m;
    }

    public static final Model DESK = desk();

    private static Model desk() {
        Model m = new Model("escritorio", 2, 2, 1);
        m.box(BIRCH, 0, 12, 0, 32, 13, 14);
        for (int x : new int[]{1, 30})
            for (int z : new int[]{1, 12}) m.box(IRON, x, 0, z, x + 1, 12, z + 1);
        m.box(BIRCH, 1, 4, 1, 31, 12, 2);
        m.box(BLACK, 15, 13, 3, 17, 16, 5);
        m.box(BLACK, 8, 15, 2, 24, 25, 3);
        m.box(Mat.of("light_blue_concrete"), 9, 16, 3, 23, 24, 4);
        m.box(GRAY, 10, 13, 7, 22, 14, 10);
        m.box(BLACK, 25, 13, 8, 27, 14, 10);
        m.cylY(WHITE, 5, 9, 1.5, 13, 16);
        m.box(WHITE, 26, 13, 2, 30, 14, 6);
        m.box(t(0x8D6E63), 2, 13, 2, 4, 21, 3);
        m.sphere(LEAF, 3, 22, 3, 2.2);
        return m;
    }

    public static final Model OFFICE_CHAIR = officeChair();

    private static Model officeChair() {
        Model m = new Model("silla_oficina", 1, 1, 1);
        m.box(BLACK, 3, 0, 7, 13, 1, 9).box(BLACK, 7, 0, 3, 9, 1, 13);
        m.cylY(BLACK, 8, 8, 1, 1, 7);
        m.box(GRAY, 3, 7, 3, 13, 9, 13);
        m.box(GRAY, 3, 9, 12, 13, 16, 14);
        m.box(BLACK, 3, 10, 4, 4, 11, 11).box(BLACK, 12, 10, 4, 13, 11, 11);
        return m;
    }

    // ------------------------------------------------------------------ supermercado

    private static final int[][] PALETTES = {
            {0xE8A030, 0xD04020, 0xF0D040, 0x8A5020, 0xE06030}, // cereales
            {0x2E7D32, 0x795548, 0xC8E6C9, 0x1565C0, 0xF9A825}, // bebidas
            {0xC62828, 0xB0BEC5, 0x1E88E5, 0xFFB300, 0x6D4C41}, // latas
            {0x1E88E5, 0xFFFFFF, 0xEC407A, 0x26C6DA, 0x7E57C2}, // limpieza
            {0xFF7043, 0xFFEB3B, 0x8BC34A, 0xE91E63, 0x3F51B5}, // golosinas
            {0xFDD835, 0x1976D2, 0xFFF8E1, 0xD84315, 0x43A047}, // fideos y harinas
    };

    /** Góndola de 3 de largo con productos de colores (variant 0..5). */
    public static Model shelf(int variant) {
        return CACHE.computeIfAbsent("shelf" + variant, k -> {
            Model m = new Model("gondola" + variant, 3, 2, 1);
            int[] pal = PALETTES[Math.floorMod(variant, PALETTES.length)];
            m.box(WHITE, 0, 0, 13, 48, 31, 15);
            m.box(GRAY, 0, 0, 0, 48, 3, 13);
            m.box(LGRAY, 0, 0, 0, 1, 31, 15);
            m.box(LGRAY, 47, 0, 0, 48, 31, 15);
            Rng r = new Rng(variant * 7919L + 13);
            int[] levels = {3, 10, 17, 24};
            for (int li = 0; li < levels.length; li++) {
                int y = levels[li];
                if (li > 0) m.box(LGRAY, 1, y, 1, 47, y + 1, 13);
                int x = 2;
                while (x < 45) {
                    int pw = r.range(2, 4), ph = r.range(3, 5), pd = r.range(8, 11);
                    if (x + pw > 46) break;
                    Mat c = t(pal[r.nextInt(pal.length)]);
                    boolean bottle = variant == 1 && r.chance(0.7);
                    boolean can = variant == 2;
                    for (int rep = 0; rep < 2 && x + pw <= 46; rep++) {
                        if (bottle) {
                            m.cylY(c, x + pw / 2.0, 7, pw / 2.0, y + 1, y + 1 + ph);
                            m.cylY(c, x + pw / 2.0, 7, 0.6, y + 1 + ph, y + 2 + ph);
                        } else if (can) m.cylY(c, x + pw / 2.0, 7, pw / 2.0, y + 1, y + 1 + Math.min(ph, 4));
                        else m.box(c, x, y + 1, 2, x + pw, y + 1 + ph, 2 + pd);
                        x += pw + (r.chance(0.3) ? 1 : 0);
                    }
                }
                m.box(YELLOW, 1, y, 0, 47, y + 1, 1);
            }
            return m;
        });
    }

    public static final Model FRIDGE = fridge();

    private static Model fridge() {
        Model m = new Model("heladera", 2, 2, 1);
        m.box(WHITE, 0, 0, 0, 32, 32, 16);
        m.cut(2, 3, 1, 30, 24, 14);
        Rng r = new Rng(77);
        for (int y : new int[]{3, 11, 19}) {
            m.box(IRON, 2, y, 2, 30, y + 1, 14);
            for (int x = 3; x < 29; x += 4) {
                Mat c = r.chance(0.5) ? WHITE : t(new int[]{0x1976D2, 0xFFD54F, 0xE53935, 0x81C784}[r.nextInt(4)]);
                m.box(c, x, y + 1, 6, x + 3, y + 1 + r.range(4, 6), 10);
            }
        }
        m.box(SEA, 2, 23, 2, 30, 24, 13);
        m.box(GLASS, 1, 3, 0, 31, 24, 1);
        m.box(IRON, 15, 3, 0, 17, 24, 1);
        m.box(BLACK, 13, 10, 0, 14, 16, 1).box(BLACK, 18, 10, 0, 19, 16, 1);
        m.box(BLUE, 0, 24, 0, 32, 32, 1);
        Deco.text(m, "FRIO", WHITE, 1, 16, 32, 0, 1);
        return m;
    }

    public static final Model CHECKOUT = checkout();

    /** Caja registradora con cinta, 2 de ancho (cajero al este) x 3 de largo. */
    private static Model checkout() {
        Model m = new Model("caja", 2, 2, 3);
        m.box(LGRAY, 0, 0, 0, 14, 14, 48);
        m.box(BLACK, 1, 14, 2, 13, 15, 30);
        m.box(GRAY, 0, 14, 0, 14, 15, 2);
        m.box(WHITE, 4, 14, 32, 13, 17, 40);
        m.box(BLACK, 6, 17, 34, 12, 22, 35);
        m.box(Mat.of("light_blue_concrete"), 7, 18, 35, 11, 21, 36);
        m.box(GRAY, 2, 14, 42, 6, 16, 45);
        m.box(IRON, 0, 13, 40, 14, 14, 48);
        m.box(GRAY, 6, 15, 10, 8, 16, 12);
        m.box(RED, 0, 3, 0, 14, 5, 48);
        m.cylY(GRAY, 24, 34, 1, 0, 10);
        m.cylY(BLACK, 24, 34, 4, 10, 12);
        m.box(BLACK, 21, 12, 37, 27, 16, 39);
        return m;
    }

    public static final Model CART = cart();

    private static Model cart() {
        Model m = new Model("carrito", 1, 1, 1);
        for (int x : new int[]{3, 12})
            for (int z : new int[]{2, 13}) m.box(BLACK, x, 0, z, x + 1, 2, z + 1);
        m.box(IRON, 3, 2, 2, 13, 3, 14);
        for (int x : new int[]{3, 12})
            for (int z : new int[]{2, 13}) m.box(IRON, x, 2, z, x + 1, 6, z + 1);
        m.box(IRON, 2, 6, 1, 14, 7, 15);
        for (int x = 2; x <= 13; x += 2) {
            m.box(IRON, x, 7, 1, x + 1, 13, 2);
            m.box(IRON, x, 7, 14, x + 1, 13, 15);
        }
        for (int z = 1; z <= 14; z += 2) {
            m.box(IRON, 2, 7, z, 3, 13, z + 1);
            m.box(IRON, 13, 7, z, 14, 13, z + 1);
        }
        m.box(IRON, 2, 12, 1, 14, 13, 15);
        m.box(RED, 2, 14, 15, 14, 15, 16);
        m.box(IRON, 2, 12, 15, 3, 15, 16).box(IRON, 13, 12, 15, 14, 15, 16);
        return m;
    }

    public static final Model FRUIT_STAND = fruitStand();

    private static Model fruitStand() {
        Model m = new Model("fruteria", 2, 1, 1);
        m.box(SPRUCE, 0, 0, 0, 32, 7, 16);
        m.box(DARK_OAK, 0, 7, 0, 32, 8, 16);
        int[][] fruit = {{0xC62828, 0}, {0xF57C00, 1}, {0x7CB342, 0}, {0xFDD835, 2}};
        for (int q = 0; q < 4; q++) {
            int x0 = q * 8;
            m.box(SPRUCE, x0, 8, 0, x0 + 1, 11, 16);
            Mat c = t(fruit[q][0]);
            for (int z = 2; z < 15; z += 3)
                for (int x = x0 + 2; x < x0 + 8; x += 3) {
                    if (fruit[q][1] == 2) m.box(c, x - 1, 8, z - 1, x + 2, 10, z);
                    else m.sphere(c, x + 0.5, 9.5, z + 0.5, 1.6);
                }
        }
        m.box(SPRUCE, 31, 8, 0, 32, 11, 16);
        return m;
    }

    public static final Model BAKERY = bakeryCase();

    private static Model bakeryCase() {
        Model m = new Model("panaderia", 2, 1, 1);
        m.box(WHITE, 0, 0, 0, 32, 9, 16);
        m.box(GLASS, 0, 9, 0, 32, 15, 2);
        m.box(GLASS, 0, 15, 0, 32, 16, 12);
        m.box(IRON, 0, 9, 2, 32, 10, 14);
        Rng r = new Rng(31);
        for (int x = 2; x < 30; x += 4) {
            Mat c = t(new int[]{0xC8873A, 0xA0602A, 0xE8C080, 0xF5E6C8}[r.nextInt(4)]);
            m.ellipsoid(c, x + 1.5, 11, 6, 2, 1.3, 3);
        }
        m.box(DARK_OAK, 0, 0, 0, 32, 1, 16);
        return m;
    }

    // ------------------------------------------------------------------ shopping

    public static Model clothesRack(int variant) {
        return CACHE.computeIfAbsent("rack" + variant, k -> {
            Model m = new Model("perchero" + variant, 2, 2, 1);
            m.box(IRON, 0, 0, 4, 3, 1, 12).box(IRON, 29, 0, 4, 32, 1, 12);
            m.box(IRON, 1, 1, 7, 2, 24, 9).box(IRON, 30, 1, 7, 31, 24, 9);
            m.box(IRON, 1, 24, 7, 31, 25, 9);
            Rng r = new Rng(variant * 31L + 5);
            int[][] pals = {{0xE53935, 0xFFFFFF, 0x1E88E5, 0x212121}, {0xF8BBD0, 0xCE93D8, 0xFFF59D, 0x80DEEA},
                    {0x5D4037, 0x8D6E63, 0x455A64, 0x9E9E9E}, {0x43A047, 0xFDD835, 0xFB8C00, 0x1565C0}};
            int[] pal = pals[Math.floorMod(variant, pals.length)];
            for (int x = 3; x < 29; x += 3) {
                Mat c = t(pal[r.nextInt(pal.length)]);
                int len = r.range(10, 15);
                m.box(c, x, 24 - len, 4, x + 2, 23, 12);
                m.box(IRON, x + 1, 23, 7, x + 2, 24, 8);
            }
            return m;
        });
    }

    public static Model mannequin(int variant) {
        return CACHE.computeIfAbsent("mannequin" + variant, k -> {
            Model m = new Model("maniqui" + variant, 1, 2, 1);
            int[][] pal = {{0xC62828, 0x263238}, {0xFFFFFF, 0x1565C0}, {0x2E7D32, 0xD7CCC8}, {0xF06292, 0x424242}, {0xFFB300, 0x3E2723}};
            int[] p = pal[Math.floorMod(variant, pal.length)];
            Mat top = t(p[0]), bottom = t(p[1]);
            m.cylY(GRAY, 8, 8, 4, 0, 1);
            m.box(IRON, 7, 1, 7, 9, 6, 9);
            m.box(bottom, 5, 6, 6, 7, 16, 10).box(bottom, 9, 6, 6, 11, 16, 10);
            m.box(top, 4, 16, 5, 12, 25, 11);
            m.box(top, 2, 17, 6, 4, 24, 10).box(top, 12, 17, 6, 14, 24, 10);
            m.box(WHITE, 2, 15, 7, 4, 17, 9).box(WHITE, 12, 15, 7, 14, 17, 9);
            m.box(WHITE, 7, 25, 7, 9, 26, 9);
            m.ellipsoid(WHITE, 8, 28.5, 8, 2.5, 3, 2.5);
            return m;
        });
    }

    public static final Model DISPLAY_TABLE = displayTable();

    private static Model displayTable() {
        Model m = new Model("mesa_exhibidora", 2, 1, 1);
        m.box(WHITE, 1, 0, 1, 31, 10, 15);
        m.box(OAK, 0, 10, 0, 32, 11, 16);
        Rng r = new Rng(19);
        for (int x = 2; x < 30; x += 5)
            for (int z = 2; z < 14; z += 6) {
                Mat c = t(new int[]{0xEF5350, 0x42A5F5, 0x66BB6A, 0xFFCA28, 0xAB47BC, 0xFFFFFF}[r.nextInt(6)]);
                m.box(c, x, 11, z, x + 4, 11 + r.range(1, 3), z + 4);
            }
        return m;
    }

    /** Mesa redonda con 4 sillas (2x2). */
    public static Model foodTable(int variant) {
        return CACHE.computeIfAbsent("foodtable" + variant, k -> {
            Model m = new Model("mesa_patio" + variant, 2, 1, 2);
            Mat chair = new Mat[]{RED, Mat.of("orange_concrete"), Mat.of("lime_concrete"), LBLUE}[Math.floorMod(variant, 4)];
            m.cylY(GRAY, 16, 16, 3, 0, 1);
            m.cylY(GRAY, 16, 16, 1, 1, 11);
            m.cylY(WHITE, 16, 16, 7, 11, 12);
            m.cylY(t(0xE0E0E0), 16, 16, 7.3, 10, 11);
            int[][] pos = {{16, 3, 0}, {16, 29, 2}, {3, 16, 3}, {29, 16, 1}};
            for (int[] p : pos) {
                int x = p[0], z = p[1];
                m.box(chair, x - 3, 7, z - 3, x + 3, 8, z + 3);
                for (int dx : new int[]{-3, 2})
                    for (int dz : new int[]{-3, 2}) m.box(GRAY, x + dx, 0, z + dz, x + dx + 1, 7, z + dz + 1);
                switch (p[2]) {
                    case 0 -> m.box(chair, x - 3, 8, z - 3, x + 3, 15, z - 2);
                    case 2 -> m.box(chair, x - 3, 8, z + 2, x + 3, 15, z + 3);
                    case 3 -> m.box(chair, x - 3, 8, z - 3, x - 2, 15, z + 3);
                    default -> m.box(chair, x + 2, 8, z - 3, x + 3, 15, z + 3);
                }
            }
            m.cylY(WHITE, 13, 15, 1.4, 12, 13);
            m.box(t(0xFFB74D), 17, 12, 16, 21, 13, 19);
            return m;
        });
    }

    /** Mesa de café con sombrilla (3x3x3, mesa en el centro). */
    public static Model parasolTable(int variant) {
        return CACHE.computeIfAbsent("parasol" + variant, k -> {
            Model m = new Model("sombrilla" + variant, 3, 3, 3);
            Mat cloth = new Mat[]{RED, Mat.of("green_concrete"), Mat.of("blue_concrete"), Mat.of("orange_concrete")}[Math.floorMod(variant, 4)];
            m.cylY(GRAY, 24, 24, 4, 0, 1);
            m.cylY(IRON, 24, 24, 0.8, 1, 40);
            m.cylY(WHITE, 24, 24, 6, 11, 12);
            for (int y = 0; y < 6; y++) {
                double rad = 21 - y * 3.3;
                m.cylY(y % 2 == 0 ? cloth : WHITE, 24, 24, rad, 34 + y, 35 + y);
            }
            int[][] ch = {{24, 13}, {24, 35}, {13, 24}, {35, 24}};
            for (int[] p : ch) {
                m.box(DARK_OAK, p[0] - 3, 7, p[1] - 3, p[0] + 3, 8, p[1] + 3);
                for (int dx : new int[]{-3, 2})
                    for (int dz : new int[]{-3, 2}) m.box(BLACK, p[0] + dx, 0, p[1] + dz, p[0] + dx + 1, 7, p[1] + dz + 1);
            }
            m.box(DARK_OAK, 21, 8, 10, 27, 14, 11).box(DARK_OAK, 21, 8, 37, 27, 14, 38);
            m.box(DARK_OAK, 10, 8, 21, 11, 14, 27).box(DARK_OAK, 37, 8, 21, 38, 14, 27);
            m.cylY(WHITE, 22, 26, 1.3, 12, 15);
            return m;
        });
    }

    public static final Model ATM = atm();

    private static Model atm() {
        Model m = new Model("cajero", 1, 2, 1);
        m.box(GRAY, 1, 0, 3, 15, 26, 16);
        m.box(BLACK, 3, 16, 2, 13, 23, 3);
        m.box(Mat.of("light_blue_concrete"), 4, 17, 2, 12, 22, 3);
        m.box(LGRAY, 4, 11, 1, 12, 14, 3);
        m.box(BLACK, 10, 15, 2, 13, 16, 3);
        m.box(BLUE, 1, 26, 3, 15, 31, 16);
        Deco.text(m, "$", WHITE, 1, 8, 31, 2, 1);
        m.box(SEA, 2, 24, 2, 14, 25, 3);
        return m;
    }

    public static final Model TICKET_MACHINE = ticketMachine();

    private static Model ticketMachine() {
        Model m = new Model("maquina_boletos", 1, 2, 1);
        m.box(Mat.of("orange_concrete"), 1, 0, 3, 15, 28, 15);
        m.box(BLACK, 3, 15, 2, 13, 24, 3);
        m.box(Mat.of("light_blue_concrete"), 4, 16, 2, 12, 23, 3);
        m.box(LGRAY, 4, 9, 2, 12, 13, 3);
        m.box(BLACK, 6, 4, 2, 10, 6, 3);
        m.box(WHITE, 1, 28, 3, 15, 31, 15);
        m.box(SEA, 2, 25, 2, 14, 26, 3);
        return m;
    }

    public static final Model CLOCK = clock();

    /** Reloj de estación colgante, doble faz. */
    private static Model clock() {
        Model m = new Model("reloj", 1, 2, 1);
        m.box(BLACK, 7, 22, 7, 9, 32, 9);
        m.cylZ(BLACK, 8, 14, 7.2, 5, 11);
        m.cylZ(WHITE, 8, 14, 6.2, 4, 12);
        for (int side : new int[]{4, 11}) {
            m.box(BLACK, 7, 14, side, 9, 19, side + 1);
            m.box(BLACK, 8, 13, side, 12, 15, side + 1);
            m.box(RED, 8, 9, side, 9, 14, side + 1);
        }
        return m;
    }

    public static final Model TV = tv();

    private static Model tv() {
        Model m = new Model("tele", 2, 2, 1);
        m.box(DARK_OAK, 0, 0, 3, 32, 8, 15);
        m.box(BLACK, 1, 2, 2, 15, 7, 3).box(BLACK, 17, 2, 2, 31, 7, 3);
        m.box(BLACK, 15, 8, 9, 17, 10, 11);
        m.box(BLACK, 2, 10, 8, 30, 26, 10);
        m.box(t(0x1A237E), 3, 11, 7, 29, 25, 8);
        m.box(t(0x4FC3F7), 5, 13, 7, 14, 20, 8);
        m.box(t(0x81C784), 15, 13, 7, 27, 22, 8);
        return m;
    }

    public static final Model COUNTER = counter();

    /** Mostrador de comercio con registradora (3 de largo). */
    private static Model counter() {
        Model m = new Model("mostrador", 3, 2, 1);
        m.box(OAK, 0, 0, 2, 48, 15, 14);
        m.box(DARK_OAK, 0, 15, 1, 48, 16, 15);
        m.box(BIRCH, 0, 1, 1, 48, 14, 2);
        m.box(GRAY, 30, 16, 5, 40, 19, 12);
        m.box(BLACK, 32, 19, 9, 38, 24, 10);
        m.box(LIME, 33, 20, 8, 37, 23, 9);
        m.box(WHITE, 6, 16, 6, 12, 17, 12);
        return m;
    }

    public static final Model COFFEE_MACHINE = coffeeMachine();

    private static Model coffeeMachine() {
        Model m = new Model("cafetera", 1, 1, 1);
        m.box(IRON, 2, 0, 4, 14, 14, 14);
        m.box(BLACK, 3, 4, 3, 13, 9, 4);
        m.box(WHITE, 5, 3, 2, 7, 6, 4).box(WHITE, 9, 3, 2, 11, 6, 4);
        m.box(RED, 3, 11, 3, 5, 13, 4);
        m.box(BLACK, 2, 14, 4, 14, 16, 14);
        return m;
    }

    // ------------------------------------------------------------------ salud y educación

    public static final Model HOSPITAL_BED = hospitalBed();

    private static Model hospitalBed() {
        Model m = new Model("cama_hospital", 1, 2, 2);
        for (int x : new int[]{1, 14})
            for (int z : new int[]{2, 29}) {
                m.box(IRON, x, 2, z, x + 1, 6, z + 1);
                m.box(BLACK, x, 0, z, x + 1, 2, z + 1);
            }
        m.box(IRON, 1, 5, 1, 15, 6, 31);
        m.box(WHITE, 1, 6, 1, 15, 9, 31);
        m.box(Mat.of("white_wool"), 3, 9, 2, 13, 11, 7);
        m.box(LBLUE, 1, 9, 10, 15, 10, 31);
        m.box(IRON, 1, 6, 0, 15, 15, 1);
        m.box(IRON, 1, 6, 31, 15, 12, 32);
        m.box(IRON, 0, 10, 8, 1, 11, 24).box(IRON, 15, 10, 8, 16, 11, 24);
        m.box(IRON, 15, 0, 0, 16, 28, 1);
        m.box(IRON, 12, 27, 0, 16, 28, 1);
        m.box(GLASS_BLUE, 12, 20, 0, 14, 26, 1);
        return m;
    }

    public static final Model SCHOOL_DESK = schoolDesk();

    private static Model schoolDesk() {
        Model m = new Model("pupitre", 1, 1, 1);
        m.box(BIRCH, 2, 11, 1, 14, 12, 8);
        m.box(IRON, 2, 0, 1, 3, 11, 2).box(IRON, 13, 0, 1, 14, 11, 2).box(IRON, 2, 0, 7, 3, 11, 8).box(IRON, 13, 0, 7, 14, 11, 8);
        m.box(GRAY, 3, 8, 2, 13, 9, 7);
        m.box(BLUE, 4, 7, 10, 12, 8, 15);
        m.box(IRON, 4, 0, 10, 5, 7, 11).box(IRON, 11, 0, 10, 12, 7, 11).box(IRON, 4, 0, 14, 5, 7, 15).box(IRON, 11, 0, 14, 12, 7, 15);
        m.box(BLUE, 4, 8, 14, 12, 15, 15);
        m.box(WHITE, 5, 12, 3, 10, 13, 6);
        return m;
    }

    /** Pizarrón de pared: el fondo queda contra la pared (z=16). */
    public static final Model CHALKBOARD = chalkboard();

    private static Model chalkboard() {
        Model m = new Model("pizarron", 3, 2, 1);
        m.box(DARK_OAK, 0, 4, 14, 48, 30, 16);
        m.box(t(0x2E4A3A), 1, 5, 13, 47, 29, 14);
        Deco.text(m, "2+2=4", WHITE, 1, 24, 26, 12, 1);
        m.box(DARK_OAK, 0, 4, 11, 48, 5, 14);
        m.box(WHITE, 8, 5, 12, 11, 6, 13);
        return m;
    }

    // ------------------------------------------------------------------ servicio y plazas

    public static final Model FUEL_PUMP = fuelPump();

    private static Model fuelPump() {
        Model m = new Model("surtidor", 1, 2, 1);
        m.box(GRAY, 1, 0, 2, 15, 2, 14);
        m.box(WHITE, 2, 2, 4, 14, 27, 12);
        m.box(RED, 2, 25, 4, 14, 31, 12);
        m.box(BLACK, 4, 17, 3, 12, 23, 4);
        m.box(LIME, 5, 19, 2, 9, 21, 3);
        m.box(RED, 10, 19, 2, 11, 21, 3);
        m.box(BLACK, 14, 8, 6, 16, 18, 8);
        m.box(BLACK, 15, 4, 6, 16, 8, 7);
        m.box(YELLOW, 3, 10, 3, 6, 13, 4);
        m.box(BLUE, 3, 6, 3, 13, 8, 4);
        return m;
    }

    public static final Model SLIDE = slide();

    private static Model slide() {
        Model m = new Model("tobogan", 1, 2, 3);
        Mat post = YELLOW, deck = RED, chute = LBLUE;
        for (int x : new int[]{0, 14})
            for (int z : new int[]{32, 44}) m.box(post, x, 0, z, x + 2, 31, z + 2);
        m.box(deck, 0, 19, 32, 16, 21, 46);
        m.box(deck, 0, 29, 32, 16, 31, 46);
        for (int y = 4; y < 20; y += 4) m.box(post, 3, y, 46, 13, y + 1, 48);
        m.box(post, 2, 0, 46, 3, 22, 48).box(post, 13, 0, 46, 14, 22, 48);
        for (int z = 0; z < 32; z++) {
            int h = (int) Math.round(19.0 * z / 32.0);
            m.box(chute, 3, h, z, 13, h + 2, z + 1);
            m.box(BLUE, 2, h, z, 3, h + 4, z + 1);
            m.box(BLUE, 13, h, z, 14, h + 4, z + 1);
        }
        return m;
    }

    public static final Model SWINGS = swings();

    private static Model swings() {
        Model m = new Model("hamacas", 3, 2, 1);
        Mat frame = Mat.of("light_blue_concrete");
        m.box(frame, 0, 0, 4, 2, 30, 6).box(frame, 0, 0, 10, 2, 30, 12);
        m.box(frame, 46, 0, 4, 48, 30, 6).box(frame, 46, 0, 10, 48, 30, 12);
        m.box(frame, 0, 28, 7, 48, 30, 9);
        for (int x : new int[]{12, 30}) {
            m.box(IRON, x, 8, 7, x + 1, 28, 8);
            m.box(IRON, x + 5, 8, 7, x + 6, 28, 8);
            m.box(BLACK, x - 1, 7, 5, x + 7, 8, 11);
        }
        return m;
    }

    public static final Model PICNIC_TABLE = picnicTable();

    private static Model picnicTable() {
        Model m = new Model("mesa_picnic", 2, 1, 2);
        m.box(SPRUCE, 0, 12, 6, 32, 13, 26);
        m.box(SPRUCE, 0, 7, 1, 32, 8, 5);
        m.box(SPRUCE, 0, 7, 27, 32, 8, 31);
        for (int x : new int[]{3, 27}) {
            m.box(SPRUCE, x, 0, 4, x + 2, 12, 6);
            m.box(SPRUCE, x, 0, 26, x + 2, 12, 28);
            m.box(SPRUCE, x, 6, 4, x + 2, 7, 28);
        }
        return m;
    }

    public static final Model STATUE = statue();

    private static Model statue() {
        Model m = new Model("estatua", 1, 3, 1);
        Mat bronze = Mat.of("waxed_oxidized_copper");
        m.box(Mat.of("stone_bricks"), 1, 0, 1, 15, 14, 15);
        m.box(ANDESITE, 0, 14, 0, 16, 16, 16);
        m.box(ANDESITE, 0, 0, 0, 16, 2, 16);
        m.box(bronze, 5, 16, 6, 7, 29, 9).box(bronze, 9, 16, 6, 11, 29, 9);
        m.box(bronze, 4, 29, 5, 12, 40, 11);
        m.box(bronze, 12, 34, 7, 14, 46, 9);
        m.box(bronze, 2, 30, 7, 4, 38, 9);
        m.sphere(bronze, 8, 43, 8, 2.8);
        m.box(bronze, 13, 46, 6, 14, 48, 10);
        return m;
    }

    public static final Model PARKING_BOOTH = parkingBarrier();

    private static Model parkingBarrier() {
        Model m = new Model("barrera", 3, 1, 1);
        m.box(YELLOW, 1, 0, 5, 7, 12, 11);
        m.box(BLACK, 1, 9, 4, 7, 11, 5);
        for (int x = 7; x < 47; x += 6) m.box(x % 12 == 7 ? RED : WHITE, x, 9, 7, x + 6, 11, 9);
        return m;
    }
}
