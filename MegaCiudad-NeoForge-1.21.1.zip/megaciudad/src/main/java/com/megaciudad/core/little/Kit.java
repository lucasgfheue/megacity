package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Materiales y piezas comunes para armar muebles con mini-bloques (grilla 16).
 * Convenciones de los modelos: el frente mira al norte (z = 0); los muebles "de pared" apoyan su
 * espalda en z = 16·sz; los de colgar en la pared ocupan solo el fondo de la celda; los de techo
 * cuelgan desde y = 16·sy hacia abajo. Visto de frente, +x queda a la izquierda.
 */
public final class Kit {
    private Kit() {
    }

    private static final ConcurrentHashMap<String, Mat> TINTS = new ConcurrentHashMap<>();

    private static Mat tint(String id, int rgb, int alpha) {
        return TINTS.computeIfAbsent(id + "|" + rgb + "|" + alpha, k -> alpha >= 255 ? Mat.tint(id, rgb) : Mat.tint(id, rgb, alpha));
    }

    /** Hormigón teñido (superficie lisa y mate). */
    public static Mat c(int rgb) {
        return tint("white_concrete", rgb, 255);
    }

    /** Lana teñida (tela, tapizados, ropa). */
    public static Mat w(int rgb) {
        return tint("white_wool", rgb, 255);
    }

    /** Vidrio teñido translúcido. */
    public static Mat g(int rgb, int alpha) {
        return tint("white_stained_glass", rgb, alpha);
    }

    /** Terracota teñida (cerámica, macetas). */
    public static Mat tc(int rgb) {
        return tint("white_terracotta", rgb, 255);
    }

    // ------------------------------------------------------------------ materiales
    public static final Mat OAK = Mat.of("oak_planks"), BIRCH = Mat.of("birch_planks"), SPRUCE = Mat.of("spruce_planks"),
            WALNUT = Mat.of("dark_oak_planks"), CHERRY = Mat.of("cherry_planks"), JUNGLE = Mat.of("jungle_planks"),
            ACACIA = Mat.of("acacia_planks"), MANGROVE = Mat.of("mangrove_planks"), BAMBOO = Mat.of("bamboo_planks"),
            PALE = Mat.of("stripped_birch_wood"), LOGWOOD = Mat.of("stripped_oak_wood");
    public static final Mat WHITE = Mat.of("white_concrete"), BLACK = Mat.of("black_concrete"), GRAY = Mat.of("gray_concrete"),
            LGRAY = Mat.of("light_gray_concrete"), STEEL = Mat.of("iron_block"), GOLD = Mat.of("gold_block"),
            COPPER = Mat.of("waxed_copper_block"), QUARTZ = Mat.of("smooth_quartz"), MARBLE = Mat.of("calcite"),
            STONE = Mat.of("smooth_stone"), DARK = Mat.of("polished_blackstone"), SLATE = Mat.of("polished_deepslate"),
            BRICK = Mat.of("bricks"), GRANITE = Mat.of("polished_granite"), BASALT = Mat.of("smooth_basalt"),
            ANDESITE = Mat.of("polished_andesite"), TUFF = Mat.of("polished_tuff");
    public static final Mat GLASS = Mat.of("glass"), TGLASS = Mat.of("tinted_glass"), GLASS_B = Mat.of("light_blue_stained_glass"),
            GLASS_W = Mat.of("white_stained_glass"), GLASS_G = Mat.of("gray_stained_glass");
    public static final Mat LIGHT = Mat.of("sea_lantern"), WARM = Mat.of("ochre_froglight"), PEARL = Mat.of("pearlescent_froglight"),
            GLOW = Mat.of("glowstone"), FIRE = Mat.of("shroomlight"), GREEN_LIT = Mat.of("verdant_froglight"),
            REDSTONE = Mat.of("redstone_block"), LAPIS = Mat.of("lapis_block"), EMERALD = Mat.of("emerald_block");
    public static final Mat LEAF = Mat.of("moss_block"), LEAF2 = Mat.of("green_wool"), LEAF3 = Mat.of("lime_wool"),
            SOIL = Mat.of("rooted_dirt"), POT = Mat.of("terracotta"), HAY = Mat.of("hay_block"), BOOKS = Mat.of("bookshelf");
    public static final Mat CARDBOARD = c(0xB88A55), CORK = c(0xB07B4A), LEATHER = c(0x5A3522), LEATHER_D = c(0x2A2422),
            CREAM = c(0xF2E8D0), SCREEN = c(0x15202B), SKIN = c(0xE8C4A0), CHROME = Mat.of("iron_block");
    public static final Mat RED = Mat.of("red_concrete"), BLUE = Mat.of("blue_concrete"), LBLUE = Mat.of("light_blue_concrete"),
            YELLOW = Mat.of("yellow_concrete"), ORANGE = Mat.of("orange_concrete"), GREEN = Mat.of("green_concrete"),
            LIME = Mat.of("lime_concrete"), PINK = Mat.of("pink_concrete"), PURPLE = Mat.of("purple_concrete"),
            CYAN = Mat.of("cyan_concrete"), BROWN = Mat.of("brown_concrete"), MAGENTA = Mat.of("magenta_concrete");
    public static final Mat WATER = Mat.tint("light_blue_stained_glass", 0x4FA3E0, 190);

    /** Paleta de colores vivos para productos, libros y juguetes. */
    public static final int[] VIVID = {0xE53935, 0x1E88E5, 0x43A047, 0xFDD835, 0xFB8C00, 0x8E24AA, 0x00ACC1, 0xF06292,
            0x6D4C41, 0x3949AB, 0xC0CA33, 0xFFFFFF, 0x212121, 0x26A69A};
    public static final int[] BOOK = {0x8E2B2B, 0x2B4C8E, 0x2E6B3A, 0xC9A227, 0x5B3A29, 0x7A2E6B, 0x1F5F6B, 0xD9D2C0,
            0x3A3A3A, 0xA0522D, 0x6B8E23, 0x4A6FA5};

    // ------------------------------------------------------------------ piezas

    /** Cuatro patas de grosor t en las esquinas interiores del rectángulo [x0,x1) x [z0,z1), de y0 a y1. */
    public static void legs(Model m, Mat mat, int x0, int z0, int x1, int z1, int y0, int y1, int t) {
        m.box(mat, x0, y0, z0, x0 + t, y1, z0 + t);
        m.box(mat, x1 - t, y0, z0, x1, y1, z0 + t);
        m.box(mat, x0, y0, z1 - t, x0 + t, y1, z1);
        m.box(mat, x1 - t, y0, z1 - t, x1, y1, z1);
    }

    /** Mesa: tapa de espesor 1 a la altura top (tapa = [top-1, top)) y cuatro patas. */
    public static void table(Model m, Mat topMat, Mat legMat, int x0, int z0, int x1, int z1, int top, int legT) {
        m.box(topMat, x0, top - 1, z0, x1, top, z1);
        legs(m, legMat, x0 + 1, z0 + 1, x1 - 1, z1 - 1, 0, top - 1, legT);
    }

    /** Hilera de libros sobre un estante en y0, entre x0 y x1, ocupando de z0 a z1. */
    public static void books(Model m, Rng r, int x0, int x1, int y0, int z0, int z1, int hMin, int hMax) {
        int x = x0;
        while (x < x1) {
            int bw = r.chance(0.25) ? 2 : 1;
            if (x + bw > x1) bw = x1 - x;
            if (r.chance(0.08) && x + 3 <= x1) {
                x += r.range(1, 2); // hueco
                continue;
            }
            int h = r.range(hMin, hMax);
            int d = z1 - z0 - r.nextInt(2);
            m.box(c(BOOK[r.nextInt(BOOK.length)]), x, y0, z1 - d, x + bw, y0 + h, z1);
            x += bw;
        }
    }

    /** Pantalla con marco negro en el plano z (espesor d): imagen en el interior. */
    public static void screen(Model m, int x0, int y0, int x1, int y1, int z, int d, Mat img) {
        m.box(BLACK, x0, y0, z, x1, y1, z + d);
        m.box(img, x0 + 1, y0 + 1, z, x1 - 1, y1 - 1, z + Math.min(1, d));
    }

    /** Maceta cilíndrica con tierra. Devuelve la altura del borde. */
    public static int pot(Model m, Mat mat, double cx, double cz, double r, int y0, int h) {
        m.cylY(mat, cx, cz, r, y0, y0 + h);
        m.cylY(SOIL, cx, cz, Math.max(0.8, r - 1), y0 + h - 1, y0 + h);
        return y0 + h;
    }

    /** Taza de 2x2 con asa. */
    public static void cup(Model m, Mat mat, int x, int y, int z) {
        m.box(mat, x, y, z, x + 2, y + 2, z + 2);
        m.box(mat, x + 2, y + 1, z, x + 3, y + 2, z + 1);
    }

    /** Botella cilíndrica con cuello. */
    public static void bottle(Model m, Mat mat, double cx, double cz, int y, int h, double r) {
        m.cylY(mat, cx, cz, r, y, y + h);
        m.cylY(mat, cx, cz, Math.max(0.5, r / 2.2), y + h, y + h + Math.max(2, h / 3));
    }

    /** Almohadón o almohada (caja con esquinas recortadas). */
    public static void cushion(Model m, Mat mat, int x0, int y0, int z0, int x1, int y1, int z1) {
        m.box(mat, x0, y0, z0, x1, y1, z1);
        if (x1 - x0 > 3 && y1 - y0 > 2) {
            m.cut(x0, y1 - 1, z0, x0 + 1, y1, z1);
            m.cut(x1 - 1, y1 - 1, z0, x1, y1, z1);
        }
    }

    /** Silla simple de 16x16 mirando al norte (respaldo al sur). */
    public static void chair(Model m, Mat frame, Mat seat, int ox, int oz, int seatY, int backH) {
        legs(m, frame, ox + 3, oz + 3, ox + 13, oz + 13, 0, seatY - 1, 1);
        m.box(seat, ox + 3, seatY - 1, oz + 3, ox + 13, seatY + 1, oz + 13);
        m.box(frame, ox + 3, seatY + 1, oz + 12, ox + 4, seatY + backH, oz + 13);
        m.box(frame, ox + 12, seatY + 1, oz + 12, ox + 13, seatY + backH, oz + 13);
        m.box(seat, ox + 4, seatY + backH - 5, oz + 12, ox + 12, seatY + backH, oz + 13);
    }

    /** Silla rotada: dir 0 mira al norte, 1 al este, 2 al sur, 3 al oeste; (ox,oz) = esquina de la celda 16x16. */
    public static void chairDir(Model m, Mat frame, Mat seat, int ox, int oz, int seatY, int backH, int dir) {
        legs(m, frame, ox + 3, oz + 3, ox + 13, oz + 13, 0, seatY - 1, 1);
        m.box(seat, ox + 3, seatY - 1, oz + 3, ox + 13, seatY + 1, oz + 13);
        int[] b = switch (dir & 3) {
            case 0 -> new int[]{ox + 3, oz + 12, ox + 13, oz + 13};
            case 1 -> new int[]{ox + 3, oz + 3, ox + 4, oz + 13};
            case 2 -> new int[]{ox + 3, oz + 3, ox + 13, oz + 4};
            default -> new int[]{ox + 12, oz + 3, ox + 13, oz + 13};
        };
        m.box(frame, b[0], seatY + 1, b[1], b[2], seatY + backH, b[3]);
    }

    /** Tela con pliegues verticales (cortinas): alterna dos tonos cada 2 vóxeles. */
    public static void drape(Model m, Mat a, Mat b, int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int x = x0; x < x1; x += 2) m.box(((x - x0) / 2) % 2 == 0 ? a : b, x, y0, z0, Math.min(x1, x + 2), y1, z1);
    }

    /** Planta frondosa: varias esferas de follaje alrededor de un centro. */
    public static void foliage(Model m, Rng r, double cx, double cy, double cz, double rad, int n) {
        m.ellipsoid(LEAF, cx, cy, cz, rad, rad * 0.85, rad);
        for (int i = 0; i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2, d = rad * (0.45 + r.nextDouble() * 0.5);
            double rr = rad * (0.35 + r.nextDouble() * 0.3);
            m.ellipsoid(r.chance(0.5) ? LEAF2 : LEAF, cx + Math.cos(a) * d, cy + (r.nextDouble() - 0.3) * rad * 0.8, cz + Math.sin(a) * d, rr, rr, rr);
        }
    }

    /** Texto en relieve (ver {@link Deco#text}). */
    public static void text(Model m, String s, Mat mat, int cx, int yTop, int z0, int depth) {
        Deco.text(m, s, mat, 1, cx, yTop, z0, depth);
    }

    /** Fila de cajones: frentes con tirador, de x0 a x1, entre y0 e y1 (n cajones), en el plano z. */
    public static void drawers(Model m, Mat front, Mat handle, int x0, int x1, int y0, int y1, int n, int z) {
        int h = (y1 - y0) / n;
        for (int i = 0; i < n; i++) {
            int a = y0 + i * h, b = i == n - 1 ? y1 : a + h;
            m.box(front, x0, a, z, x1, b - 1, z + 1);
            int mx = (x0 + x1) / 2, hy = (a + b) / 2 - 1;
            if (z > 0) m.box(handle, mx - 2, hy, z - 1, mx + 2, hy + 1, z);
            else m.box(handle, mx - 2, hy, 0, mx + 2, hy + 1, 1);
        }
    }
}
