package com.megaciudad.core.gen;

import com.megaciudad.core.B;
import com.megaciudad.core.BlockRef;
import com.megaciudad.core.Canvas;
import com.megaciudad.core.layout.AxisLayout;
import com.megaciudad.core.layout.CityLayout;
import com.megaciudad.core.little.Deco;
import com.megaciudad.core.little.Kit;
import com.megaciudad.core.little.Mat;
import com.megaciudad.core.little.Model;

/**
 * Dos líneas de metro elevado (viaducto con vías funcionales para vagonetas, con raíles
 * propulsores alimentados por bloques de redstone ocultos) y estaciones con andén central,
 * techo, escaleras hasta el cantero central de la avenida y mobiliario de mini-bloques.
 */
public final class Metro {
    private final CityLayout L;
    private static final AxisLayout A = CityLayout.A;
    private static final BlockRef DECK = B.of("light_gray_concrete");
    private static final BlockRef DECK_TOP = B.SMOOTH_STONE;
    private static final BlockRef BED = B.P_ANDESITE;
    private static final BlockRef PLATFORM = B.of("polished_diorite");
    private static final BlockRef EDGE = B.MARK_YELLOW;
    private static final BlockRef PARAPET = B.wall("stone_brick", false, true);
    private static final BlockRef PARAPET_NS = B.wall("stone_brick", true, false);
    private static final BlockRef ROOF_GLASS = B.of("light_gray_stained_glass");
    private static final BlockRef SIDE_GLASS = B.of("light_blue_stained_glass");
    private static final Mat SIGN_BOARD = Mat.of("blue_concrete");

    public Metro(CityLayout l) {
        this.L = l;
    }

    public void build(Canvas c) {
        line(c, true);
        line(c, false);
    }

    /** ew=true: línea Este-Oeste sobre la calle Z índice METRO_EW_ROAD. */
    private void line(Canvas c, boolean ew) {
        int k = ew ? CityLayout.METRO_EW_ROAD : CityLayout.METRO_NS_ROAD;
        int across0 = (ew ? L.roadZ0(k) : L.roadX0(k)) + 6;
        int deckY = ew ? CityLayout.EW_DECK_Y : CityLayout.NS_DECK_Y;
        int start = (ew ? L.minX : L.minZ) + A.lotStart[0], end = (ew ? L.minX : L.minZ) + A.lotStart[23] + A.lotSize[23] - 1;
        // ¿el chunk toca el viaducto?
        int ax0 = ew ? start : across0, az0 = ew ? across0 : start, ax1 = ew ? end : across0 + 10, az1 = ew ? across0 + 10 : end;
        if (!c.overlaps(ax0, az0, ax1, az1)) return;
        int[] stations = ew ? CityLayout.EW_STATIONS : CityLayout.NS_STATIONS;
        int a0 = Math.max(start, ew ? c.x0 : c.z0), a1 = Math.min(end, ew ? c.x1 : c.z1);
        for (int a = a0; a <= a1; a++) {
            int off = a - (ew ? L.minX : L.minZ);
            boolean inLot = A.isLot(off);
            int seg = inLot ? A.lotAt(off) : -1;
            int pa = inLot ? A.posAt(off) : -1;
            int len = inLot ? A.lotSize[seg] : 0;
            boolean station = inLot && CityLayout.isStation(stations, seg);
            for (int q = 0; q <= 10; q++) {
                int x = ew ? a : across0 + q, z = ew ? across0 + q : a;
                if (!c.contains(x, z)) continue;
                column(c, ew, x, z, q, a - start, deckY, station, seg, pa, len, a == start || a == end);
            }
        }
        // pilares y estaciones por tramo
        for (int seg = 0; seg < AxisLayout.LOTS; seg++) {
            int s0 = (ew ? L.minX : L.minZ) + A.lotStart[seg];
            int len = A.lotSize[seg];
            if (!(ew ? c.overlaps(s0 - 2, across0, s0 + len + 2, across0 + 10) : c.overlaps(across0, s0 - 2, across0 + 10, s0 + len + 2)))
                continue;
            boolean station = CityLayout.isStation(stations, seg);
            int[] pillars = station ? (ew ? new int[]{20, 36} : new int[]{4, 26}) : new int[]{8, 24, 40, 56};
            for (int pa : pillars) if (pa + 1 < len - 2) pillar(c, ew, across0, s0 + pa, deckY);
            if (station) station(c, ew, k, seg, s0, len, across0, deckY);
        }
    }

    private void set(Canvas c, boolean ew, int a, int q, int across0, int y, BlockRef b) {
        if (ew) c.set(a, y, across0 + q, b);
        else c.set(across0 + q, y, a, b);
    }

    private BlockRef rail(boolean ew, int along, boolean powered) {
        return powered ? B.poweredRail(!ew) : B.rail(!ew);
    }

    private void column(Canvas c, boolean ew, int x, int z, int q, int along, int deckY, boolean station, int seg,
                        int pa, int len, boolean endCol) {
        c.set(x, deckY - 1, z, DECK);
        boolean track = q == 2 || q == 8;
        boolean powered = track && Math.floorMod(along, 12) == 0;
        if (q == 0 || q == 10) {
            c.set(x, deckY, z, DECK);
            c.set(x, deckY + 1, z, ew ? PARAPET : PARAPET_NS);
            if (Math.floorMod(along, 16) == 8) c.set(x, deckY + 2, z, B.LANTERN);
            return;
        }
        if (track) {
            c.set(x, deckY, z, powered ? B.REDSTONE_BLOCK : BED);
            boolean buffer = (seg == 0 && pa <= 1) || (seg == AxisLayout.LOTS - 1 && pa >= len - 2);
            if (buffer) c.set(x, deckY + 1, z, pa == 0 || pa == len - 1 ? B.of("red_concrete") : B.AIR);
            else c.set(x, deckY + 1, z, rail(ew, along, powered));
            return;
        }
        if (station && q >= 3 && q <= 7 && pa >= 0) {
            c.set(x, deckY, z, (q == 3 || q == 7) ? EDGE : PLATFORM);
            return;
        }
        c.set(x, deckY, z, DECK_TOP);
    }

    private void pillar(Canvas c, boolean ew, int across0, int a, int deckY) {
        for (int da = 0; da < 2; da++)
            for (int q = 4; q <= 6; q++) {
                set(c, ew, a + da, q, across0, CityLayout.GROUND, B.P_ANDESITE);
                for (int y = CityLayout.GROUND + 1; y <= deckY - 3; y++) set(c, ew, a + da, q, across0, y, DECK);
            }
        for (int da = -1; da < 3; da++)
            for (int q = 3; q <= 7; q++) set(c, ew, a + da, q, across0, deckY - 2, DECK);
    }

    private void station(Canvas c, boolean ew, int k, int seg, int s0, int len, int across0, int deckY) {
        int pf0, pf1;
        if (ew) {
            pf0 = 13;
            pf1 = 52;
            stair(c, ew, across0, s0, 12, -1, deckY);
            stair(c, ew, across0, s0, 53, +1, deckY);
            pave(c, ew, across0, s0, 0, 2);
            pave(c, ew, across0, s0, 63, len - 1);
        } else {
            pf0 = 8;
            pf1 = 41;
            stair(c, ew, across0, s0, 42, +1, deckY);
            pave(c, ew, across0, s0, 60, len - 1);
        }
        int roofY = deckY + 5;
        for (int pa = pf0; pa <= pf1; pa++) {
            int a = s0 + pa;
            for (int q = 1; q <= 9; q++) {
                BlockRef roof = (q == 1 || q == 9) ? DECK : (q == 5 && pa % 4 == 0) ? B.SEA_LANTERN : ROOF_GLASS;
                set(c, ew, a, q, across0, roofY, roof);
            }
            if ((pa - pf0) % 8 == 4) {
                for (int y = deckY + 1; y < roofY; y++) set(c, ew, a, 5, across0, y, B.QUARTZ_PILLAR);
            }
            if ((pa - pf0) % 6 == 2) set(c, ew, a, 5, across0, deckY + 1, B.LIGHT12);
        }
        // mobiliario del andén
        String name = ew ? CityLayout.nsName(seg) : CityLayout.ewName(seg);
        name = name.replace("Calle ", "").replace("Av. ", "").replace("Bv. ", "");
        Model board = Deco.wallSign(name.toUpperCase(), SIGN_BOARD, Deco.WHITE, 1);
        for (int pa = pf0 + 2; pa + 2 <= pf1; pa += 10) {
            int a = s0 + pa;
            // bancos espalda con espalda mirando a cada vía
            placeOnDeck(c, ew, across0, a, 4, deckY + 1, Deco.BENCH_FLOOR, true);
            placeOnDeck(c, ew, across0, a, 6, deckY + 1, Deco.BENCH_FLOOR, false);
            if (pa + 6 <= pf1) {
                placeOnDeck(c, ew, across0, a + 5, 4, deckY + 1, VALIDATOR, true);
                placeOnDeck(c, ew, across0, a + 5, 6, deckY + 1, Deco.BIN_FLOOR, false);
            }
        }
        // carteles colgantes con el nombre de la estación
        for (int pa : new int[]{pf0 + 8, pf1 - 10}) {
            placeOnDeck(c, ew, across0, s0 + pa, 4, roofY - 1, board, true);
            placeOnDeck(c, ew, across0, s0 + pa, 6, roofY - 1, board, false);
        }
        // cartel "M" a nivel de calle, al pie de las escaleras
        int footA = ew ? s0 + 1 : s0 + len - 2;
        placeOnDeck(c, ew, across0, footA, 5, CityLayout.GROUND + 1, METRO_SIGN, true);
    }

    /**
     * Coloca un modelo sobre el viaducto. q = fila transversal; facingLow = el frente mira hacia q
     * decreciente (la vía del lado bajo).
     */
    private void placeOnDeck(Canvas c, boolean ew, int across0, int a, int q, int y, Model m, boolean facingLow) {
        int rot;
        if (ew) rot = facingLow ? 0 : 2;
        else rot = facingLow ? 3 : 1;
        int along = (rot & 1) == 0 ? m.sx : m.sz;
        int deep = (rot & 1) == 0 ? m.sz : m.sx;
        int qMin = facingLow ? q : q - deep + 1;
        if (!ew) {
            along = (rot & 1) == 0 ? m.sz : m.sx;
            deep = (rot & 1) == 0 ? m.sx : m.sz;
            qMin = facingLow ? q : q - deep + 1;
        }
        if (ew) c.model(m, rot, a, y, across0 + qMin);
        else c.model(m, rot, across0 + qMin, y, a);
    }

    /** Escalera de 3 de ancho desde el andén hasta el cantero; dir = hacia dónde baja. */
    private void stair(Canvas c, boolean ew, int across0, int s0, int topPa, int dir, int deckY) {
        int steps = deckY - CityLayout.GROUND;
        String up = ew ? (dir > 0 ? "west" : "east") : (dir > 0 ? "north" : "south");
        BlockRef st = B.stairs("smooth_quartz", up, false);
        for (int t = 0; t < steps; t++) {
            int a = s0 + topPa + dir * t;
            int sy = deckY - t;
            for (int q = 3; q <= 7; q++) {
                boolean side = q == 3 || q == 7;
                for (int y = CityLayout.GROUND; y <= deckY; y++) {
                    BlockRef b;
                    if (side) {
                        if (y >= deckY - 1) b = DECK;
                        else if (y <= CityLayout.GROUND + 1) b = DECK;
                        else b = SIDE_GLASS;
                    } else {
                        if (y < sy) b = B.of("light_gray_concrete");
                        else if (y == sy) b = st;
                        else b = B.AIR;
                    }
                    set(c, ew, a, q, across0, y, b);
                }
                if (side) set(c, ew, a, q, across0, deckY + 1, B.pane("iron_bars", ew, !ew));
                else if (t > 0) set(c, ew, a, q, across0, deckY + 1, B.AIR);
            }
            if (t % 5 == 3) set(c, ew, a, 5, across0, sy + 2, B.LIGHT12);
        }
    }

    private void pave(Canvas c, boolean ew, int across0, int s0, int pa0, int pa1) {
        for (int pa = pa0; pa <= pa1; pa++)
            for (int q = 4; q <= 6; q++) set(c, ew, s0 + pa, q, across0, CityLayout.GROUND, B.SMOOTH_STONE);
    }

    private static final Model VALIDATOR = validator();

    private static Model validator() {
        return new Model("validador", 1, 2, 1).b(0, 0, 0, Kit.ANDESITE_CASING).b(0, 1, 0, Kit.STOCK_TICKER);
    }

    private static final Model METRO_SIGN = metroSign();

    private static Model metroSign() {
        return new Model("cartel_metro", 1, 4, 1)
                .fill(0, 0, 0, 0, 2, 0, B.of("polished_andesite_wall"))
                .sign(0, 3, 0, B.of("warped_sign[rotation=8]"), "white", true, "", "M", "METRO", "");
    }
}
