package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Comercios, gastronomía y entretenimiento. */
public final class FShop {
    private FShop() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    // ================================================================== comercio

    public static final Model FREEZER = reg(freezer());

    private static Model freezer() {
        Model m = new Model("freezer", 2, 1, 1);
        m.box(WHITE, 1, 0, 2, 31, 11, 14);
        m.box(c(0x2E86C1), 1, 3, 1, 31, 6, 2);
        m.box(WHITE, 14, 3, 0, 18, 6, 1);
        Rng r = new Rng(4);
        for (int x = 2; x < 30; x += 3)
            for (int z = 3; z < 13; z += 4) m.box(c(VIVID[r.nextInt(VIVID.length)]), x, 8, z, x + 3, 10, z + 3);
        m.box(GLASS_B, 1, 11, 2, 31, 12, 14);
        m.box(STEEL, 1, 11, 7, 31, 12, 8);
        m.box(LGRAY, 1, 0, 2, 31, 1, 14);
        return m;
    }

    public static final Model DRINK_COOLER = reg(drinkCooler());

    private static Model drinkCooler() {
        Model m = new Model("exhibidora_bebidas", 1, 2, 1);
        m.box(WHITE, 0, 0, 2, 16, 32, 16);
        m.box(c(0xC0392B), 0, 27, 1, 16, 32, 2);
        m.box(LIGHT, 2, 28, 0, 14, 31, 1);
        m.cut(1, 3, 2, 15, 26, 15);
        Rng r = new Rng(13);
        for (int y : new int[]{3, 9, 15, 21}) {
            m.box(STEEL, 1, y, 3, 15, y + 1, 15);
            for (int x = 2; x < 15; x += 3) bottle(m, c(new int[]{0xC0392B, 0x27AE60, 0x2E86C1, 0xF39C12, 0x6E2C00}[r.nextInt(5)]), x + 0.5, 6, y + 1, 3, 1.1);
        }
        m.box(GLASS, 1, 3, 1, 15, 26, 2);
        m.box(STEEL, 13, 8, 0, 14, 20, 1);
        m.box(BLACK, 0, 0, 1, 16, 3, 2);
        return m;
    }

    public static final Model BREAD_RACK = reg(breadRack());

    private static Model breadRack() {
        Model m = new Model("estante_pan", 2, 2, 1);
        m.box(OAK, 0, 0, 4, 1, 30, 16);
        m.box(OAK, 31, 0, 4, 32, 30, 16);
        m.box(OAK, 1, 0, 15, 31, 30, 16);
        Mat crust = c(0xC8873A), dark = c(0xA0602A), light = c(0xE8C080);
        for (int y : new int[]{2, 11, 20}) {
            m.box(OAK, 1, y - 1, 3, 31, y, 16);
            for (int x : new int[]{2, 17}) {
                m.box(c(0xC9A66B), x, y, 5, x + 13, y + 3, 14);
                m.cut(x + 1, y + 1, 6, x + 12, y + 3, 13);
            }
        }
        for (int x = 4; x < 14; x += 3) m.ellipsoid(crust, x + 1, 4.5, 9.5, 1.4, 1.3, 4);
        for (int x = 19; x < 30; x += 4) m.sphere(dark, x + 1, 5, 9.5, 2.1);
        for (int x = 4; x < 14; x += 4) m.ellipsoid(light, x + 1, 13.5, 9.5, 2, 1.4, 2.5);
        for (int x = 19; x < 30; x += 3) m.ellipsoid(crust, x + 1, 13.5, 8, 1.3, 1.2, 3.5);
        for (int x = 4; x < 14; x += 4) m.sphere(crust, x + 1, 23, 9.5, 2);
        for (int x = 19; x < 30; x += 4) m.ellipsoid(c(0xD4A15A), x + 1, 22.5, 9.5, 1.8, 1.2, 2.5);
        m.box(c(0x6E2C00), 6, 23, 2, 26, 32, 4);
        Kit.text(m, "PAN", c(0xF5E6C8), 16, 31, 1, 1);
        return m;
    }

    public static final Model CAKE_STAND = reg(cakeStand());

    private static Model cakeStand() {
        Model m = new Model("torta", 1, 1, 1);
        m.cylY(WHITE, 8, 8, 1.5, 0, 6);
        m.cylY(WHITE, 8, 8, 4, 0, 1);
        m.cylY(QUARTZ, 8, 8, 5.5, 6, 7);
        m.cylY(c(0xF8C8D8), 8, 8, 4.5, 7, 10);
        m.cylY(c(0xFFF5F8), 8, 8, 3.2, 10, 12);
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3;
            m.box(RED, (int) Math.round(8 + Math.cos(a) * 3.5), 10, (int) Math.round(8 + Math.sin(a) * 3.5), (int) Math.round(8 + Math.cos(a) * 3.5) + 1, 11, (int) Math.round(8 + Math.sin(a) * 3.5) + 1);
        }
        m.box(RED, 7, 12, 7, 9, 13, 9);
        m.cylY(GLASS, 8, 8, 5.4, 7, 15);
        m.cylY(null, 8, 8, 4.8, 7, 14);
        m.cylY(GLASS, 8, 8, 1, 15, 16);
        m.cylY(c(0xF8C8D8), 8, 8, 4.5, 7, 10);
        m.cylY(c(0xFFF5F8), 8, 8, 3.2, 10, 12);
        m.box(RED, 7, 12, 7, 9, 13, 9);
        return m;
    }

    public static final Model ICE_CREAM_CASE = reg(iceCreamCase());

    private static Model iceCreamCase() {
        Model m = new Model("vitrina_helados", 2, 1, 1);
        m.box(WHITE, 0, 0, 2, 32, 9, 16);
        for (int x = 0; x < 32; x += 4) m.box(x % 8 == 0 ? c(0xF8BBD0) : WHITE, x, 1, 1, x + 4, 8, 2);
        m.box(STEEL, 0, 9, 3, 32, 10, 16);
        int[] flavors = {0xF8E8C8, 0x6E3B1F, 0xF8BBD0, 0xC5E1A5, 0xFFF59D, 0xE57373, 0xB39DDB, 0xFFCC80};
        for (int i = 0; i < 8; i++) {
            int x = 1 + (i % 4) * 8, z = i < 4 ? 4 : 10;
            m.box(STEEL, x, 9, z, x + 6, 10, z + 5);
            m.box(c(flavors[i]), x + 1, 10, z + 1, x + 5, 11, z + 4);
            m.sphere(c(flavors[i]), x + 3, 11, z + 2.5, 1.5);
        }
        for (int i = 0; i < 5; i++) m.box(GLASS, 0, 9 + i, 2 + i, 32, 10 + i, 3 + i);
        m.box(GLASS, 0, 14, 7, 32, 15, 16);
        return m;
    }

    public static final Model PIZZA_OVEN = reg(pizzaOven());

    private static Model pizzaOven() {
        Model m = new Model("horno_pizza", 2, 2, 1);
        m.box(STONE, 0, 0, 1, 32, 10, 16);
        m.box(BRICK, 1, 1, 0, 31, 9, 1);
        m.ellipsoid(BRICK, 16, 10, 9, 14, 12, 7.5);
        m.cut(0, 0, 0, 32, 10, 16);
        m.box(STONE, 0, 0, 1, 32, 10, 16);
        m.box(BRICK, 1, 1, 0, 31, 9, 1);
        m.cut(10, 10, 1, 22, 17, 9);
        m.box(BLACK, 10, 10, 8, 22, 17, 9);
        m.ellipsoid(FIRE, 16, 11.5, 6, 4, 2, 2);
        m.ellipsoid(WARM, 15, 12, 5, 2, 1.4, 1.2);
        m.box(c(0x2C2C2C), 9, 17, 1, 23, 18, 3);
        m.box(c(0x5D6D7E), 14, 21, 9, 18, 32, 13);
        m.box(OAK, 26, 10, 1, 27, 26, 2);
        m.box(OAK, 23, 10, 0, 30, 12, 1);
        m.cylY(c(0xE8B04A), 6, 6, 3, 10, 11);
        m.cylY(c(0xC0392B), 6, 6, 2.3, 10, 12 - 1 + 1);
        return m;
    }

    public static final Model ESPRESSO = reg(espresso());

    private static Model espresso() {
        Model m = new Model("maquina_espresso", 1, 2, 1);
        m.box(WALNUT, 0, 0, 2, 16, 14, 16);
        m.box(BIRCH, 0, 14, 1, 16, 15, 16);
        m.box(STEEL, 1, 15, 6, 15, 24, 15);
        m.box(BLACK, 1, 15, 5, 15, 16, 15);
        for (int x : new int[]{4, 11}) {
            m.box(STEEL, x - 1, 19, 4, x + 1, 21, 6);
            m.box(BLACK, x - 1, 18, 2, x + 1, 19, 6);
            m.box(WHITE, x - 1, 16, 4, x + 1, 18, 6);
        }
        m.box(STEEL, 14, 17, 5, 15, 22, 6);
        m.box(c(0xB03A2E), 6, 22, 5, 9, 23, 6);
        m.box(c(0xE5E7E9), 1, 24, 7, 15, 25, 14);
        for (int x = 2; x < 14; x += 3) m.box(WHITE, x, 25, 9, x + 2, 27, 11);
        return m;
    }

    public static final Model MENU_BOARD = reg(menuBoard());

    private static Model menuBoard() {
        Model m = new Model("pizarra_menu", 2, 1, 1);
        m.box(WALNUT, 1, 1, 14, 31, 16, 16);
        m.box(c(0x1C2420), 2, 2, 13, 30, 15, 14);
        Kit.text(m, "MENU", c(0xF4D03F), 16, 15, 12, 1);
        for (int y = 3; y < 8; y += 2) {
            m.box(WHITE, 4, y, 12, 18, y + 1, 13);
            m.box(c(0xF8BBD0), 23, y, 12, 28, y + 1, 13);
        }
        return m;
    }

    public static final Model REGISTER = reg(register());

    private static Model register() {
        Model m = new Model("caja_moderna", 2, 1, 1);
        m.box(WHITE, 0, 0, 3, 32, 14, 15);
        m.box(OAK, 0, 14, 2, 32, 15, 16);
        m.box(c(0x1F618D), 0, 4, 2, 32, 6, 3);
        m.box(STEEL, 20, 15, 9, 22, 18, 11);
        m.box(BLACK, 18, 17, 8, 26, 23, 9);
        m.box(c(0x5DADE2), 19, 18, 7, 25, 22, 8);
        m.box(BLACK, 12, 15, 9, 15, 16, 12);
        m.box(c(0x2C3E50), 12, 16, 10, 15, 17, 12);
        m.box(WHITE, 4, 15, 9, 9, 18, 13);
        m.box(STEEL, 5, 18, 10, 8, 19, 12);
        m.box(c(0xF5F5F5), 27, 15, 5, 31, 19, 9);
        return m;
    }

    public static final Model BOOK_TABLE = reg(bookTable());

    private static Model bookTable() {
        Model m = new Model("mesa_libros", 2, 1, 1);
        m.box(WALNUT, 0, 8, 1, 32, 10, 15);
        legs(m, WALNUT, 1, 2, 31, 14, 0, 8, 2);
        Rng r = new Rng(55);
        for (int x = 2; x < 30; x += 7)
            for (int z = 3; z < 13; z += 6) {
                int h = r.range(2, 5);
                for (int y = 0; y < h; y++) m.box(c(BOOK[r.nextInt(BOOK.length)]), x, 10 + y, z, x + 5, 11 + y, z + 4);
            }
        m.box(c(0xF4D03F), 14, 10, 1, 18, 14, 2);
        return m;
    }

    public static final Model MAGAZINE_STAND = reg(magazineStand());

    private static Model magazineStand() {
        Model m = new Model("revistero", 1, 2, 1);
        m.box(STEEL, 0, 0, 14, 16, 30, 16);
        m.box(STEEL, 0, 0, 4, 1, 30, 16);
        m.box(STEEL, 15, 0, 4, 16, 30, 16);
        Rng r = new Rng(8);
        for (int t = 0; t < 4; t++) {
            int y = 2 + t * 7, z = 4 + t * 2;
            m.box(STEEL, 1, y, z, 15, y + 1, 14);
            for (int x = 1; x < 15; x += 5) {
                m.box(c(VIVID[r.nextInt(VIVID.length)]), x, y + 1, z, x + 4, y + 7, z + 1);
                m.box(WHITE, x + 1, y + 4, z - 1 < 0 ? 0 : z - 1, x + 3, y + 5, z);
            }
        }
        return m;
    }

    public static final Model SHOE_WALL = reg(shoeWall());

    private static Model shoeWall() {
        Model m = new Model("estante_zapatos", 2, 2, 1);
        m.box(WHITE, 0, 0, 14, 32, 32, 16);
        Rng r = new Rng(19);
        for (int y = 2; y < 30; y += 7) {
            m.box(WHITE, 0, y, 7, 32, y + 1, 14);
            for (int x = 1; x < 30; x += 8) {
                Mat col = c(VIVID[r.nextInt(VIVID.length)]);
                boolean heel = r.chance(0.3);
                for (int k = 0; k < 2; k++) {
                    int sx = x + k * 3;
                    if (heel) {
                        m.box(col, sx, y + 1, 8, sx + 2, y + 2, 13);
                        m.box(col, sx, y + 2, 11, sx + 2, y + 4, 13);
                        m.box(BLACK, sx, y + 1, 12, sx + 2, y + 3, 13);
                    } else {
                        m.box(WHITE, sx, y + 1, 8, sx + 2, y + 2, 13);
                        m.box(col, sx, y + 2, 9, sx + 2, y + 4, 13);
                    }
                }
            }
        }
        return m;
    }

    public static final Model CLOTHES_TABLE = reg(clothesTable());

    private static Model clothesTable() {
        Model m = new Model("mesa_ropa", 2, 1, 1);
        m.box(BIRCH, 0, 7, 1, 32, 9, 15);
        m.box(BIRCH, 1, 0, 2, 31, 7, 14);
        m.box(c(0xD7CCC8), 2, 1, 1, 30, 6, 2);
        Rng r = new Rng(31);
        for (int x = 2; x < 30; x += 7)
            for (int z = 2; z < 14; z += 6) {
                Mat col = w(VIVID[r.nextInt(VIVID.length)]), col2 = w(VIVID[r.nextInt(VIVID.length)]);
                int h = r.range(3, 6);
                for (int y = 0; y < h; y++) m.box(y % 3 == 2 ? col2 : col, x, 9 + y, z, x + 6, 10 + y, z + 5);
            }
        return m;
    }

    public static final Model FITTING_ROOM = reg(fittingRoom());

    private static Model fittingRoom() {
        Model m = new Model("probador", 1, 2, 1);
        m.box(WALNUT, 0, 0, 0, 16, 32, 1);
        m.cut(1, 0, 0, 15, 30, 1);
        m.box(WALNUT, 0, 0, 0, 1, 32, 16);
        m.box(WALNUT, 15, 0, 0, 16, 32, 16);
        m.box(WALNUT, 0, 31, 0, 16, 32, 16);
        m.box(c(0xCFE3EA), 3, 6, 15, 13, 28, 16);
        drape(m, w(0x922B21), w(0x7B241C), 1, 1, 1, 15, 29, 2);
        m.box(GOLD, 1, 29, 1, 15, 30, 2);
        return m;
    }

    public static final Model JEWEL_CASE = reg(jewelCase());

    private static Model jewelCase() {
        Model m = new Model("vitrina_joyas", 2, 1, 1);
        m.box(WALNUT, 0, 0, 2, 32, 8, 16);
        m.box(GOLD, 0, 7, 1, 32, 8, 16);
        m.box(w(0x1A237E), 1, 8, 3, 31, 9, 15);
        int[][] items = {{4, 6, 1}, {9, 10, 0}, {14, 5, 2}, {20, 9, 1}, {25, 6, 0}, {27, 11, 2}};
        for (int[] it : items) {
            Mat met = it[2] == 1 ? STEEL : GOLD;
            if (it[2] == 0) {
                m.box(met, it[0], 9, it[1], it[0] + 2, 10, it[1] + 2);
                m.box(c(0xE74C3C), it[0], 10, it[1], it[0] + 1, 11, it[1] + 1);
            } else if (it[2] == 1) {
                m.box(met, it[0], 9, it[1], it[0] + 4, 10, it[1] + 1);
                m.box(met, it[0], 9, it[1] + 2, it[0] + 4, 10, it[1] + 3);
                m.box(c(0x5DADE2), it[0] + 1, 9, it[1] + 3, it[0] + 3, 10, it[1] + 4);
            } else {
                m.box(c(0xFDFEFE), it[0], 9, it[1], it[0] + 3, 12, it[1] + 1);
                m.box(met, it[0] + 1, 10, it[1] - 1 < 0 ? 0 : it[1] - 1, it[0] + 2, 11, it[1]);
            }
        }
        m.box(GLASS, 0, 8, 2, 32, 14, 3);
        m.box(GLASS, 0, 14, 2, 32, 15, 16);
        m.box(GLASS, 0, 8, 15, 32, 14, 16);
        m.box(PEARL, 1, 13, 8, 31, 14, 9);
        return m;
    }

    public static final Model OPTICAL_STAND = reg(opticalStand());

    private static Model opticalStand() {
        Model m = new Model("exhibidor_lentes", 1, 2, 1);
        m.box(WHITE, 2, 0, 4, 14, 2, 12);
        m.box(WHITE, 5, 2, 7, 11, 30, 9);
        Rng r = new Rng(23);
        for (int y = 5; y < 24; y += 4) {
            m.box(STEEL, 3, y, 6, 13, y + 1, 7);
            Mat fr = c(new int[]{0x212121, 0x6E2C00, 0xC0392B, 0x1F618D}[r.nextInt(4)]);
            m.box(fr, 3, y + 1, 5, 7, y + 3, 6);
            m.box(fr, 9, y + 1, 5, 13, y + 3, 6);
            m.box(GLASS_G, 4, y + 1, 4, 6, y + 2, 5);
            m.box(GLASS_G, 10, y + 1, 4, 12, y + 2, 5);
            m.box(fr, 7, y + 2, 5, 9, y + 3, 6);
        }
        m.box(c(0xCFE3EA), 4, 25, 6, 12, 30, 7);
        m.box(WHITE, 4, 30, 6, 12, 31, 9);
        return m;
    }

    public static final Model PHONE_TABLE = reg(phoneTable());

    private static Model phoneTable() {
        Model m = new Model("mesa_celulares", 2, 1, 1);
        m.box(WHITE, 0, 8, 1, 32, 10, 15);
        m.box(WHITE, 2, 0, 3, 30, 8, 13);
        m.box(c(0x2C3E50), 2, 0, 2, 30, 1, 14);
        int[] cols = {0x1F618D, 0x8E44AD, 0x16A085, 0xD35400, 0x2E86C1, 0xC0392B};
        for (int i = 0; i < 6; i++) {
            int x = 3 + (i % 3) * 10, z = i < 3 ? 3 : 9;
            m.box(STEEL, x + 1, 10, z + 1, x + 4, 11, z + 3);
            m.box(BLACK, x, 11, z + 2, x + 5, 15, z + 3);
            m.box(c(cols[i]), x + 1, 12, z + 1, x + 4, 14, z + 2);
        }
        return m;
    }

    public static final Model TV_WALL = reg(tvWall());

    private static Model tvWall() {
        Model m = new Model("pared_televisores", 3, 2, 1);
        m.box(c(0x2C3E50), 0, 0, 14, 48, 32, 16);
        m.box(c(0x2C3E50), 0, 0, 6, 48, 4, 14);
        int[][] img = {{0x2E86C1, 0x58D68D}, {0xE74C3C, 0xF4D03F}, {0x8E44AD, 0x5DADE2}, {0x16A085, 0xF39C12}, {0xD35400, 0x2E4053}, {0x1ABC9C, 0xEC7063}};
        for (int i = 0; i < 6; i++) {
            int x = 1 + (i % 3) * 16, y = i < 3 ? 6 : 19;
            screen(m, x, y, x + 14, y + 11, 12, 2, c(img[i][0]));
            m.box(c(img[i][1]), x + 2, y + 2, 12, x + 8, y + 6, 13);
            m.box(WHITE, x + 9, y + 7, 12, x + 12, y + 9, 13);
        }
        return m;
    }

    public static final Model TOY_SHELF = reg(toyShelf());

    private static Model toyShelf() {
        Model m = new Model("estante_juguetes", 2, 2, 1);
        m.box(c(0xF4D03F), 0, 0, 5, 1, 31, 16);
        m.box(c(0xF4D03F), 31, 0, 5, 32, 31, 16);
        m.box(c(0xAED6F1), 1, 0, 15, 31, 31, 16);
        for (int y : new int[]{0, 10, 20, 30}) m.box(c(0xF4D03F), 1, y, 5, 31, y + 1, 16);
        m.sphere(RED, 5, 4, 10, 3);
        m.sphere(c(0x2E86C1), 12, 3.5, 10, 2.5);
        m.box(c(0x27AE60), 17, 1, 7, 21, 5, 11);
        m.box(YELLOW, 22, 1, 7, 26, 5, 11);
        m.box(RED, 19, 5, 7, 23, 9, 11);
        m.box(c(0xE74C3C), 3, 11, 7, 11, 14, 12);
        m.box(GLASS_B, 5, 14, 8, 9, 16, 11);
        for (int x : new int[]{4, 9}) m.cylZ(BLACK, x, 11.5, 1.4, 6, 13);
        m.ellipsoid(c(0xA0522D), 21, 14, 10, 3, 3, 2.5);
        m.sphere(c(0xA0522D), 21, 18, 10, 2.2);
        m.box(STEEL, 4, 21, 8, 9, 27, 12);
        m.box(STEEL, 5, 27, 8, 8, 29, 12);
        m.box(RED, 5, 27, 7, 6, 28, 8);
        m.box(RED, 7, 27, 7, 8, 28, 8);
        m.box(c(0xF39C12), 14, 21, 7, 27, 24, 13);
        m.box(c(0x8E44AD), 15, 24, 8, 26, 27, 12);
        return m;
    }

    public static final Model SPORTS_RACK = reg(sportsRack());

    private static Model sportsRack() {
        Model m = new Model("estante_deportes", 2, 2, 1);
        m.box(c(0x2C3E50), 0, 0, 14, 32, 32, 16);
        m.box(c(0x2C3E50), 0, 0, 4, 32, 1, 14);
        m.box(c(0x2C3E50), 0, 12, 6, 32, 13, 14);
        for (int x = 4; x < 29; x += 7) {
            m.sphere(WHITE, x, 4.5, 9, 3.4);
            m.box(BLACK, x - 1, 6, 6, x + 1, 8, 7);
            m.box(BLACK, x - 3, 3, 7, x - 2, 5, 9);
        }
        for (int x = 5; x < 29; x += 8) {
            m.sphere(c(0xE67E22), x, 16.5, 10, 3.4);
            m.box(BLACK, x - 3, 16, 7, x + 3, 17, 8);
        }
        for (int x = 3; x < 30; x += 6) {
            m.box(BLACK, x, 21, 13, x + 1, 26, 14);
            m.box(c(0x2E86C1), x - 2, 26, 13, x + 3, 31, 14);
            m.box(GLASS_W, x - 1, 27, 12, x + 2, 30, 13);
        }
        return m;
    }

    public static final Model FLOWER_STAND = reg(flowerStand());

    private static Model flowerStand() {
        Model m = new Model("puesto_flores", 2, 1, 1);
        m.box(OAK, 0, 0, 1, 32, 3, 15);
        m.box(OAK, 0, 3, 7, 32, 6, 15);
        m.box(OAK, 0, 6, 11, 32, 9, 15);
        int[] cols = {0xE74C3C, 0xF4D03F, 0xFFFFFF, 0xEC7063, 0xAF7AC5, 0xF39C12, 0xE74C3C, 0x5DADE2};
        int i = 0;
        for (int[] row : new int[][]{{3, 4}, {6, 9}, {9, 13}}) {
            for (int x = 2; x < 31; x += 5) {
                m.cylY(STEEL, x + 1.5, row[1], 2, row[0], row[0] + 3);
                m.box(LEAF2, x + 1, row[0] + 3, row[1] - 1, x + 2, row[0] + 5, row[1] + 1);
                Mat fl = c(cols[i++ % cols.length]);
                for (int[] o : new int[][]{{0, 0}, {-1, 1}, {1, -1}}) m.sphere(fl, x + 1.5 + o[0], row[0] + 6, row[1] + o[1], 1.3);
            }
        }
        return m;
    }

    public static final Model PLANT_SHELF = reg(plantShelf());

    private static Model plantShelf() {
        Model m = new Model("estante_plantas", 2, 2, 1);
        for (int x : new int[]{1, 30}) m.box(BLACK, x, 0, 4, x + 1, 30, 15);
        Rng r = new Rng(77);
        int[] ys = {1, 11, 21};
        for (int y : ys) {
            m.box(c(0x5D4037), 1, y, 4, 31, y + 1, 15);
            for (int x = 3; x < 29; x += 6) {
                Mat pot = c(new int[]{0xD35400, 0xF5F5F5, 0x5D6D7E, 0xC0392B}[r.nextInt(4)]);
                pot(m, pot, x + 1.5, 9.5, 2.2, y + 1, 3);
                int k = r.nextInt(3);
                if (k == 0) m.sphere(LEAF, x + 1.5, y + 6, 9.5, 2.6);
                else if (k == 1) {
                    m.cylY(c(0x4A7A2E), x + 1.5, 9.5, 1.2, y + 4, y + 8);
                } else {
                    for (int[] o : new int[][]{{-1, 0}, {1, 0}, {0, 1}, {0, -1}}) m.box(c(0x7DCEA0), x + 1 + o[0], y + 4, 9 + o[1], x + 2 + o[0], y + 6, 10 + o[1]);
                }
            }
        }
        return m;
    }

    public static final Model SALON_STATION = reg(salonStation());

    private static Model salonStation() {
        Model m = new Model("tocador_peluqueria", 1, 2, 1);
        m.box(BLACK, 0, 0, 9, 16, 12, 16);
        m.box(WHITE, 0, 12, 8, 16, 13, 16);
        m.box(BLACK, 1, 13, 15, 15, 31, 16);
        m.box(c(0xCFE3EA), 2, 15, 14, 14, 30, 15);
        for (int y = 15; y < 30; y += 4) {
            m.box(PEARL, 1, y, 14, 2, y + 1, 15);
            m.box(PEARL, 14, y, 14, 15, y + 1, 15);
        }
        m.cylY(c(0x8E44AD), 3, 11, 1, 13, 17);
        m.cylY(c(0x16A085), 5, 11, 1, 13, 16);
        m.box(BLACK, 10, 13, 9, 14, 15, 12);
        m.box(BLACK, 11, 15, 9, 13, 16, 12);
        m.box(STEEL, 7, 13, 10, 9, 14, 13);
        return m;
    }

    public static final Model BARBER_CHAIR = reg(barberChair());

    private static Model barberChair() {
        Model m = new Model("sillon_barbero", 1, 1, 1);
        m.cylY(STEEL, 8, 9, 4, 0, 1);
        m.cylY(STEEL, 8, 9, 1.4, 1, 5);
        m.box(c(0x8B1A1A), 3, 5, 4, 13, 8, 13);
        m.box(c(0x8B1A1A), 3, 8, 12, 13, 15, 14);
        m.box(BLACK, 5, 15, 12, 11, 16, 14);
        m.box(STEEL, 2, 8, 5, 3, 10, 12);
        m.box(STEEL, 13, 8, 5, 14, 10, 12);
        m.box(c(0x8B1A1A), 2, 10, 5, 3, 11, 12);
        m.box(c(0x8B1A1A), 13, 10, 5, 14, 11, 12);
        m.box(STEEL, 5, 2, 0, 11, 3, 4);
        m.box(STEEL, 7, 3, 3, 9, 5, 4);
        return m;
    }

    public static final Model HAIR_WASH = reg(hairWash());

    private static Model hairWash() {
        Model m = new Model("lavacabezas", 1, 1, 1);
        m.box(BLACK, 3, 0, 1, 13, 5, 10);
        m.box(BLACK, 3, 5, 2, 13, 7, 10);
        m.box(BLACK, 3, 7, 8, 13, 11, 11);
        m.box(BLACK, 4, 0, 11, 12, 9, 16);
        m.box(c(0xF5F5F5), 3, 9, 11, 13, 13, 16);
        m.cut(4, 11, 12, 12, 13, 15);
        m.box(STEEL, 7, 13, 15, 9, 15, 16);
        m.box(BLACK, 2, 5, 3, 3, 8, 9);
        m.box(BLACK, 13, 5, 3, 14, 8, 9);
        return m;
    }

    public static final Model PHARMA_SHELF = reg(pharmaShelf());

    private static Model pharmaShelf() {
        Model m = new Model("estante_farmacia", 2, 2, 1);
        m.box(WHITE, 0, 0, 5, 32, 28, 16);
        Rng r = new Rng(91);
        int[] cols = {0xFFFFFF, 0xAED6F1, 0xA9DFBF, 0xF5B7B1, 0xF9E79F, 0x2E86C1, 0x27AE60};
        for (int y : new int[]{2, 9, 16, 22}) {
            m.cut(1, y, 5, 31, y + 6, 15);
            for (int x = 1; x < 30; x += 3) {
                int h = r.range(3, 5);
                m.box(c(cols[r.nextInt(cols.length)]), x, y, 7, x + 2, y + h, 13);
                if (r.chance(0.4)) m.box(c(0x2E86C1), x, y + 1, 6, x + 2, y + 2, 7);
            }
        }
        m.box(WHITE, 0, 28, 13, 32, 32, 16);
        m.box(c(0x27AE60), 14, 28, 12, 18, 32, 13);
        m.box(c(0x27AE60), 12, 29, 12, 20, 31, 13);
        return m;
    }

    public static final Model HARDWARE_WALL = reg(hardwareWall());

    private static Model hardwareWall() {
        Model m = new Model("panel_herramientas", 2, 2, 1);
        Mat peg = c(0xB08D57);
        m.box(peg, 0, 8, 14, 32, 32, 16);
        for (int x = 2; x < 32; x += 3)
            for (int y = 10; y < 32; y += 3) m.box(c(0x8A6E40), x, y, 13, x + 1, y + 1, 14);
        m.box(c(0x5D4037), 0, 0, 6, 32, 8, 16);
        m.box(STEEL, 0, 8, 6, 32, 9, 16);
        for (int x = 2; x < 30; x += 6) m.box(c(VIVID[x % VIVID.length]), x, 9, 8, x + 4, 12, 13);
        m.box(WALNUT, 3, 16, 12, 4, 26, 13);
        m.box(STEEL, 1, 24, 12, 6, 27, 13);
        m.box(c(0xC0392B), 8, 15, 12, 9, 22, 13);
        m.box(STEEL, 8, 22, 12, 9, 28, 13);
        m.box(STEEL, 12, 18, 12, 13, 28, 13);
        m.box(STEEL, 11, 26, 12, 14, 28, 13);
        m.box(c(0xF39C12), 17, 18, 12, 24, 25, 13);
        m.box(BLACK, 22, 14, 12, 24, 19, 13);
        m.box(STEEL, 16, 24, 12, 18, 26, 13);
        m.box(STEEL, 26, 14, 12, 30, 28, 13);
        m.box(WALNUT, 26, 25, 12, 30, 29, 13);
        return m;
    }

    public static final Model PAINT_CANS = reg(paintCans());

    private static Model paintCans() {
        Model m = new Model("latas_pintura", 1, 1, 1);
        int[][] cans = {{4, 4, 0, 0xC0392B}, {11, 4, 0, 0x2E86C1}, {4, 11, 0, 0xF4D03F}, {11, 11, 0, 0x27AE60}, {7, 7, 5, 0xFFFFFF}};
        for (int[] cn : cans) {
            m.cylY(STEEL, cn[0] + 0.5, cn[1] + 0.5, 3, cn[2], cn[2] + 5);
            m.cylY(c(cn[3]), cn[0] + 0.5, cn[1] + 0.5, 3.1, cn[2] + 1, cn[2] + 3);
            m.cylY(c(cn[3]), cn[0] + 0.5, cn[1] + 0.5, 2.2, cn[2] + 5, cn[2] + 6);
        }
        return m;
    }

    public static final Model DELI_CASE = reg(deliCase());

    private static Model deliCase() {
        Model m = new Model("vitrina_fiambres", 2, 1, 1);
        m.box(WHITE, 0, 0, 3, 32, 8, 16);
        m.box(c(0x7B241C), 0, 1, 2, 32, 4, 3);
        m.box(STEEL, 0, 8, 3, 32, 9, 16);
        for (int x = 3; x < 12; x += 4) m.ellipsoid(c(0xE8A0A0), x, 10, 8, 1.8, 1.4, 3);
        m.cylY(c(0xF7DC6F), 17, 8, 3, 9, 12);
        m.cylY(c(0xF4D03F), 17, 8, 3, 9, 10);
        m.cut(17, 9, 5, 20, 12, 8);
        for (int z = 5; z < 13; z += 3) m.cylX(c(0x922B21), 10, z, 1.2, 22, 30);
        for (int i = 0; i < 5; i++) m.box(GLASS, 0, 9 + i, 3 + i, 32, 10 + i, 4 + i);
        m.box(GLASS, 0, 14, 8, 32, 15, 16);
        m.box(WHITE, 24, 15, 10, 30, 16, 15);
        return m;
    }

    public static final Model SCALE = reg(scale());

    private static Model scale() {
        Model m = new Model("balanza", 1, 1, 1);
        m.box(WHITE, 2, 0, 4, 14, 12, 14);
        m.box(STEEL, 3, 12, 5, 13, 13, 13);
        m.box(STEEL, 4, 13, 6, 12, 14, 12);
        m.box(WHITE, 4, 13, 12, 12, 16, 14);
        m.box(BLACK, 5, 14, 11, 11, 16, 12);
        m.box(GREEN_LIT, 6, 14, 10, 10, 15, 11);
        m.box(c(0xE8A0A0), 6, 14, 7, 10, 15, 10);
        return m;
    }

    public static final Model CANDY_BINS = reg(candyBins());

    private static Model candyBins() {
        Model m = new Model("golosinas_granel", 2, 1, 1);
        m.box(c(0xF8BBD0), 0, 0, 3, 32, 8, 16);
        for (int x = 0; x < 32; x += 4) m.box(x % 8 == 0 ? WHITE : c(0xF8BBD0), x, 1, 2, x + 4, 7, 3);
        Rng r = new Rng(3);
        for (int i = 0; i < 4; i++) {
            int x = 1 + i * 8;
            m.box(GLASS, x, 8, 3, x + 7, 14, 15);
            m.cut(x + 1, 9, 4, x + 6, 14, 14);
            for (int z = 4; z < 14; z += 2) m.box(c(VIVID[r.nextInt(8)]), x + 1, 9, z, x + 6, 11 + (z % 4 == 0 ? 1 : 0), z + 2);
            m.box(STEEL, x + 2, 14, 6, x + 5, 15, 8);
        }
        return m;
    }

    public static final Model WINE_RACK = reg(wineRack());

    private static Model wineRack() {
        Model m = new Model("cava_vinos", 1, 2, 1);
        m.box(WALNUT, 0, 0, 3, 16, 31, 16);
        Rng r = new Rng(66);
        for (int y = 2; y < 29; y += 4)
            for (int x = 1; x < 15; x += 4) {
                m.cut(x, y, 3, x + 3, y + 3, 15);
                Mat b = r.chance(0.6) ? c(0x1E3A1E) : c(0x5B1A1A);
                m.cylZ(b, x + 1.5, y + 1.5, 1.4, 4, 15);
                m.cylZ(r.chance(0.5) ? GOLD : RED, x + 1.5, y + 1.5, 0.7, 3, 4);
            }
        m.box(WALNUT, 0, 31, 2, 16, 32, 16);
        return m;
    }

    public static final Model BASKETS = reg(baskets());

    private static Model baskets() {
        Model m = new Model("canastos", 1, 1, 1);
        Mat red = c(0xC0392B);
        for (int i = 0; i < 4; i++) {
            int y = i * 2;
            m.box(red, 3, y, 4, 13, y + 2, 12);
        }
        m.box(red, 2, 8, 3, 14, 10, 13);
        m.cut(3, 9, 4, 13, 10, 12);
        for (int x = 4; x < 12; x += 2) m.box(c(0x922B21), x, 1, 3, x + 1, 9, 4);
        m.box(BLACK, 2, 10, 7, 3, 13, 9);
        m.box(BLACK, 13, 10, 7, 14, 13, 9);
        m.box(BLACK, 2, 12, 7, 14, 13, 9);
        return m;
    }

    public static final Model SECURITY_GATE = reg(securityGate());

    private static Model securityGate() {
        Model m = new Model("antirrobo", 1, 2, 1);
        m.box(c(0x7F8C8D), 4, 0, 5, 12, 2, 11);
        m.box(GLASS_W, 7, 2, 4, 9, 26, 12);
        m.box(c(0x7F8C8D), 7, 2, 4, 9, 3, 12);
        m.box(c(0x7F8C8D), 7, 25, 4, 9, 26, 12);
        m.box(LIGHT, 7, 26, 6, 9, 27, 10);
        m.box(c(0x7F8C8D), 7, 2, 4, 9, 26, 5);
        m.box(c(0x7F8C8D), 7, 2, 11, 9, 26, 12);
        return m;
    }

    public static final Model PROMO_SIGN = reg(promoSign());

    private static Model promoSign() {
        Model m = new Model("cartel_oferta", 1, 1, 1);
        for (int y = 0; y < 15; y++) {
            int z = 6 - y / 4;
            m.box(STEEL, 2, y, z, 3, y + 1, z + 1);
            m.box(STEEL, 13, y, z, 14, y + 1, z + 1);
            m.box(STEEL, 2, y, 10 + y / 4, 3, y + 1, 11 + y / 4);
            m.box(STEEL, 13, y, 10 + y / 4, 14, y + 1, 11 + y / 4);
        }
        m.box(YELLOW, 2, 4, 3, 14, 15, 4);
        Kit.text(m, "$", RED, 8, 14, 2, 1);
        m.box(RED, 3, 4, 2, 13, 6, 3);
        m.box(YELLOW, 2, 4, 13, 14, 15, 14);
        return m;
    }

    public static final Model POPCORN = reg(popcorn());

    private static Model popcorn() {
        Model m = new Model("pochoclera", 1, 2, 1);
        m.box(RED, 1, 2, 3, 15, 14, 13);
        for (int z : new int[]{3, 12}) m.cylX(BLACK, 2.5, z + 0.5, 2.5, 0, 2);
        m.box(GOLD, 1, 14, 3, 15, 15, 13);
        m.box(GLASS, 1, 15, 3, 15, 27, 13);
        Rng r = new Rng(5);
        m.box(c(0xFFF8DC), 2, 15, 4, 14, 19, 12);
        for (int z = 4; z < 12; z += 3) m.box(c(0xF7DC6F), 2 + z % 4, 19, z, 10 + z % 3, 20, z + 2);
        m.box(RED, 1, 27, 3, 15, 30, 13);
        m.box(STEEL, 7, 22, 7, 9, 27, 9);
        m.box(STEEL, 6, 22, 6, 10, 24, 10);
        m.box(WARM, 3, 26, 5, 13, 27, 11);
        return m;
    }

    public static final Model CINEMA_SEATS = reg(cinemaSeats());

    private static Model cinemaSeats() {
        Model m = new Model("butacas_cine", 3, 1, 1);
        Mat vel = w(0x8B1A1A);
        for (int i = 0; i < 4; i++) {
            int x = i * 15;
            m.box(BLACK, x, 0, 3, x + 3, 9, 15);
            m.box(BLACK, x, 9, 3, x + 3, 10, 13);
            m.cylY(c(0x2C3E50), x + 1.5, 5, 1.2, 9, 11);
        }
        for (int i = 0; i < 3; i++) {
            int x = 3 + i * 15;
            m.box(vel, x, 4, 3, x + 12, 7, 13);
            m.box(vel, x, 7, 12, x + 12, 16, 15);
            m.box(BLACK, x, 0, 6, x + 12, 4, 13);
        }
        return m;
    }

    public static final Model ARCADE = reg(arcade());

    private static Model arcade() {
        Model m = new Model("arcade", 1, 2, 1);
        Mat side = c(0x512E5F);
        m.box(side, 1, 0, 4, 15, 31, 15);
        m.box(BLACK, 2, 0, 3, 14, 12, 4);
        m.box(c(0x1C2833), 2, 12, 1, 14, 15, 4);
        m.box(RED, 4, 15, 2, 5, 17, 3);
        m.box(c(0xE74C3C), 7, 15, 1, 9, 16, 3);
        m.box(c(0x2E86C1), 10, 15, 1, 12, 16, 3);
        m.box(c(0xF4D03F), 7, 15, 3, 9, 16, 4);
        m.box(BLACK, 2, 16, 4, 14, 26, 5);
        m.box(c(0x0B5345), 3, 17, 3, 13, 25, 4);
        m.box(c(0xF4D03F), 5, 19, 2, 7, 21, 3);
        m.box(c(0xEC7063), 9, 21, 2, 11, 23, 3);
        m.box(c(0x5DADE2), 4, 23, 2, 6, 24, 3);
        m.box(LIGHT, 2, 27, 3, 14, 30, 4);
        m.box(c(0xF39C12), 0, 0, 6, 1, 31, 14);
        m.box(c(0xF39C12), 15, 0, 6, 16, 31, 14);
        m.box(c(0xF4D03F), 6, 5, 2, 10, 7, 3);
        return m;
    }

    public static final Model CLAW = reg(claw());

    private static Model claw() {
        Model m = new Model("maquina_peluches", 1, 2, 1);
        m.box(c(0xE91E63), 0, 0, 0, 16, 11, 16);
        m.box(GLASS, 0, 11, 0, 16, 29, 16);
        m.cut(1, 11, 1, 15, 28, 15);
        Rng r = new Rng(9);
        for (int i = 0; i < 9; i++) m.sphere(c(VIVID[r.nextInt(10)]), 3 + (i % 3) * 4.5, 13, 3 + (i / 3) * 4.5, 2.2);
        m.box(STEEL, 7, 22, 7, 9, 28, 9);
        m.box(STEEL, 6, 20, 6, 10, 22, 10);
        m.box(STEEL, 5, 18, 7, 6, 20, 8);
        m.box(STEEL, 10, 18, 7, 11, 20, 8);
        m.box(c(0xE91E63), 0, 28, 0, 16, 32, 16);
        m.box(LIGHT, 1, 29, 0, 15, 31, 1);
        m.box(BLACK, 4, 8, 0, 6, 11, 1);
        m.box(RED, 4, 11, 1, 6, 12, 3);
        m.box(BLACK, 10, 3, 0, 13, 6, 1);
        return m;
    }

    public static final Model PERFUMES = reg(perfumes());

    private static Model perfumes() {
        Model m = new Model("exhibidor_perfumes", 1, 2, 1);
        m.box(WHITE, 0, 0, 3, 16, 8, 16);
        m.box(GOLD, 0, 7, 3, 16, 8, 16);
        m.box(WHITE, 0, 8, 14, 16, 30, 16);
        int[] cols = {0xF1948A, 0xBB8FCE, 0x85C1E9, 0xF7DC6F, 0x76D7C4};
        Rng r = new Rng(12);
        for (int y : new int[]{8, 15, 22}) {
            m.box(GLASS_W, 1, y, 5, 15, y + 1, 14);
            for (int x = 2; x < 14; x += 4) {
                Mat b = g(cols[r.nextInt(cols.length)], 200);
                m.box(b, x, y + 1, 8, x + 3, y + 4, 11);
                m.box(GOLD, x + 1, y + 4, 9, x + 2, y + 5, 10);
            }
        }
        m.box(PEARL, 1, 29, 12, 15, 30, 14);
        return m;
    }

    // ================================================================== gastronomía

    public static final Model TABLE_TWO = reg(tableTwo());

    private static Model tableTwo() {
        Model m = new Model("mesa_dos", 2, 1, 1);
        m.box(WALNUT, 9, 10, 2, 23, 11, 14);
        m.box(WALNUT, 15, 0, 7, 17, 10, 9);
        m.box(WALNUT, 12, 0, 5, 20, 1, 11);
        m.box(w(0xFFFFFF), 8, 9, 1, 24, 11, 15);
        m.box(w(0xFFFFFF), 9, 11, 2, 23, 11 + 1, 14);
        m.cylY(WHITE, 12, 8, 2, 12, 13);
        m.cylY(WHITE, 20, 8, 2, 12, 13);
        m.cylY(c(0xF5F5F5), 16, 8, 0.8, 12, 15);
        m.box(WARM, 16, 15, 8, 17, 16, 9);
        m.cylY(GLASS, 14, 5, 0.8, 12, 15);
        m.cylY(g(0x922B21, 200), 18, 11, 0.8, 12, 14);
        for (int[] ch : new int[][]{{0, 3}, {24, 1}}) {
            int x = ch[0];
            legs(m, WALNUT, x + 1, 3, x + 8, 13, 0, 6, 1);
            m.box(w(0x922B21), x + 1, 6, 3, x + 8, 8, 13);
            if (ch[1] == 3) m.box(WALNUT, x + 1, 8, 3, x + 2, 16, 13);
            else m.box(WALNUT, x + 7, 8, 3, x + 8, 16, 13);
        }
        return m;
    }

    public static final Model BOOTH = reg(booth());

    private static Model booth() {
        Model m = new Model("reservado", 2, 1, 2);
        Mat vin = c(0xB03A2E);
        for (int[] b : new int[][]{{0, 0}, {22, 1}}) {
            int z0 = b[0];
            m.box(c(0x5D4037), 0, 0, z0, 32, 6, z0 + 10);
            m.box(vin, 0, 6, z0, 32, 8, z0 + 10);
            if (b[1] == 0) m.box(vin, 0, 6, z0, 32, 16, z0 + 3);
            else m.box(vin, 0, 6, z0 + 7, 32, 16, z0 + 10);
            for (int x = 2; x < 32; x += 6) m.box(c(0x922B21), x, 9, b[1] == 0 ? z0 + 2 : z0 + 7, x + 1, 15, b[1] == 0 ? z0 + 3 : z0 + 8);
        }
        m.box(c(0xE5E1DA), 1, 10, 11, 31, 11, 21);
        m.box(STEEL, 1, 9, 11, 31, 10, 12);
        m.box(STEEL, 1, 9, 20, 31, 10, 21);
        m.box(STEEL, 15, 0, 15, 17, 10, 17);
        m.cylY(WHITE, 8, 14, 2, 11, 12);
        m.cylY(WHITE, 24, 18, 2, 11, 12);
        m.cylY(c(0xF4D03F), 16, 16, 1, 11, 14);
        m.cylY(RED, 18, 16, 1, 11, 14);
        return m;
    }

    public static final Model BAR_COUNTER = reg(barCounter());

    private static Model barCounter() {
        Model m = new Model("barra", 3, 1, 2);
        m.box(WALNUT, 0, 0, 18, 48, 14, 30);
        for (int x = 2; x < 47; x += 8) m.box(c(0x5A4030), x, 2, 17, x + 6, 12, 18);
        m.box(c(0x2E1F12), 0, 14, 16, 48, 16, 31);
        m.box(GOLD, 0, 2, 15, 48, 3, 16);
        for (int x : new int[]{4, 20, 36, 44}) m.box(GOLD, x, 2, 16, x + 1, 3, 18);
        for (int x : new int[]{6, 22, 38}) {
            m.cylY(STEEL, x + 2, 7, 3, 0, 1);
            m.cylY(STEEL, x + 2, 7, 0.8, 1, 10);
            m.cylY(LEATHER_D, x + 2, 7, 3.5, 10, 12);
        }
        return m;
    }

    public static final Model BAR_SHELF = reg(barShelf());

    private static Model barShelf() {
        Model m = new Model("estante_botellas", 2, 2, 1);
        m.box(WALNUT, 0, 0, 6, 32, 12, 16);
        m.box(c(0x5A4030), 1, 1, 5, 15, 11, 6);
        m.box(c(0x5A4030), 17, 1, 5, 31, 11, 6);
        m.box(c(0xCFE3EA), 0, 12, 15, 32, 31, 16);
        m.box(WALNUT, 0, 12, 10, 32, 13, 16);
        m.box(WALNUT, 0, 21, 10, 32, 22, 16);
        m.box(WALNUT, 0, 30, 10, 32, 32, 16);
        Rng r = new Rng(14);
        int[] cols = {0x7B241C, 0x1E3A1E, 0xD68910, 0xF4F6F7, 0x6E2C00, 0x1F618D};
        for (int y : new int[]{13, 22}) for (int x = 2; x < 31; x += 3) bottle(m, g(cols[r.nextInt(cols.length)], 210), x + 0.5, 12.5, y, r.range(4, 5), 1.1);
        for (int x = 3; x < 30; x += 6) m.cylY(GLASS, x, 9, 1.2, 12, 14);
        m.box(WARM, 1, 29, 12, 31, 30, 13);
        return m;
    }

    public static final Model BEER_TAPS = reg(beerTaps());

    private static Model beerTaps() {
        Model m = new Model("chopera", 2, 1, 1);
        m.box(WALNUT, 0, 0, 3, 32, 13, 16);
        m.box(c(0x2E1F12), 0, 13, 2, 32, 14, 16);
        m.box(STEEL, 6, 14, 9, 26, 16, 11);
        for (int x : new int[]{8, 15, 22}) {
            m.box(STEEL, x, 13, 6, x + 2, 15, 9);
            m.box(new Mat[]{BLACK, GOLD, RED}[(x / 7) % 3], x, 15, 6, x + 2, 16, 7);
        }
        for (int x : new int[]{3, 28}) {
            m.cylY(GLASS, x, 7, 1.6, 14, 16);
            m.cylY(c(0xF5B041), x, 7, 1.3, 14, 15);
        }
        m.box(STEEL, 6, 13, 4, 26, 14, 6);
        return m;
    }

    public static final Model BISTRO = reg(bistro());

    private static Model bistro() {
        Model m = new Model("mesa_alta", 1, 1, 1);
        m.cylY(BLACK, 8, 8, 4, 0, 1);
        m.cylY(BLACK, 8, 8, 0.9, 1, 15);
        m.cylY(MARBLE, 8, 8, 6, 15, 16);
        return m;
    }

    public static final Model SALAD_BAR = reg(saladBar());

    private static Model saladBar() {
        Model m = new Model("barra_ensaladas", 3, 1, 1);
        m.box(OAK, 0, 0, 2, 48, 10, 15);
        m.box(STEEL, 0, 10, 2, 48, 11, 15);
        int[] cols = {0x27AE60, 0xE74C3C, 0xF4D03F, 0xF39C12, 0x8E44AD, 0xF5F5F5, 0x58D68D, 0xC0392B, 0xD4AC0D};
        for (int i = 0; i < 9; i++) {
            int x = 1 + (i % 5) * 9 + (i >= 5 ? 4 : 0), z = i < 5 ? 4 : 9;
            m.box(STEEL, x, 10, z, x + 6, 12, z + 4);
            m.box(c(cols[i]), x + 1, 11, z + 1, x + 5, 12, z + 3);
        }
        m.box(STEEL, 1, 11, 7, 2, 16, 8);
        m.box(STEEL, 46, 11, 7, 47, 16, 8);
        m.box(GLASS, 0, 15, 2, 48, 16, 12);
        return m;
    }

    public static final Model PREP_TABLE = reg(prepTable());

    private static Model prepTable() {
        Model m = new Model("mesa_acero", 2, 1, 1);
        m.box(STEEL, 0, 13, 1, 32, 14, 15);
        legs(m, STEEL, 1, 2, 31, 14, 0, 13, 1);
        m.box(STEEL, 1, 3, 2, 31, 4, 14);
        m.cylY(c(0x5D6D7E), 6, 6, 3, 4, 8);
        m.cylY(c(0x5D6D7E), 12, 9, 2.5, 4, 7);
        m.box(BIRCH, 14, 14, 4, 24, 15, 11);
        m.box(c(0xE74C3C), 16, 15, 6, 18, 16, 8);
        m.box(c(0x27AE60), 20, 15, 7, 22, 16, 9);
        m.cylY(STEEL, 28, 8, 2.6, 14, 16);
        return m;
    }

    public static final Model IND_STOVE = reg(industrialStove());

    private static Model industrialStove() {
        Model m = new Model("cocina_industrial", 2, 1, 1);
        m.box(STEEL, 0, 0, 2, 32, 13, 16);
        for (int x : new int[]{1, 17}) {
            m.box(c(0x5D6D7E), x, 1, 1, x + 14, 9, 2);
            m.box(STEEL, x + 2, 7, 0, x + 12, 8, 1);
        }
        for (int x = 2; x < 31; x += 4) m.box(BLACK, x, 10, 1, x + 2, 12, 2);
        m.box(BLACK, 0, 13, 2, 32, 14, 16);
        for (int i = 0; i < 6; i++) {
            int x = 5 + (i % 3) * 11, z = i < 3 ? 6 : 12;
            m.cylY(c(0x444444), x, z, 2.6, 14, 15);
        }
        m.cylY(c(0x95A5A6), 5, 6, 3.4, 14, 16);
        m.cylY(c(0x2C3E50), 27, 12, 3, 14, 16);
        m.box(BLACK, 30, 15, 11, 32, 16, 13);
        return m;
    }

    public static final Model DOUBLE_SINK = reg(doubleSink());

    private static Model doubleSink() {
        Model m = new Model("pileta_doble", 2, 1, 1);
        m.box(STEEL, 0, 12, 1, 32, 14, 16);
        legs(m, STEEL, 1, 2, 31, 15, 0, 12, 1);
        for (int x : new int[]{3, 18}) {
            m.cut(x, 8, 3, x + 11, 14, 13);
            m.box(STEEL, x, 7, 3, x + 11, 8, 13);
            m.box(STEEL, x - 1, 7, 2, x, 14, 14);
            m.box(STEEL, x + 11, 7, 2, x + 12, 14, 14);
            m.box(STEEL, x, 7, 2, x + 11, 14, 3);
            m.box(STEEL, x, 7, 13, x + 11, 14, 14);
        }
        m.box(STEEL, 15, 14, 14, 17, 16, 16);
        m.box(STEEL, 15, 15, 9, 17, 16, 14);
        m.box(STEEL, 0, 14, 15, 32, 16, 16);
        return m;
    }

    public static final Model HOT_DOG = reg(hotDog());

    private static Model hotDog() {
        Model m = new Model("maquina_panchos", 1, 1, 1);
        m.box(STEEL, 1, 0, 3, 15, 4, 14);
        m.box(GLASS, 1, 4, 3, 15, 11, 14);
        m.cut(2, 4, 4, 14, 10, 13);
        for (int z = 5; z < 13; z += 2) {
            m.cylX(STEEL, 4.5, z, 0.8, 2, 14);
            m.cylX(c(0xB9572A), 5.5, z, 0.9, 3, 13);
        }
        m.box(RED, 1, 11, 3, 15, 13, 14);
        m.box(WARM, 3, 10, 6, 13, 11, 11);
        m.box(RED, 1, 1, 2, 15, 3, 3);
        return m;
    }

    public static final Model SLUSHIE = reg(slushie());

    private static Model slushie() {
        Model m = new Model("maquina_granizados", 1, 1, 1);
        m.box(WHITE, 1, 0, 3, 15, 5, 15);
        m.box(BLACK, 2, 2, 2, 6, 4, 3);
        m.box(BLACK, 10, 2, 2, 14, 4, 3);
        for (int[] t : new int[][]{{4, 0x3498DB}, {12, 0xE74C3C}}) {
            m.box(GLASS, t[0] - 3, 5, 4, t[0] + 3, 14, 13);
            m.box(c(t[1]), t[0] - 2, 5, 5, t[0] + 2, 12, 12);
            m.box(WHITE, t[0] - 3, 14, 4, t[0] + 3, 16, 13);
            m.box(STEEL, t[0] - 1, 4, 2, t[0] + 1, 6, 4);
        }
        return m;
    }
}
