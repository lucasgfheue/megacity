package com.megaciudad.core;

import com.megaciudad.core.little.LittleBlock;
import com.megaciudad.core.little.Model;

/** Destino de los bloques generados: un chunk de Minecraft o el mundo en memoria del renderizador. */
public interface BlockSink {
    void set(int x, int y, int z, BlockRef b);

    /** Bloque de LittleTiles (mini-bloques) en una posición. */
    void little(int x, int y, int z, LittleBlock lb);

    /** Cartel vanilla con texto (líneas 0..3). */
    void sign(int x, int y, int z, BlockRef state, String[] lines, String color, boolean glowing);

    /** Aviso de que se colocó un modelo de mini-bloques (solo para estadísticas; por defecto no hace nada). */
    default void onModel(Model m, int k, int x, int y, int z) {
    }
}
