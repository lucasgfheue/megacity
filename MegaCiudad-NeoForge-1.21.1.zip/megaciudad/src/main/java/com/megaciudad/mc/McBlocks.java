package com.megaciudad.mc;

import com.megaciudad.MegaCiudad;
import com.megaciudad.core.BlockRef;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Convierte las referencias de bloque del generador ("minecraft:oak_stairs[facing=north]") en BlockState. */
public final class McBlocks {
    private McBlocks() {
    }

    private static final Set<String> WARNED = ConcurrentHashMap.newKeySet();

    public static BlockState state(BlockRef ref) {
        Object cached = ref.mcState;
        if (cached instanceof BlockState bs) return bs;
        BlockState st = resolve(ref);
        ref.mcState = st;
        return st;
    }

    private static BlockState resolve(BlockRef ref) {
        ResourceLocation rl = ResourceLocation.tryParse(ref.id);
        Optional<Block> block = rl == null ? Optional.empty() : BuiltInRegistries.BLOCK.getOptional(rl);
        if (block.isEmpty()) {
            if (WARNED.add(ref.id)) MegaCiudad.LOGGER.warn("Bloque desconocido en la ciudad: {}", ref.id);
            return Blocks.AIR.defaultBlockState();
        }
        Block b = block.get();
        BlockState st = b.defaultBlockState();
        StateDefinition<Block, BlockState> def = b.getStateDefinition();
        for (int i = 0; i < ref.keys.length; i++) {
            Property<?> prop = def.getProperty(ref.keys[i]);
            if (prop != null) st = with(st, prop, ref.values[i]);
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState with(BlockState st, Property<T> prop, String value) {
        Optional<T> v = prop.getValue(value);
        return v.isPresent() ? st.setValue(prop, v.get()) : st;
    }
}
