# MegaCiudad — mod para Minecraft 1.21.1 (NeoForge)

Genera una **ciudad de 2000 × 2000 bloques** en el mundo normal, centrada en 0,0: rascacielos, torres
de oficinas y residenciales, hoteles, apartamentos, casas adosadas, barrios de casas con jardín,
locales a la calle, **supermercados**, **shoppings** de 3 pisos, la **Estación Central** de trenes,
**dos líneas de metro elevado** con estaciones, hospital, escuelas, bomberos, policía, estaciones de
servicio, garajes, estacionamientos, parques, plazas, la plaza central con obelisco, intendencia,
catedral, estadio y zona industrial.

**Decoración con bloques de mods (sin LittleTiles).** Los edificios se amueblan
con bloques reales de estos mods, si los tienes instalados:

- **MrCrayfish's Furniture Mod: Refurbished**: sillas, mesas, sofás, escritorios, cajoneras, roperos,
  cocinas completas (mesadas, piletas, heladeras, hornos, microondas, tostadoras, campanas), baños
  (inodoros, lavatorios, bañeras), televisores, computadoras, lámparas, ventiladores y luces de techo,
  tachos de reciclaje y buzones.
- **Create**: máquinas en fábricas y talleres (prensas, taladros, brazos mecánicos, sierras, tanques,
  bóvedas, ejes, engranajes y medidores), cajas de herramientas, relojes cucú, pantallas de salidas en
  la estación, asientos, manteles de exhibición en los comercios, terminales de venta y cajas de cartón
  en los depósitos.
- **Create Deco**: faroles de jaula en calles, parques y arañas de techo, y pilas de monedas en las
  joyerías. **Create Slice & Dice**: rebanadoras en las cocinas de los restaurantes.
- **Farmer's Delight**: cocinas, ollas, sartenes, tablas de cortar, alacenas, cajones de verduras en
  los supermercados y **comida servida** (pollo asado, jamón glaseado, pastel de papas, tartas) en
  restaurantes, patios de comida, panaderías y casas.
- **Extra Delight**: más comida servida (lasaña, curry, costillas, brownies, cheesecakes, tartas,
  pan, rolls de canela), vitrinas, especieros, hornos, golosinas, cajones de frutas y bolsas de harina.
- **Neapolitan**: helados de seis sabores en las vitrinas de las heladerías, tortas, licuados y
  canastos de frutillas y bananas en las verdulerías.

Todos son **opcionales**: instala los que quieras. Si falta alguno, en su lugar se usa una alternativa
con bloques normales (por ejemplo, escaleras en vez de sillas o una torta común en vez de la comida).
Para el resultado completo, instálalos todos.

**Plantas realistas (versión 1.3.0).** Los interiores se arman como en la realidad, con tabiques,
puertas y cada mueble en su lugar:

- **Oficinas**: bancadas de escritorios enfrentados con computadora y silla, en filas con pasillos;
  en los pisos angostos, escritorios en fila mirando a las ventanas; salas de reuniones vidriadas con
  mesa, sillas y tele; café con heladera, pileta y cafetera, rincón de impresoras y estar con sofás.
- **Hoteles**: pasillo alfombrado y habitaciones con baño junto a la entrada, cama doble con mesas de
  luz, tele enfrente, ropero, escritorio y sillón junto a la ventana.
- **Torres y edificios de departamentos**: pasillo con puertas; cada departamento tiene baño, cocina
  en línea con alacenas y campana, living con tele, sofá, mesa ratona y alfombra, comedor y
  dormitorio con cama, mesas de luz, ropero y cómoda (los más grandes, un segundo dormitorio o
  estudio). En planta baja, hall de entrada con buzones.
- **Casas**: living y cocina-comedor abajo; dormitorios y baño arriba (en las de un piso, todo en la
  misma planta con tabiques).

**Todos los edificios están amueblados por dentro**, con un mínimo de 15 decoraciones cada uno (la
mayoría tiene muchas más): casas y departamentos, oficinas, hoteles, cada rubro de local, hospital,
escuelas, bomberos, policía, depósitos, fábricas, supermercados, shoppings, estación de trenes,
catedral y estadio.

**No agrega ningún ítem ni bloque propio**: todo se construye con bloques vanilla y de los mods
instalados, así que nada de lo creado por MegaCiudad aparece en el inventario.

---

## 1. Qué necesitas

| Mod | Versión | ¿Obligatorio? |
|---|---|---|
| Minecraft | 1.21.1 | sí |
| NeoForge | 21.1.x (el proyecto está configurado con 21.1.265) | sí |
| Create | 6.0.x para 1.21.1 | opcional (recomendado) |
| Farmer's Delight | 1.2.x o más nuevo para 1.21.1 | opcional (recomendado) |
| MrCrayfish's Furniture Mod: Refurbished | 1.0.x para NeoForge 1.21.1 (requiere Framework) | opcional (recomendado) |
| Extra Delight | 2.x para 1.21.1 (requiere Farmer's Delight) | opcional |
| Neapolitan | 6.x para 1.21.1 (requiere Blueprint) | opcional |
| Create Deco | 2.1.x para NeoForge 1.21.1 (requiere Create) | opcional |
| Create Slice & Dice | para NeoForge 1.21.1 (requiere Create y Farmer's Delight) | opcional |

Todos se bajan de Modrinth o CurseForge (cada página indica sus librerías). LittleTiles y
CreativeCore ya no hacen falta.

## 2. Compilar el .jar (una sola vez, en una PC)

1. Instala el **JDK 21** (por ejemplo, Eclipse Temurin 21 de adoptium.net).
2. Descomprime este proyecto en una carpeta.
3. Abre una terminal en esa carpeta y ejecuta:
   - Windows: `gradlew.bat build`
   - Linux / macOS: `./gradlew build`
4. La primera vez descarga Gradle, NeoForge y Minecraft (tarda varios minutos).
5. El mod queda en `build/libs/megaciudad-1.3.0.jar`.

**Alternativa sin instalar nada (GitHub):**
1. Crea un repositorio nuevo y sube este zip **tal cual**, sin descomprimirlo (*Add file → Upload files*).
2. Crea el archivo `.github/workflows/build.yml` (*Add file → Create new file*) y pega el workflow
   que viene en este proyecto en `.github/workflows/build.yml`.
3. GitHub descomprime el zip y compila solo (tarda unos minutos). El .jar aparece en **Releases**
   (y también en *Actions* → la ejecución → *Artifacts*).

El mismo workflow funciona si subes el código ya descomprimido.

## 3. Instalar y jugar

1. Copia en la carpeta `mods` de tu instancia NeoForge 1.21.1 `megaciudad-1.3.0.jar` y los mods
   de la lista de arriba que quieras usar (con sus librerías). Borra la versión anterior de
   MegaCiudad; si tenías LittleTiles y CreativeCore solo por la ciudad, también puedes quitarlos.
2. **Crea un mundo nuevo** (tipo "Predeterminado" o "Biomas grandes"). La ciudad solo se genera en
   chunks nuevos, así que en un mundo ya explorado cerca de 0,0 quedaría cortada.
3. Apareces en la **plaza central** (junto a la fuente). La ciudad va de x −1008 a 992 y de
   z −1008 a 992. Alrededor, el terreno baja o sube suavemente hasta el relieve natural.

Consejos:
- Los rascacielos tienen escalera de caracol funcional en el núcleo (y salida a la azotea).
- Las vías del metro elevado son funcionales: pon una vagoneta en las vías desde un andén
  (las estaciones tienen escaleras que bajan al cantero central de la avenida).
- Las calles, interiores, parques, patios y azoteas tienen luz (bloques de luz invisibles y
  faroles) para que no aparezcan monstruos.
- No se generan aldeas ni otras estructuras dentro de la ciudad.

## 4. Configuración

Archivo `config/megaciudad-common.toml` (se crea al iniciar el juego):

| Opción | Por defecto | Qué hace |
|---|---|---|
| `enabled` | `true` | generar la ciudad |
| `centerX`, `centerZ` | `0` | centro de la ciudad |
| `spawnInPlaza` | `true` | aparecer en la plaza central al crear el mundo |
| `interiorDetail` | `2` | muebles dentro de los edificios: `0` ninguno; `1`, `2` o `3`, todos los pisos amueblados |

Con `interiorDetail = 0` los edificios quedan vacíos (máximo rendimiento). Cámbialo **antes** de crear
el mundo: los chunks ya generados no cambian.

## 5. Detalles técnicos

- La ciudad se genera en la etapa de decoración de cada chunk (mixin en
  `ChunkGenerator#applyBiomeDecoration`), con un generador determinista: cada chunk produce solo
  su parte de cada edificio, así que los edificios cruzan chunks sin cortes. Otro mixin en
  `ChunkGenerator#createStructures` evita estructuras vanilla dentro y alrededor de la ciudad.
- Las decoraciones son bloques comunes. Cada una indica el bloque del mod y una alternativa
  (`mod:bloque|otro_mod:bloque|minecraft:bloque`); al generar, se usa el primero que exista. En el log
  aparece una vez `El mod '...' no está instalado` por cada mod que falte.
- El generador es Java puro (`com.megaciudad.core`); se probó generando los 15.625 chunks de la
  ciudad completa sin errores (≈ 0,4 ms por chunk fuera del juego).
- Sin LittleTiles la ciudad es mucho más liviana. Si aun así el juego va lento en el centro, prueba
  con un mundo nuevo y `interiorDetail = 0`.
- Si ves en el log `Bloque desconocido en la ciudad`, avísame: significa que un nombre de bloque
  vanilla no existe en tu versión.
