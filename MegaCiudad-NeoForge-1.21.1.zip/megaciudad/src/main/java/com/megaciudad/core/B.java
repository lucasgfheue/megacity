package com.megaciudad.core;

/** Paleta de bloques vanilla (1.21.1) y ayudas para estados con orientación. */
public final class B {
    private B() {
    }

    public static BlockRef of(String s) {
        return BlockRef.of(s);
    }

    public static final BlockRef AIR = of("air");
    public static final BlockRef STONE = of("stone");
    public static final BlockRef DIRT = of("dirt");
    public static final BlockRef COARSE_DIRT = of("coarse_dirt");
    public static final BlockRef GRASS = of("grass_block[snowy=false]");
    public static final BlockRef PODZOL = of("podzol[snowy=false]");
    public static final BlockRef MOSS = of("moss_block");
    public static final BlockRef SAND = of("sand");
    public static final BlockRef GRAVEL = of("gravel");
    public static final BlockRef WATER = of("water[level=0]");
    public static final BlockRef LIGHT15 = of("light[level=15,waterlogged=false]");
    public static final BlockRef LIGHT12 = of("light[level=12,waterlogged=false]");
    public static final BlockRef LIGHT10 = of("light[level=10,waterlogged=false]");

    // Calles
    public static final BlockRef ASPHALT = of("gray_concrete");
    public static final BlockRef ASPHALT_WORN = of("gray_concrete_powder");
    public static final BlockRef ASPHALT_DARK = of("black_concrete");
    public static final BlockRef MARK_WHITE = of("white_concrete");
    public static final BlockRef MARK_YELLOW = of("yellow_concrete");
    public static final BlockRef SIDEWALK = of("smooth_stone_slab[type=bottom,waterlogged=false]");
    public static final BlockRef SIDEWALK_BASE = of("smooth_stone");
    public static final BlockRef CURB = of("polished_andesite_slab[type=bottom,waterlogged=false]");

    // Piedra y hormigón
    public static final BlockRef SMOOTH_STONE = of("smooth_stone");
    public static final BlockRef STONE_BRICKS = of("stone_bricks");
    public static final BlockRef CHISELED_STONE = of("chiseled_stone_bricks");
    public static final BlockRef ANDESITE = of("andesite");
    public static final BlockRef P_ANDESITE = of("polished_andesite");
    public static final BlockRef P_DIORITE = of("polished_diorite");
    public static final BlockRef P_GRANITE = of("polished_granite");
    public static final BlockRef P_DEEPSLATE = of("polished_deepslate");
    public static final BlockRef DEEPSLATE_TILES = of("deepslate_tiles");
    public static final BlockRef DEEPSLATE_BRICKS = of("deepslate_bricks");
    public static final BlockRef TUFF_BRICKS = of("tuff_bricks");
    public static final BlockRef P_TUFF = of("polished_tuff");
    public static final BlockRef CALCITE = of("calcite");
    public static final BlockRef BRICKS = of("bricks");
    public static final BlockRef MUD_BRICKS = of("mud_bricks");
    public static final BlockRef QUARTZ = of("quartz_block");
    public static final BlockRef SMOOTH_QUARTZ = of("smooth_quartz");
    public static final BlockRef QUARTZ_PILLAR = of("quartz_pillar[axis=y]");
    public static final BlockRef QUARTZ_BRICKS = of("quartz_bricks");
    public static final BlockRef SANDSTONE_SMOOTH = of("smooth_sandstone");
    public static final BlockRef SANDSTONE_CUT = of("cut_sandstone");
    public static final BlockRef RED_SANDSTONE_SMOOTH = of("smooth_red_sandstone");
    public static final BlockRef P_BLACKSTONE = of("polished_blackstone");
    public static final BlockRef P_BLACKSTONE_BRICKS = of("polished_blackstone_bricks");
    public static final BlockRef PRISMARINE_BRICKS = of("prismarine_bricks");
    public static final BlockRef DARK_PRISMARINE = of("dark_prismarine");
    public static final BlockRef IRON_BLOCK = of("iron_block");
    public static final BlockRef GOLD_BLOCK = of("gold_block");
    public static final BlockRef COPPER = of("waxed_copper_block");
    public static final BlockRef CUT_COPPER = of("waxed_cut_copper");
    public static final BlockRef OX_COPPER = of("waxed_oxidized_cut_copper");
    public static final BlockRef COPPER_GRATE = of("waxed_copper_grate[waterlogged=false]");
    public static final BlockRef HAY = of("hay_block[axis=y]");

    // Vidrio
    public static final BlockRef GLASS = of("glass");
    public static final BlockRef TINTED = of("tinted_glass");
    public static final BlockRef IRON_BARS = of("iron_bars[east=false,north=false,south=false,west=false,waterlogged=false]");
    public static final BlockRef CHAIN = of("chain[axis=y,waterlogged=false]");

    // Luces
    public static final BlockRef SEA_LANTERN = of("sea_lantern");
    public static final BlockRef GLOWSTONE = of("glowstone");
    public static final BlockRef SHROOMLIGHT = of("shroomlight");
    public static final BlockRef OCHRE_LIGHT = of("ochre_froglight[axis=y]");
    public static final BlockRef PEARL_LIGHT = of("pearlescent_froglight[axis=y]");
    public static final BlockRef VERDANT_LIGHT = of("verdant_froglight[axis=y]");
    public static final BlockRef LANTERN = of("lantern[hanging=false,waterlogged=false]");
    public static final BlockRef LANTERN_HANG = of("lantern[hanging=true,waterlogged=false]");
    public static final BlockRef END_ROD = of("end_rod[facing=up]");

    // Raíles
    public static final BlockRef REDSTONE_BLOCK = of("redstone_block");

    // Varios
    public static final BlockRef BOOKSHELF = of("bookshelf");
    public static final BlockRef BARREL = of("barrel[facing=up,open=false]");
    public static final BlockRef CAULDRON = of("cauldron");
    public static final BlockRef FLOWER_POT = of("flower_pot");
    public static final BlockRef LADDER_N = of("ladder[facing=north,waterlogged=false]");
    public static final BlockRef SHORT_GRASS = of("short_grass");
    public static final BlockRef FERN = of("fern");
    public static final BlockRef AZALEA = of("azalea");
    public static final BlockRef FLOWERING_AZALEA = of("flowering_azalea");
    public static final BlockRef[] FLOWERS = {
            of("dandelion"), of("poppy"), of("blue_orchid"), of("allium"), of("azure_bluet"), of("red_tulip"),
            of("orange_tulip"), of("white_tulip"), of("pink_tulip"), of("oxeye_daisy"), of("cornflower"), of("lily_of_the_valley")};
    public static final BlockRef[] POTTED = {
            of("potted_fern"), of("potted_azalea_bush"), of("potted_flowering_azalea_bush"), of("potted_red_tulip"),
            of("potted_oak_sapling"), of("potted_cactus"), of("potted_bamboo"), of("potted_poppy"), of("potted_blue_orchid")};

    public static final String[] COLORS = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};

    public static BlockRef concrete(String color) {
        return of(color + "_concrete");
    }

    public static BlockRef terracotta(String color) {
        return of(color + "_terracotta");
    }

    public static BlockRef wool(String color) {
        return of(color + "_wool");
    }

    public static BlockRef glass(String color) {
        return of(color + "_stained_glass");
    }

    public static BlockRef carpet(String color) {
        return of(color + "_carpet");
    }

    /** Escalera. facing = dirección en la que se sube. */
    public static BlockRef stairs(String material, String facing, boolean top) {
        return of(material + "_stairs[facing=" + facing + ",half=" + (top ? "top" : "bottom") + ",shape=straight,waterlogged=false]");
    }

    public static BlockRef slab(String material, boolean top) {
        return of(material + "_slab[type=" + (top ? "top" : "bottom") + ",waterlogged=false]");
    }

    public static BlockRef doubleSlab(String material) {
        return of(material + "_slab[type=double,waterlogged=false]");
    }

    public static BlockRef log(String wood, String axis) {
        return of(wood + "_log[axis=" + axis + "]");
    }

    public static BlockRef leaves(String type) {
        return of(type + "_leaves[distance=7,persistent=true,waterlogged=false]");
    }

    public static BlockRef planks(String wood) {
        return of(wood + "_planks");
    }

    /** Panel de vidrio con conexiones explícitas (luego se reajustan en el post-procesado). */
    public static BlockRef pane(String id, boolean ns, boolean ew) {
        return of(id + "[east=" + ew + ",north=" + ns + ",south=" + ns + ",waterlogged=false,west=" + ew + "]");
    }

    public static BlockRef fence(String wood, boolean ns, boolean ew) {
        return of(wood + "_fence[east=" + ew + ",north=" + ns + ",south=" + ns + ",waterlogged=false,west=" + ew + "]");
    }

    public static BlockRef wall(String material, boolean ns, boolean ew) {
        String l = ns ? "low" : "none", w = ew ? "low" : "none";
        return of(material + "_wall[east=" + w + ",north=" + l + ",south=" + l + ",up=true,waterlogged=false,west=" + w + "]");
    }

    public static BlockRef trapdoor(String material, String facing, boolean top, boolean open) {
        return of(material + "_trapdoor[facing=" + facing + ",half=" + (top ? "top" : "bottom") + ",open=" + open
                + ",powered=false,waterlogged=false]");
    }

    public static BlockRef door(String material, String facing, boolean upper, boolean rightHinge) {
        return of(material + "_door[facing=" + facing + ",half=" + (upper ? "upper" : "lower") + ",hinge="
                + (rightHinge ? "right" : "left") + ",open=false,powered=false]");
    }

    public static BlockRef rail(boolean ns) {
        return of("rail[shape=" + (ns ? "north_south" : "east_west") + ",waterlogged=false]");
    }

    public static BlockRef poweredRail(boolean ns) {
        return of("powered_rail[powered=true,shape=" + (ns ? "north_south" : "east_west") + ",waterlogged=false]");
    }

    public static BlockRef wallSign(String wood, String facing) {
        return of(wood + "_wall_sign[facing=" + facing + ",waterlogged=false]");
    }

    public static BlockRef bed(String color, String facing, boolean head) {
        return of(color + "_bed[facing=" + facing + ",occupied=false,part=" + (head ? "head" : "foot") + "]");
    }

    public static BlockRef light(int level) {
        return of("light[level=" + level + ",waterlogged=false]");
    }
}
