package com.megaciudad.core.little;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Industria y depósitos (máquinas de Create), estacionamientos, servicentros, gimnasio y estadio. */
public final class FInd {
    private FInd() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    // ------------------------------------------------------------------ depósito

    public static final Model PALLET_RACK = reg(m("estanteria_pallets", 3, 3, 1)
            .b(0, 0, 0, crate("spruce")).b(1, 0, 0, CARDBOARD).b(2, 0, 0, crate("spruce"))
            .b(0, 1, 0, CARDBOARD_TIED).b(1, 1, 0, crate("oak")).b(2, 1, 0, CARDBOARD)
            .b(0, 2, 0, crate("spruce")).b(1, 2, 0, CARDBOARD_TIED).b(2, 2, 0, crate("oak")));
    public static final Model PALLET_BOXES = reg(one("pallet_cajas", CARDBOARD));
    public static final Model PALLETS = reg(one("pallets", v("spruce_slab[type=bottom]")));
    public static final Model FORKLIFT = reg(m("autoelevador", 1, 2, 2)
            .b(0, 0, 0, v("iron_trapdoor[facing=north,half=bottom,open=false]")).b(0, 1, 0, v("iron_bars"))
            .b(0, 0, 1, v("yellow_concrete")).b(0, 1, 1, seat("black")));
    public static final Model CRATES = reg(one("cajones", crate("spruce")));
    public static final Model DRUMS = reg(one("tambores", TANK));
    public static final Model BOX_STACK = reg(col("pila_cajas", CARDBOARD, CARDBOARD_TIED));
    public static final Model HAND_TRUCK = reg(one("zorra", v("iron_bars")));
    public static final Model CONVEYOR = reg(row("cinta", DEPOT, DEPOT, DEPOT));

    // ------------------------------------------------------------------ taller y fábrica

    public static final Model WORKBENCH = reg(row2("banco_trabajo", a(Kit.WORKBENCH, v("smithing_table")),
            a(toolbox("red"), v("grindstone[face=floor,facing=north]"))));
    public static final Model TOOL_CHEST = reg(one("caja_herramientas", toolbox("red")));
    public static final Model LATHE = reg(row("torno", r(CR + "andesite_encased_shaft[axis=x]|" + MC + "polished_andesite"), SAW_UP));
    public static final Model DRILL_PRESS = reg(col("taladro_banco", DEPOT, r(CR + "mechanical_drill[facing=down]|" + MC + "dispenser[facing=down]")));
    public static final Model CONTROL_PANEL = reg(col("tablero_control", BRASS_CASING, STRESSOMETER));
    public static final Model GENERATOR = reg(row("generador", Kit.GENERATOR, FLYWHEEL));
    public static final Model GAS_CYL = reg(one("garrafa", BACKTANK));
    public static final Model ELECTRIC_CAB = reg(col("tablero_electrico", COPPER_CASING, COPPER_CASING));
    public static final Model WELDER = reg(one("soldadora", BURNER));
    public static final Model CNC = reg(row2("cnc", a(ANDESITE_CASING, GEARBOX), a(CRAFTER, COG_Y)));
    public static final Model ROBOT_ARM = reg(col("brazo_robot", ANDESITE_CASING, ARM));
    public static final Model TIRES = reg(one("cubiertas", v("black_concrete")));

    // ------------------------------------------------------------------ estacionamiento y servicentro

    public static final Model EV_CHARGER = reg(col("cargador_electrico", v("white_concrete"), v("verdant_froglight")));
    public static final Model PAY_STATION = reg(col("cajero_estacionamiento", ANDESITE_CASING, STOCK_TICKER));
    public static final Model OIL_RACK = reg(col("estante_aceite", TANK_LOW, TANK_HIGH));
    public static final Model AIR_PUMP = reg(one("inflador", PUMP_UP));
    public static final Model ICE_CHEST = reg(one("conservadora", cooler("light_blue")));

    // ------------------------------------------------------------------ gimnasio y estadio

    public static final Model TREADMILL = reg(m("cinta_correr", 1, 1, 2).b(0, 0, 0, v("smooth_stone_slab[type=bottom]")).b(0, 0, 1, v("black_carpet")));
    public static final Model EXERCISE_BIKE = reg(one("bici_fija", v("anvil[facing=north]")));
    public static final Model BENCH_PRESS = reg(m("banco_pesas", 1, 2, 2).b(0, 0, 0, v("chain[axis=x]")).b(0, 1, 0, v("iron_bars"))
            .b(0, 0, 1, seat("black")));
    public static final Model DUMBBELLS = reg(row("mancuernas", n(2, v("heavy_weighted_pressure_plate"))));
    public static final Model PUNCHING_BAG = reg(col("bolsa_boxeo", null, v("red_wool")));
    public static final Model TEAM_BENCH = reg(m("banco_suplentes", 3, 2, 1).fill(0, 0, 0, 2, 0, 0, seatStairs("spruce")));
    public static final Model CONCESSION = reg(row2("cantina", n(2, counter("red")),
            a(edFeast("bbq_ribs_block", "roast_chicken_block"), CANDY_BOWL)));
}
