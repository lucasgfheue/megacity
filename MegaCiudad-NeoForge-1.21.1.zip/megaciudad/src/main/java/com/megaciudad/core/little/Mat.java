package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

/** Material de un mini-bloque: bloque base (cubo completo) + color ARGB de LittleTiles (-1 = sin tinte). */
public final class Mat {
    public static final int NO_COLOR = -1;
    public final BlockRef block;
    public final int color;
    private final Mat[] rots = new Mat[4];

    private Mat(BlockRef block, int color) {
        this.block = block;
        this.color = color;
        rots[0] = this;
    }

    public static Mat of(String id) {
        return new Mat(BlockRef.of(id), NO_COLOR);
    }

    public static Mat of(BlockRef b) {
        return new Mat(b, NO_COLOR);
    }

    /** Material teñido: rgb = 0xRRGGBB. */
    public static Mat tint(String id, int rgb) {
        return new Mat(BlockRef.of(id), 0xFF000000 | rgb);
    }

    /** Material translúcido teñido (alpha 0-255). */
    public static Mat tint(String id, int rgb, int alpha) {
        return new Mat(BlockRef.of(id), (alpha & 255) << 24 | (rgb & 0xFFFFFF));
    }

    public Mat rot(int k) {
        k &= 3;
        Mat m = rots[k];
        if (m == null) {
            BlockRef r = block.rot(k);
            m = r == block ? this : new Mat(r, color);
            rots[k] = m;
        }
        return m;
    }
}
