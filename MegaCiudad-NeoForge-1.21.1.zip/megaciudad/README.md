# MegaCiudad — mod para Minecraft 1.21.1 (NeoForge)

Genera una **ciudad de 2000 × 2000 bloques** en el mundo normal, centrada en 0,0: rascacielos, torres
de oficinas y residenciales, hoteles, apartamentos, casas adosadas, barrios de casas con jardín,
locales a la calle, **supermercados**, **shoppings** de 3 pisos, la **Estación Central** de trenes,
**dos líneas de metro elevado** con estaciones, hospital, escuelas, bomberos, policía, estaciones de
servicio, garajes, estacionamientos, parques, plazas, la plaza central con obelisco, intendencia,
catedral, estadio y zona industrial.

Las decoraciones (faroles, semáforos, bancos, paradas de ómnibus, autos, góndolas, heladeras, cajas
registradoras, sillones, escritorios, juegos de plaza, carteles con letras, etc. — 56 modelos) están
hechas con **mini-bloques de LittleTiles** (grilla 16).

**No agrega ningún ítem ni bloque propio**: todo se construye con bloques vanilla y bloques de
LittleTiles, así que nada de lo creado aparece en el inventario.

---

## 1. Qué necesitas

| Mod | Versión | ¿Obligatorio? |
|---|---|---|
| Minecraft | 1.21.1 | sí |
| NeoForge | 21.1.x (el proyecto está configurado con 21.1.265) | sí |
| LittleTiles | 1.6.0 (beta) para NeoForge 1.21.1 | para las decoraciones de mini-bloques |
| CreativeCore | 2.13.x para NeoForge 1.21.1 (lo requiere LittleTiles) | junto con LittleTiles |

LittleTiles y CreativeCore se bajan de Modrinth o CurseForge. Sin LittleTiles el mod funciona igual,
pero las decoraciones se reemplazan por aproximaciones con bloques normales (o se omiten).

## 2. Compilar el .jar (una sola vez, en una PC)

1. Instala el **JDK 21** (por ejemplo, Eclipse Temurin 21 de adoptium.net).
2. Descomprime este proyecto en una carpeta.
3. Abre una terminal en esa carpeta y ejecuta:
   - Windows: `gradlew.bat build`
   - Linux / macOS: `./gradlew build`
4. La primera vez descarga Gradle, NeoForge y Minecraft (tarda varios minutos).
5. El mod queda en `build/libs/megaciudad-1.0.0.jar`.

**Alternativa sin instalar nada (GitHub):**
1. Crea un repositorio nuevo y sube este zip **tal cual**, sin descomprimirlo (*Add file → Upload files*).
2. Crea el archivo `.github/workflows/build.yml` (*Add file → Create new file*) y pega el workflow
   que viene en este proyecto en `.github/workflows/build.yml`.
3. GitHub descomprime el zip y compila solo (tarda unos minutos). El .jar aparece en **Releases**
   (y también en *Actions* → la ejecución → *Artifacts*).

El mismo workflow funciona si subes el código ya descomprimido.

## 3. Instalar y jugar

1. Copia en la carpeta `mods` de tu instancia NeoForge 1.21.1:
   `megaciudad-1.0.0.jar`, el .jar de LittleTiles y el de CreativeCore.
2. **Crea un mundo nuevo** (tipo "Predeterminado" o "Biomas grandes"). La ciudad solo se genera en
   chunks nuevos, así que en un mundo ya explorado cerca de 0,0 quedaría cortada.
3. Apareces en la **plaza central** (junto a la fuente). La ciudad va de x −1008 a 992 y de
   z −1008 a 992. Alrededor, el terreno baja o sube suavemente hasta el relieve natural.

Consejos:
- Los rascacielos tienen escalera de caracol funcional en el núcleo (y salida a la azotea).
- Las vías del metro elevado son funcionales: pon una vagoneta en las vías desde un andén
  (las estaciones tienen escaleras que bajan al cantero central de la avenida).
- Las calles, interiores, parques, patios y azoteas tienen luz (bloques de luz invisibles y
  faroles) para que no aparezcan monstruos.
- No se generan aldeas ni otras estructuras dentro de la ciudad.

## 4. Configuración

Archivo `config/megaciudad-common.toml` (se crea al iniciar el juego):

| Opción | Por defecto | Qué hace |
|---|---|---|
| `enabled` | `true` | generar la ciudad |
| `centerX`, `centerZ` | `0` | centro de la ciudad |
| `spawnInPlaza` | `true` | aparecer en la plaza central al crear el mundo |
| `useLittleTiles` | `true` | usar mini-bloques de LittleTiles si está instalado |

## 5. Detalles técnicos

- La ciudad se genera en la etapa de decoración de cada chunk (mixin en
  `ChunkGenerator#applyBiomeDecoration`), con un generador determinista: cada chunk produce solo
  su parte de cada edificio, así que los edificios cruzan chunks sin cortes. Otro mixin en
  `ChunkGenerator#createStructures` evita estructuras vanilla dentro y alrededor de la ciudad.
- Los mini-bloques se escriben como entidades de bloque `littletiles:tiles` con el mismo formato
  NBT que guarda LittleTiles 1.6 (no hay dependencia de compilación con LittleTiles).
- El generador es Java puro (`com.megaciudad.core`); se probó generando los 15.625 chunks de la
  ciudad completa sin errores (≈ 0,4 ms por chunk fuera del juego).
- Si ves en el log `Bloque desconocido en la ciudad`, avísame: significa que un nombre de bloque no
  existe en tu versión.
