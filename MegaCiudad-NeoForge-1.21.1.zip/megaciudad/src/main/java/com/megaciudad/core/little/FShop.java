package com.megaciudad.core.little;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Comercios, gastronomía (con comida de Farmer's Delight, Extra Delight y Neapolitan) y ocio. */
public final class FShop {
    private FShop() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    // ------------------------------------------------------------------ alimentos

    public static final Model FREEZER = reg(row("freezer_horizontal", CHILLBOX, CHILLBOX));
    public static final Model DRINK_COOLER = reg(col("heladera_bebidas", FREEZER_D, FRIDGE_D));
    public static final Model BREAD_RACK = reg(row2("panera", n(2, foodDisplay("oak")),
            a(edFeast("cinnamon_rolls", "shepherds_pie_block"), edFeast("cornbread", "shepherds_pie_block"))));
    public static final Model CAKE_STAND = reg(one("tortera", npCake(1)));
    public static final Model ICE_CREAM_CASE = reg(row2("vitrina_helados", a(iceCream(0), iceCream(2)), n(2, v("glass"))));
    public static final Model PIZZA_OVEN = reg(row2("horno_pizza", a(OVEN, v("bricks")), a(v("bricks"), v("brick_stairs[facing=south]"))));
    public static final Model ESPRESSO = reg(col("cafetera_espresso", counter("brown"), BREWING));
    public static final Model MENU_BOARD = reg(m("menu", 2, 1, 1)
            .sign(0, 0, 0, wallSign("dark_oak"), "white", true, "MENÚ", "Pizza  $350", "Milanesa  $390", "Ensalada  $260")
            .sign(1, 0, 0, wallSign("dark_oak"), "white", true, "BEBIDAS", "Café  $95", "Jugo  $130", "Licuado  $150"));
    public static final Model REGISTER = reg(row2("caja_registradora", n(2, counter("white")), a(STOCK_TICKER, DESK_BELL)));
    public static final Model DELI_CASE = reg(row2("fiambreria", n(2, counter("light_gray")),
            a(feast("honey_glazed_ham_block"), edFeast("charcuterie_board", "roast_chicken_block"))));
    public static final Model SCALE = reg(one("balanza", DEPOT));
    public static final Model CANDY_BINS = reg(row2("golosinas", n(2, counter("pink")), a(CANDY_BOWL, chocoBox("red"))));
    public static final Model WINE_RACK = reg(col("vinoteca", BARREL_N, BARREL_N));
    public static final Model BASKETS = reg(one("canastos", BASKET));
    public static final Model SALAD_BAR = reg(row2("barra_ensaladas", n(3, counter("white")),
            a(feast("rice_roll_medley_block"), feast("gleaming_salad_block"), FRUIT_BOWL)));
    public static final Model PREP_TABLE = reg(row2("mesa_preparacion", n(2, counter("light_gray")), a(CUTTING, SLICER)));
    public static final Model IND_STOVE = reg(row2("cocina_industrial", n(2, FD_STOVE_LIT), a(POT, SKILLET)));
    public static final Model DOUBLE_SINK = reg(row("pileta_doble", ksink("light_gray"), ksink("light_gray")));
    public static final Model HOT_DOG = reg(one("carrito_panchos", grill("red")));
    public static final Model SLUSHIE = reg(one("licuados", milkshake(2)));
    public static final Model POPCORN = reg(col("pochoclera", counter("red"), v("glass")));

    // ------------------------------------------------------------------ tiendas

    public static final Model BOOK_TABLE = reg(row("mesa_libros", cloth("brown"), cloth("brown")));
    public static final Model MAGAZINE_STAND = reg(col("revistero", CHISELED, CHISELED));
    public static final Model SHOE_WALL = reg(m("pared_zapatos", 2, 2, 1).fill(0, 0, 0, 1, 1, 0, BARREL_N));
    public static final Model CLOTHES_TABLE = reg(row("mesa_ropa", cloth("blue"), cloth("red")));
    public static final Model FITTING_ROOM = reg(col("probador", v("red_wool"), v("red_wool")));
    public static final Model JEWEL_CASE = reg(row2("vitrina_joyas", n(2, counter("black")), a(coins("brass", 3), v("amethyst_cluster[facing=up]"))));
    public static final Model OPTICAL_STAND = reg(col("exhibidor_anteojos", cabinet("birch", "left"), MIRROR));
    public static final Model PHONE_TABLE = reg(row("mesa_celulares", cloth("black"), cloth("gray")));
    public static final Model TV_WALL = reg(row2("pared_televisores", drawerRow("dark_oak", 3), n(3, TV)));
    public static final Model TOY_SHELF = reg(row2("estante_juguetes", a(v("red_shulker_box[facing=up]"), v("yellow_shulker_box[facing=up]")),
            a(v("blue_shulker_box[facing=up]"), v("lime_shulker_box[facing=up]"))));
    public static final Model SPORTS_RACK = reg(row2("estante_deportes", n(2, v("target")), a(toolbox("orange"), toolbox("blue"))));
    public static final Model FLOWER_STAND = reg(row("puesto_flores", potted("red_tulip"), potted("dandelion")));
    public static final Model PLANT_SHELF = reg(row2("estante_plantas", n(2, hedge("azalea")), a(potted("fern"), potted("blue_orchid"))));
    public static final Model SALON_STATION = reg(col("tocador_peluqueria", kdrawer("white"), MIRROR));
    public static final Model BARBER_CHAIR = reg(one("silla_barbero", seat("red")));
    public static final Model HAIR_WASH = reg(one("lavacabezas", basin("black")));
    public static final Model PHARMA_SHELF = reg(row2("estante_farmacia", a(cabinet("birch", "left"), cabinet("birch", "right")), a(BREWING, BREWING)));
    public static final Model HARDWARE_WALL = reg(row2("pared_ferreteria", n(2, ANDESITE_CASING), a(toolbox("yellow"), toolbox("red"))));
    public static final Model PAINT_CANS = reg(one("latas_pintura", BASIN));
    public static final Model SECURITY_GATE = reg(col("antena_seguridad", v("iron_bars"), v("iron_bars")));
    public static final Model PROMO_SIGN = reg(m("cartel_oferta", 1, 1, 1).sign(0, 0, 0, v("oak_sign[rotation=8]"), "red", true, "", "¡OFERTA!", "2 x 1", ""));
    public static final Model PERFUMES = reg(col("perfumeria", counter("white"), BREWING));

    // ------------------------------------------------------------------ ocio

    public static final Model CINEMA_SEATS = reg(row("butacas_cine", sofaRow("red", 3)));
    public static final Model ARCADE = reg(col("arcade", v("black_concrete"), TV));
    public static final Model CLAW = reg(col("maquina_peluches", v("pink_concrete"), v("glass")));

    // ------------------------------------------------------------------ bar y restaurante

    public static final Model TABLE_TWO = reg(tableGrid("mesa_dos", "cherry", 2, 1).chairs(chairModel("cherry")));
    public static final Model BOOTH = reg(m("reservado", 2, 1, 2).b(0, 0, 1, sofaRow("red", 2)[0]).b(1, 0, 1, sofaRow("red", 2)[1])
            .b(0, 0, 0, table("spruce", false, true, false, false)).b(1, 0, 0, table("spruce", false, false, false, true)));
    public static final Model BAR_COUNTER = reg(m("barra", 3, 1, 2).fill(0, 0, 0, 2, 0, 0, counter("dark_oak")));
    public static final Model BAR_SHELF = reg(row2("estante_bar", n(2, kdrawer("dark_oak")), a(BREWING, BREWING)));
    public static final Model BEER_TAPS = reg(row("chopera", BARREL_N, BARREL_N));
    public static final Model BISTRO = reg(one("mesa_bistro", cloth("white")).chairs(chairModel("dark_oak")));
}
