package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

/**
 * Contenido de un bloque de LittleTiles en grilla 16: lista de "tiles", cada uno con su
 * material y sus cajas [x0,y0,z0,x1,y1,z1) en coordenadas 0..16.
 */
public final class LittleBlock {
    public static final int GRID = 16;
    public final Mat[] mats;
    public final int[][] boxes;
    public final int volume;
    /** Bloque vanilla aproximado si LittleTiles no está instalado (null = dejar vacío). */
    public final BlockRef fallback;

    public LittleBlock(Mat[] mats, int[][] boxes, int volume, BlockRef fallback) {
        this.mats = mats;
        this.boxes = boxes;
        this.volume = volume;
        this.fallback = fallback;
    }

    public int boxCount() {
        int n = 0;
        for (int[] b : boxes) n += b.length / 6;
        return n;
    }
}
