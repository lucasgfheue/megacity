package com.megaciudad.core;

import com.megaciudad.core.little.Model;

/**
 * Sistema de coordenadas local de un edificio. Local z=0 es el frente (la calle está hacia
 * el "norte" local), x crece de izquierda a derecha vista en planta. rot = giros horarios.
 */
public final class Frame {
    public final Canvas c;
    public final int rot, w, d;
    private final int ox, oz, ax, az, bx, bz;

    public Frame(Canvas c, int wx0, int wz0, int wx1, int wz1, int rot) {
        this.c = c;
        this.rot = rot & 3;
        int mnx = Math.min(wx0, wx1), mxx = Math.max(wx0, wx1), mnz = Math.min(wz0, wz1), mxz = Math.max(wz0, wz1);
        int sx = mxx - mnx + 1, sz = mxz - mnz + 1;
        switch (this.rot) {
            case 0 -> { ox = mnx; oz = mnz; ax = 1; az = 0; bx = 0; bz = 1; w = sx; d = sz; }
            case 1 -> { ox = mxx; oz = mnz; ax = 0; az = 1; bx = -1; bz = 0; w = sz; d = sx; }
            case 2 -> { ox = mxx; oz = mxz; ax = -1; az = 0; bx = 0; bz = -1; w = sx; d = sz; }
            default -> { ox = mnx; oz = mxz; ax = 0; az = -1; bx = 1; bz = 0; w = sz; d = sx; }
        }
    }

    public int wx(int lx, int lz) {
        return ox + ax * lx + bx * lz;
    }

    public int wz(int lx, int lz) {
        return oz + az * lx + bz * lz;
    }

    public boolean has(int lx, int lz) {
        return c.contains(wx(lx, lz), wz(lx, lz));
    }

    /** Coordenada local x de un punto de mundo. */
    public int lx(int wx, int wz) {
        return switch (rot) {
            case 0 -> wx - ox;
            case 1 -> wz - oz;
            case 2 -> ox - wx;
            default -> oz - wz;
        };
    }

    /** Coordenada local z de un punto de mundo. */
    public int lz(int wx, int wz) {
        return switch (rot) {
            case 0 -> wz - oz;
            case 1 -> ox - wx;
            case 2 -> oz - wz;
            default -> wx - ox;
        };
    }

    /** Rectángulo local {lx0, lz0, lx1, lz1} de la parte del lienzo dentro del marco (null si no hay). */
    public int[] localClip() {
        int ax = lx(c.x0, c.z0), az = lz(c.x0, c.z0), bx = lx(c.x1, c.z1), bz = lz(c.x1, c.z1);
        int x0 = Math.max(0, Math.min(ax, bx)), x1 = Math.min(w - 1, Math.max(ax, bx));
        int z0 = Math.max(0, Math.min(az, bz)), z1 = Math.min(d - 1, Math.max(az, bz));
        if (x0 > x1 || z0 > z1) return null;
        return new int[]{x0, z0, x1, z1};
    }

    public boolean visible(int lx0, int lz0, int lx1, int lz1) {
        return c.overlaps(wx(lx0, lz0), wz(lx0, lz0), wx(lx1, lz1), wz(lx1, lz1));
    }

    public boolean visible() {
        return visible(0, 0, w - 1, d - 1);
    }

    public void set(int lx, int y, int lz, BlockRef b) {
        c.set(wx(lx, lz), y, wz(lx, lz), b.rot(rot));
    }

    public void fill(int lx0, int y0, int lz0, int lx1, int y1, int lz1, BlockRef b) {
        c.fill(wx(lx0, lz0), y0, wz(lx0, lz0), wx(lx1, lz1), y1, wz(lx1, lz1), b.rot(rot));
    }

    /** Paredes huecas de un rectángulo (solo el perímetro). */
    public void ring(int lx0, int y0, int lz0, int lx1, int y1, int lz1, BlockRef b) {
        fill(lx0, y0, lz0, lx1, y1, lz0, b);
        fill(lx0, y0, lz1, lx1, y1, lz1, b);
        fill(lx0, y0, lz0, lx0, y1, lz1, b);
        fill(lx1, y0, lz0, lx1, y1, lz1, b);
    }

    /** Coloca un modelo LittleTiles. r = rotación local del modelo; (lx,lz) = esquina mínima local de su huella. */
    public void model(Model m, int r, int lx, int y, int lz) {
        r &= 3;
        int sx = (r & 1) == 0 ? m.sx : m.sz, sz = (r & 1) == 0 ? m.sz : m.sx;
        int ax0 = wx(lx, lz), az0 = wz(lx, lz), ax1 = wx(lx + sx - 1, lz + sz - 1), az1 = wz(lx + sx - 1, lz + sz - 1);
        c.model(m, r + rot, Math.min(ax0, ax1), y, Math.min(az0, az1));
    }

    public void sign(int lx, int y, int lz, BlockRef state, String[] lines, String color, boolean glow) {
        c.sign(wx(lx, lz), y, wz(lx, lz), state.rot(rot), lines, color, glow);
    }

    /** Sub-sistema local para un rectángulo local con rotación adicional r. */
    public Frame sub(int lx0, int lz0, int lx1, int lz1, int r) {
        return new Frame(c, wx(lx0, lz0), wz(lx0, lz0), wx(lx1, lz1), wz(lx1, lz1), rot + r);
    }

    /** Dirección local (north/east/south/west) convertida a la dirección de mundo. */
    public String dir(String local) {
        return BlockRef.rotDir(local, rot);
    }
}
