package com.megaciudad.mc;

import com.megaciudad.Config;
import com.megaciudad.MegaCiudad;
import com.megaciudad.core.little.LittleBlock;
import com.megaciudad.core.little.Mat;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.fml.ModList;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Escribe bloques de LittleTiles sin depender de su código: se coloca el bloque "littletiles:tiles"
 * y su entidad de bloque se carga desde NBT con el mismo formato que usa LittleTiles 1.6 al guardar
 * el mundo (BETiles: "content" -> "tiles" -> nombre de bloque -> [color], [caras, x0,y0,z0,x1,y1,z1]...).
 * La grilla por defecto (16) no se escribe.
 */
public final class LittleTilesBridge {
    private LittleTilesBridge() {
    }

    private static volatile int state = -1; // -1 sin inicializar, 0 no disponible, 1 disponible
    private static BlockState tiles;
    private static String beId;

    public static boolean available() {
        int s = state;
        if (s < 0) s = init();
        return s == 1;
    }

    private static synchronized int init() {
        if (state >= 0) return state;
        int result = 0;
        try {
            if (Config.USE_LITTLETILES.get() && ModList.get().isLoaded("littletiles")) {
                Block block = BuiltInRegistries.BLOCK.get(ResourceLocation.fromNamespaceAndPath("littletiles", "tiles"));
                if (block != null && block != Blocks.AIR) {
                    BlockState st = block.defaultBlockState();
                    BlockEntityType<?> type = BuiltInRegistries.BLOCK_ENTITY_TYPE.get(ResourceLocation.fromNamespaceAndPath("littletiles", "tiles"));
                    if (type == null || !type.isValid(st)) {
                        type = null;
                        for (BlockEntityType<?> t : BuiltInRegistries.BLOCK_ENTITY_TYPE) {
                            if (t.isValid(st)) {
                                type = t;
                                break;
                            }
                        }
                    }
                    if (type != null) {
                        ResourceLocation key = BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(type);
                        if (key != null) {
                            tiles = st;
                            beId = key.toString();
                            result = 1;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            MegaCiudad.LOGGER.error("No se pudo preparar la integración con LittleTiles", t);
            result = 0;
        }
        MegaCiudad.LOGGER.info(result == 1 ? "LittleTiles detectado: decoraciones con mini-bloques ({})"
                : "LittleTiles no disponible: decoraciones con bloques normales{}", result == 1 ? beId : "");
        state = result;
        return result;
    }

    public static BlockState tilesState() {
        return tiles;
    }

    public static CompoundTag nbt(int x, int y, int z, LittleBlock lb) {
        CompoundTag tag = new CompoundTag();
        tag.putString("id", beId);
        tag.putInt("x", x);
        tag.putInt("y", y);
        tag.putInt("z", z);
        Map<String, ListTag> byBlock = new LinkedHashMap<>();
        for (int t = 0; t < lb.mats.length; t++) {
            Mat m = lb.mats[t];
            ListTag list = byBlock.computeIfAbsent(m.block.spec, k -> new ListTag());
            list.add(new IntArrayTag(new int[]{m.color}));
            int[] b = lb.boxes[t];
            for (int i = 0; i + 5 < b.length; i += 6)
                list.add(new IntArrayTag(new int[]{0, b[i], b[i + 1], b[i + 2], b[i + 3], b[i + 4], b[i + 5]}));
        }
        CompoundTag tilesTag = new CompoundTag();
        for (Map.Entry<String, ListTag> e : byBlock.entrySet()) tilesTag.put(e.getKey(), e.getValue());
        CompoundTag content = new CompoundTag();
        content.put("tiles", tilesTag);
        tag.put("content", content);
        return tag;
    }
}
