package com.megaciudad.core.layout;

import com.megaciudad.core.Rng;

/** Geometría global de la ciudad: posición, manzanas, calles, distritos y nombres. */
public final class CityLayout {
    public static final AxisLayout A = new AxisLayout();
    public static final int SIZE = AxisLayout.SIZE;
    /** Bloque de la calzada (asfalto). La vereda es una losa encima; los lotes tienen suelo en GROUND. */
    public static final int ROAD_Y = 64, GROUND = 65, FLOOR = 66;
    public static final int BUFFER = 16, BLEND = 48;

    public static final int CORE = 0, MIDTOWN = 1, URBAN = 2, OUTER = 3;

    /** Línea de metro E-O sobre la avenida (calle Z índice 7) y N-S (calle X índice 17). */
    public static final int METRO_EW_ROAD = 7, METRO_NS_ROAD = 17;
    public static final int EW_DECK_Y = 75, NS_DECK_Y = 83;
    public static final int[] EW_STATIONS = {0, 3, 6, 10, 13, 17, 20, 23};
    public static final int[] NS_STATIONS = {0, 3, 7, 10, 14, 18, 20, 23};

    public final int minX, minZ;
    public final long seed;

    public CityLayout(int centerX, int centerZ, long seed) {
        this.minX = Math.floorDiv(centerX - SIZE / 2, 16) * 16;
        this.minZ = Math.floorDiv(centerZ - SIZE / 2, 16) * 16;
        this.seed = seed;
    }

    public int centerX() {
        return minX + SIZE / 2;
    }

    public int centerZ() {
        return minZ + SIZE / 2;
    }

    public boolean inCity(int x, int z) {
        return x >= minX && x < minX + SIZE && z >= minZ && z < minZ + SIZE;
    }

    /** Distancia (Chebyshev) desde la columna hasta el borde de la ciudad (0 dentro). */
    public int distOutside(int x, int z) {
        int dx = x < minX ? minX - x : x >= minX + SIZE ? x - (minX + SIZE - 1) : 0;
        int dz = z < minZ ? minZ - z : z >= minZ + SIZE ? z - (minZ + SIZE - 1) : 0;
        return Math.max(dx, dz);
    }

    public static final int CHUNK_NONE = 0, CHUNK_BLEND = 1, CHUNK_BUFFER = 2, CHUNK_URBAN = 3;

    public int chunkKind(int cx, int cz) {
        int x0 = cx * 16, z0 = cz * 16, x1 = x0 + 15, z1 = z0 + 15;
        if (x1 >= minX && x0 < minX + SIZE && z1 >= minZ && z0 < minZ + SIZE) return CHUNK_URBAN;
        int dx = x1 < minX ? minX - x1 : x0 >= minX + SIZE ? x0 - (minX + SIZE - 1) : 0;
        int dz = z1 < minZ ? minZ - z1 : z0 >= minZ + SIZE ? z0 - (minZ + SIZE - 1) : 0;
        int d = Math.max(dx, dz);
        if (d <= BUFFER) return CHUNK_BUFFER;
        if (d <= BLEND + 16) return CHUNK_BLEND;
        return CHUNK_NONE;
    }

    // ---------------------------------------------------------------- manzanas y calles

    public int lotX0(int i) { return minX + A.lotStart[i]; }
    public int lotX1(int i) { return minX + A.lotStart[i] + A.lotSize[i] - 1; }
    public int lotZ0(int j) { return minZ + A.lotStart[j]; }
    public int lotZ1(int j) { return minZ + A.lotStart[j] + A.lotSize[j] - 1; }
    public int roadX0(int k) { return minX + A.roadStart[k]; }
    public int roadZ0(int k) { return minZ + A.roadStart[k]; }
    public static int roadW(int k) { return A.roadWidth[k]; }

    /** Distrito de una manzana según la distancia al centro (con algo de variación). */
    public int district(int i, int j) {
        double cx = A.lotStart[i] + A.lotSize[i] / 2.0 - SIZE / 2.0;
        double cz = A.lotStart[j] + A.lotSize[j] / 2.0 - SIZE / 2.0;
        double r = Math.sqrt(cx * cx + cz * cz) + (Rng.unit(seed, 11, i, j) - 0.5) * 90;
        if (r < 270) return CORE;
        if (r < 480) return MIDTOWN;
        if (r < 760) return URBAN;
        return OUTER;
    }

    /** Zona industrial: sector este exterior. */
    public boolean industrial(int i, int j) {
        return i >= 20 && j >= 8 && j <= 16;
    }

    // ---------------------------------------------------------------- nombres

    private static final String[] NS_NAMES = {
            "Bv. Poniente", "Calle Sarandí", "Calle Las Acacias", "Av. del Libertador", "Calle Bolívar", "Calle San Martín",
            "Calle Las Heras", "Av. de los Pinos", "Calle Rivadavia", "Calle Belgrano", "Calle Mitre", "Calle Sucre",
            "Av. Central", "Calle Colón", "Calle Moreno", "Calle Alvear", "Calle Esmeralda", "Av. del Puerto",
            "Calle Florida", "Calle Laprida", "Calle Garibaldi", "Av. de Mayo", "Calle Lavalle", "Calle Pringles", "Bv. Oriente"};
    private static final String[] EW_NAMES = {
            "Bv. Norte", "Calle del Sol", "Calle Los Olivos", "Av. Libertad", "Calle Paraná", "Calle Uruguay",
            "Calle Córdoba", "Av. Metropolitana", "Calle Mendoza", "Calle Salta", "Calle Jujuy", "Calle Tucumán",
            "Av. Independencia", "Calle Santa Fe", "Calle Entre Ríos", "Calle Misiones", "Calle Corrientes", "Av. Universidad",
            "Calle La Rioja", "Calle Catamarca", "Calle Neuquén", "Av. del Parque", "Calle Chaco", "Calle Formosa", "Bv. Sur"};

    /** Nombre de la calle X índice k (corre de norte a sur). */
    public static String nsName(int k) {
        return NS_NAMES[k];
    }

    /** Nombre de la calle Z índice k (corre de este a oeste). */
    public static String ewName(int k) {
        return EW_NAMES[k];
    }

    public static boolean isStation(int[] list, int seg) {
        for (int s : list) if (s == seg) return true;
        return false;
    }
}
