package com.megaciudad.core.little;

import com.megaciudad.core.Rng;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.little.Kit.*;

/** Muebles y objetos de vivienda: living, decoración, cocina, comedor, dormitorio y baño. */
public final class FHome {
    private FHome() {
    }

    public static final List<Model> ALL = new ArrayList<>();

    private static Model reg(Model m) {
        ALL.add(m);
        return m;
    }

    // ================================================================== living

    public static final Model SOFA_L = reg(sofaL());

    private static Model sofaL() {
        Model m = new Model("sofa_esquinero", 3, 1, 2);
        Mat fab = w(0xA9ADB2), cush = w(0xC4C7CB), dark = c(0x2B2B2B);
        for (int[] p : new int[][]{{1, 17}, {45, 17}, {1, 29}, {45, 29}, {33, 2}, {45, 2}}) m.box(dark, p[0], 0, p[1], p[0] + 2, 2, p[1] + 2);
        m.box(fab, 0, 2, 16, 48, 7, 32);
        m.box(fab, 32, 2, 1, 48, 7, 16);
        m.box(fab, 0, 7, 28, 48, 16, 32);
        m.box(fab, 0, 7, 16, 3, 11, 28);
        m.box(fab, 45, 7, 1, 48, 11, 28);
        for (int x : new int[]{3, 17, 31}) m.box(cush, x, 7, 16, x + 14, 9, 28);
        m.box(cush, 32, 7, 2, 45, 9, 16);
        for (int x : new int[]{3, 17, 31}) cushion(m, cush, x, 9, 26, x + 14, 15, 28);
        cushion(m, w(0xD9A42B), 4, 9, 24, 10, 14, 26);
        cushion(m, w(0x2A7F86), 38, 9, 24, 44, 14, 26);
        cushion(m, w(0xE8E2D4), 30, 9, 24, 36, 13, 26);
        return m;
    }

    public static final Model SOFA_MOD = reg(sofaMod());

    private static Model sofaMod() {
        Model m = new Model("sofa_moderno", 2, 1, 1);
        Mat fab = w(0x2E6F73), dark = w(0x24585B);
        for (int x : new int[]{2, 29})
            for (int z : new int[]{3, 12}) m.box(WALNUT, x, 0, z, x + 1, 4, z + 1);
        m.box(WALNUT, 1, 4, 2, 31, 5, 15);
        m.box(fab, 1, 5, 2, 31, 9, 13);
        m.box(dark, 15, 8, 2, 17, 9, 13);
        m.box(fab, 1, 9, 12, 31, 16, 15);
        m.box(fab, 0, 5, 2, 2, 11, 15);
        m.box(fab, 30, 5, 2, 32, 11, 15);
        for (int x : new int[]{6, 12, 19, 25}) m.box(dark, x, 13, 11, x + 1, 14, 12);
        m.box(fab, 2, 9, 11, 30, 15, 12);
        cushion(m, w(0xE7B04A), 3, 9, 9, 9, 14, 11);
        return m;
    }

    public static final Model CHESTERFIELD = reg(chesterfield());

    private static Model chesterfield() {
        Model m = new Model("sofa_chester", 2, 1, 1);
        Mat lea = c(0x6B3A22), dark = c(0x4E2916);
        for (int x : new int[]{1, 29})
            for (int z : new int[]{1, 13}) m.box(GOLD, x, 0, z, x + 2, 2, z + 2);
        m.box(lea, 1, 2, 1, 31, 7, 15);
        m.box(lea, 4, 7, 1, 16, 9, 12);
        m.box(lea, 16, 7, 1, 28, 9, 12);
        m.box(dark, 15, 7, 1, 17, 9, 12);
        m.box(lea, 1, 7, 12, 31, 14, 15);
        for (int x = 4; x < 29; x += 4) m.box(dark, x, 11, 11, x + 1, 12, 12);
        m.box(lea, 4, 9, 11, 28, 13, 12);
        for (int x : new int[]{0, 28}) {
            m.box(lea, x, 2, 1, x + 4, 10, 15);
            m.cylZ(lea, x + 2, 10, 2.4, 1, 15);
        }
        return m;
    }

    public static final Model WINGBACK = reg(wingback());

    private static Model wingback() {
        Model m = new Model("sillon_orejero", 1, 1, 1);
        Mat fab = w(0x2F5D3A), light = w(0x3E7149);
        legs(m, WALNUT, 2, 2, 14, 14, 0, 3, 1);
        m.box(fab, 2, 3, 2, 14, 7, 14);
        m.box(light, 4, 7, 2, 12, 8, 12);
        m.box(fab, 2, 7, 12, 14, 16, 14);
        m.box(fab, 2, 7, 2, 4, 10, 12);
        m.box(fab, 12, 7, 2, 14, 10, 12);
        m.box(fab, 2, 10, 8, 4, 16, 12);
        m.box(fab, 12, 10, 8, 14, 16, 12);
        m.box(light, 5, 10, 11, 11, 15, 12);
        return m;
    }

    public static final Model RECLINER = reg(recliner());

    private static Model recliner() {
        Model m = new Model("sillon_reclinable", 1, 1, 1);
        Mat lea = c(0x4A2F21), seat = c(0x5C3A28);
        m.box(LEATHER_D, 2, 0, 5, 14, 1, 15);
        m.box(lea, 1, 1, 5, 15, 7, 15);
        m.box(seat, 3, 4, 0, 13, 6, 5);
        m.box(LEATHER_D, 7, 1, 2, 9, 4, 5);
        m.box(seat, 3, 7, 5, 13, 8, 12);
        m.box(lea, 2, 7, 11, 14, 10, 15);
        m.box(lea, 2, 10, 12, 14, 13, 16);
        m.box(lea, 3, 13, 13, 13, 16, 16);
        m.box(lea, 1, 7, 5, 3, 11, 15);
        m.box(lea, 13, 7, 5, 15, 11, 15);
        m.box(seat, 4, 10, 11, 12, 13, 12);
        return m;
    }

    public static final Model BEANBAG = reg(beanbag());

    private static Model beanbag() {
        Model m = new Model("puf_pera", 1, 1, 1);
        Mat fab = w(0xC0392B), d = w(0xA93226);
        m.box(fab, 2, 0, 2, 14, 5, 14);
        m.box(fab, 1, 1, 3, 15, 4, 13);
        m.box(fab, 3, 0, 1, 13, 4, 15);
        m.box(d, 4, 5, 3, 12, 6, 10);
        m.box(fab, 3, 5, 10, 13, 12, 14);
        m.box(fab, 4, 12, 11, 12, 13, 13);
        return m;
    }

    public static final Model OTTOMAN = reg(ottoman());

    private static Model ottoman() {
        Model m = new Model("puf", 1, 1, 1);
        Mat fab = w(0xD9A42B), dark = w(0xB8891F);
        m.cylY(WALNUT, 8, 8, 5.5, 0, 2);
        m.cylY(fab, 8, 8, 6, 2, 8);
        m.cylY(dark, 8, 8, 6.2, 4, 5);
        for (int[] p : new int[][]{{8, 8}, {5, 5}, {11, 5}, {5, 11}, {11, 11}}) m.box(dark, p[0], 7, p[1], p[0] + 1, 8, p[1] + 1);
        return m;
    }

    public static final Model COFFEE_WOOD = reg(coffeeWood());

    private static Model coffeeWood() {
        Model m = new Model("mesa_centro", 2, 1, 1);
        m.box(WALNUT, 1, 6, 3, 31, 7, 13);
        legs(m, WALNUT, 2, 4, 30, 12, 0, 6, 2);
        m.box(OAK, 3, 2, 5, 29, 3, 11);
        m.box(c(0xC0392B), 5, 3, 6, 12, 4, 10);
        m.box(c(0x2E86C1), 6, 4, 6, 12, 5, 9);
        m.box(c(0x6E2C00), 20, 7, 5, 26, 8, 11);
        m.box(c(0x1F618D), 20, 8, 5, 25, 9, 10);
        m.cylY(c(0xE8E2D4), 10, 8, 1.8, 7, 11);
        m.sphere(c(0xE74C3C), 10, 12, 8, 1.4);
        m.sphere(c(0xF4D03F), 9, 11, 7, 1.0);
        m.box(STEEL, 14, 7, 6, 18, 8, 10);
        return m;
    }

    public static final Model SIDE_LAMP = reg(sideLamp());

    private static Model sideLamp() {
        Model m = new Model("mesita_lampara", 1, 1, 1);
        m.cylY(WALNUT, 8, 8, 5.5, 8, 9);
        m.cylY(WALNUT, 8, 8, 1, 1, 8);
        m.cylY(WALNUT, 8, 8, 3.5, 0, 1);
        m.cylY(c(0x2C3E50), 8, 8, 1.6, 9, 11);
        m.cylY(STEEL, 8, 8, 0.5, 11, 13);
        m.cylY(WARM, 8, 8, 1.2, 12, 13);
        m.cylY(w(0xF2E8D0), 8, 8, 3.6, 13, 16);
        m.cylY(w(0xF2E8D0), 8, 8, 3.0, 12, 13);
        m.box(c(0x8E44AD), 3, 9, 10, 7, 10, 13);
        return m;
    }

    public static final Model FLOOR_LAMP = reg(floorLamp());

    private static Model floorLamp() {
        Model m = new Model("lampara_pie", 1, 2, 1);
        m.cylY(STEEL, 8, 8, 3.6, 0, 1);
        m.cylY(DARK, 8, 8, 0.8, 1, 24);
        m.cylY(WARM, 8, 8, 1.6, 23, 25);
        m.cylY(w(0xF2E8D0), 8, 8, 4.8, 24, 26);
        m.cylY(w(0xF2E8D0), 8, 8, 4.3, 26, 28);
        m.cylY(w(0xF2E8D0), 8, 8, 3.8, 28, 30);
        m.cut(6, 24, 6, 10, 25, 10);
        m.cylY(WARM, 8, 8, 1.6, 23, 25);
        return m;
    }

    public static final Model ARC_LAMP = reg(arcLamp());

    private static Model arcLamp() {
        Model m = new Model("lampara_arco", 2, 2, 1);
        m.box(MARBLE, 23, 0, 5, 30, 4, 12);
        m.box(STEEL, 26, 4, 8, 27, 24, 9);
        int[][] arc = {{25, 24, 26, 26}, {23, 26, 25, 27}, {20, 27, 23, 28}, {16, 28, 20, 29}, {12, 28, 16, 29}, {10, 27, 12, 28}};
        for (int[] a : arc) m.box(STEEL, a[0], a[1], 8, a[2], a[3], 9);
        m.ellipsoid(STEEL, 9, 25, 8.5, 4, 2.4, 4);
        m.cut(6, 22, 5, 13, 24, 13);
        m.cylY(WARM, 9, 8.5, 1.5, 23, 25);
        return m;
    }

    public static final Model TV_UNIT = reg(tvUnit());

    private static Model tvUnit() {
        Model m = new Model("mueble_tv", 3, 2, 1);
        m.box(WALNUT, 0, 0, 4, 48, 8, 15);
        for (int x : new int[]{1, 17, 33}) m.box(OAK, x, 1, 3, x + 14, 7, 4);
        for (int x : new int[]{7, 23, 39}) m.box(GOLD, x, 4, 2, x + 2, 5, 3);
        m.box(DARK, 22, 8, 10, 26, 9, 14);
        m.box(DARK, 23, 9, 12, 25, 12, 14);
        screen(m, 6, 12, 42, 30, 13, 2, c(0x173A5E));
        m.box(c(0x5DADE2), 8, 22, 13, 40, 29, 14);
        m.box(c(0x2E86C1), 8, 17, 13, 40, 22, 14);
        m.box(c(0x58D68D), 8, 13, 13, 40, 17, 14);
        m.box(c(0xF9E79F), 31, 24, 13, 34, 27, 14);
        m.box(BLACK, 15, 8, 6, 33, 10, 9);
        m.box(WHITE, 36, 8, 6, 42, 10, 12);
        m.box(LIGHT, 37, 9, 5, 38, 10, 6);
        m.box(c(0xE8E2D4), 2, 8, 7, 6, 12, 11);
        m.box(LEAF, 1, 12, 6, 7, 16, 12);
        return m;
    }

    public static final Model BOOKCASE = reg(bookcase(1, "biblioteca", WALNUT, 41));
    public static final Model BOOKCASE_WIDE = reg(bookcase(2, "biblioteca_doble", OAK, 77));

    private static Model bookcase(int sx, String name, Mat wood, long seed) {
        Model m = new Model(name, sx, 2, 1);
        int W = sx * 16;
        Rng r = new Rng(seed);
        m.box(wood, 0, 0, 3, 1, 32, 16);
        m.box(wood, W - 1, 0, 3, W, 32, 16);
        m.box(wood, 0, 31, 3, W, 32, 16);
        m.box(wood, 1, 0, 15, W - 1, 31, 16);
        if (sx == 2) m.box(wood, 15, 0, 3, 17, 31, 16);
        int[] shelves = sx == 2 ? new int[]{0, 10, 18, 25} : new int[]{0, 8, 16, 24};
        for (int s : shelves) m.box(wood, 1, s, 3, W - 1, s + 1, 16);
        if (sx == 2) {
            m.box(wood, 1, 1, 3, W - 1, 10, 4);
            m.box(wood.equals(OAK) ? WALNUT : OAK, 2, 2, 2, 15, 9, 3);
            m.box(wood.equals(OAK) ? WALNUT : OAK, 17, 2, 2, 30, 9, 3);
            m.box(GOLD, 13, 5, 1, 14, 6, 2);
            m.box(GOLD, 18, 5, 1, 19, 6, 2);
        }
        for (int i = 0; i < shelves.length; i++) {
            int s = shelves[i];
            if (sx == 2 && i == 0) continue;
            int top = i + 1 < shelves.length ? shelves[i + 1] : 31;
            int hMax = Math.min(7, top - s - 2);
            if (sx == 1) {
                books(m, r, 1, 15, s + 1, 5, 15, Math.max(3, hMax - 2), hMax);
            } else {
                books(m, r, 1, 15, s + 1, 5, 15, Math.max(3, hMax - 2), hMax);
                if (i == 2) {
                    books(m, r, 17, 24, s + 1, 5, 15, Math.max(3, hMax - 2), hMax);
                    pot(m, c(0xE8E2D4), 27.5, 10, 2, s + 1, 3);
                    m.sphere(LEAF, 27.5, s + 6, 10, 2.4);
                } else books(m, r, 17, W - 1, s + 1, 5, 15, Math.max(3, hMax - 2), hMax);
            }
        }
        if (sx == 1) {
            m.cut(9, 25, 4, 15, 31, 15);
            m.cylY(c(0x1F618D), 12, 9, 1.6, 25, 30);
        }
        return m;
    }

    public static final Model CUBE_SHELF = reg(cubeShelf());

    private static Model cubeShelf() {
        Model m = new Model("estanteria_cubos", 2, 2, 1);
        Rng r = new Rng(9);
        m.box(WHITE, 0, 0, 4, 32, 32, 16);
        int[] xs = {1, 9, 17, 25}, ys = {1, 9, 17, 25};
        for (int ix = 0; ix < 4; ix++)
            for (int iy = 0; iy < 4; iy++) {
                int x = xs[ix], y = ys[iy];
                m.cut(x, y, 4, x + 6, y + 7, 15);
                int k = (ix * 7 + iy * 3) % 5;
                switch (k) {
                    case 0 -> m.box(w(new int[]{0x9E9E9E, 0xD7C4A3, 0x5D6D7E}[r.nextInt(3)]), x, y, 5, x + 6, y + 6, 15);
                    case 1 -> books(m, r, x, x + 6, y, 6, 15, 4, 6);
                    case 2 -> {
                        pot(m, c(0xF5F5F5), x + 3, 10, 1.8, y, 3);
                        m.sphere(LEAF, x + 3, y + 5, 10, 2.2);
                    }
                    case 3 -> {
                        m.box(c(0x2E4053), x + 1, y, 8, x + 5, y + 1, 13);
                        m.box(c(0xF4D03F), x + 2, y + 1, 9, x + 4, y + 4, 12);
                    }
                    default -> {
                    }
                }
            }
        return m;
    }

    public static final Model FIREPLACE = reg(fireplace());

    private static Model fireplace() {
        Model m = new Model("chimenea", 2, 2, 1);
        Mat st = Mat.of("stone_bricks"), cap = QUARTZ;
        m.box(STONE, 0, 0, 2, 32, 2, 16);
        m.box(st, 1, 2, 8, 31, 26, 16);
        m.cut(8, 2, 8, 24, 16, 14);
        m.box(BLACK, 8, 2, 14, 24, 16, 15);
        m.box(BLACK, 8, 15, 9, 24, 16, 14);
        m.cylX(c(0x5A3A1E), 3.5, 11, 1.6, 10, 22);
        m.cylX(c(0x6E4626), 3.5, 13, 1.5, 11, 21);
        m.ellipsoid(FIRE, 16, 7, 11.5, 5, 3.5, 2);
        m.ellipsoid(WARM, 15, 9, 11.5, 2.5, 3, 1.2);
        m.ellipsoid(FIRE, 19, 8, 11.5, 1.5, 2.5, 1.2);
        m.box(DARK, 8, 2, 8, 24, 3, 9);
        m.box(cap, 0, 26, 6, 32, 28, 16);
        m.box(BRICK, 4, 28, 12, 28, 32, 16);
        m.cylY(WHITE, 5, 9, 1, 28, 31);
        m.box(WARM, 5, 31, 9, 6, 32, 10);
        m.cylY(WHITE, 27, 9, 1, 28, 30);
        m.box(WARM, 27, 30, 9, 28, 31, 10);
        m.box(GOLD, 13, 28, 9, 19, 32, 11);
        m.box(WHITE, 14, 29, 8, 18, 31, 9);
        return m;
    }

    public static final Model PIANO = reg(piano());

    private static Model piano() {
        Model m = new Model("piano", 2, 2, 1);
        m.box(BLACK, 1, 0, 8, 31, 24, 16);
        m.box(BLACK, 0, 24, 7, 32, 25, 16);
        m.box(BLACK, 1, 10, 3, 31, 12, 8);
        m.box(WHITE, 2, 12, 3, 30, 13, 7);
        for (int x = 2; x < 30; x++) {
            int k = (x - 2) % 7;
            if (k == 0 || k == 1 || k == 3 || k == 4 || k == 5) m.box(BLACK, x, 13, 5, x + 1, 14, 7);
        }
        m.box(BLACK, 2, 0, 3, 4, 10, 5);
        m.box(BLACK, 28, 0, 3, 30, 10, 5);
        m.box(BLACK, 1, 13, 6, 31, 17, 8);
        m.box(WHITE, 11, 17, 7, 21, 22, 8);
        m.box(c(0x333333), 12, 19, 6, 20, 20, 7);
        m.box(GOLD, 3, 1, 7, 6, 2, 8);
        m.box(GOLD, 26, 1, 7, 29, 2, 8);
        m.box(GOLD, 4, 25, 11, 8, 30, 12);
        m.box(c(0xF2E8D0), 5, 26, 10, 7, 29, 11);
        m.cylY(WHITE, 26, 11, 1, 25, 29);
        m.box(WARM, 26, 29, 11, 27, 30, 12);
        return m;
    }

    public static final Model GRAND_PIANO = reg(grandPiano());

    private static Model grandPiano() {
        Model m = new Model("piano_cola", 2, 1, 2);
        for (int z = 4; z < 30; z++) {
            double t = (z - 4) / 26.0;
            int xr = 30 - (int) Math.round(t < 0.4 ? 0 : 14 * Math.pow((t - 0.4) / 0.6, 1.4));
            m.box(BLACK, 2, 8, z, xr, 14, z + 1);
        }
        m.box(BLACK, 3, 0, 5, 5, 8, 7);
        m.box(BLACK, 27, 0, 5, 29, 8, 7);
        m.box(BLACK, 6, 0, 25, 8, 8, 27);
        m.box(BLACK, 2, 9, 0, 30, 11, 4);
        m.box(WHITE, 3, 11, 0, 29, 12, 3);
        for (int x = 3; x < 29; x++) {
            int k = (x - 3) % 7;
            if (k == 0 || k == 1 || k == 3 || k == 4 || k == 5) m.box(BLACK, x, 12, 1, x + 1, 13, 3);
        }
        m.box(BLACK, 2, 12, 3, 30, 15, 5);
        for (int i = 0; i < 13; i++) {
            int y = 15 + i;
            m.box(BLACK, 4 + i * 2, y, 6, 6 + i * 2, y + 1, 26 - i);
        }
        m.box(GOLD, 3, 14, 10, 4, 15, 26);
        m.box(STEEL, 27, 14, 14, 28, 26, 15);
        m.box(c(0xE5E5E5), 10, 15, 4, 22, 16, 5);
        return m;
    }

    public static final Model AQUARIUM = reg(aquarium());

    private static Model aquarium() {
        Model m = new Model("pecera", 2, 2, 1);
        m.box(WALNUT, 0, 0, 3, 32, 12, 15);
        m.box(OAK, 1, 1, 2, 15, 11, 3);
        m.box(OAK, 17, 1, 2, 31, 11, 3);
        m.box(GOLD, 13, 6, 1, 14, 7, 2);
        m.box(GOLD, 18, 6, 1, 19, 7, 2);
        m.box(GLASS, 0, 12, 3, 32, 28, 15);
        m.box(WATER, 1, 13, 4, 31, 26, 14);
        m.box(c(0xD8C08A), 1, 13, 4, 31, 14, 14);
        for (int x : new int[]{4, 9, 25, 28}) m.box(GREEN, x, 14, 9, x + 1, 14 + 4 + x % 5, 10);
        m.box(c(0x7F8C8D), 13, 14, 7, 19, 17, 12);
        int[][] fish = {{8, 20, 6, 0xF39C12}, {20, 22, 9, 0xE74C3C}, {14, 18, 10, 0xF1C40F}, {24, 17, 6, 0x3498DB}, {5, 23, 11, 0xE67E22}};
        for (int[] f : fish) {
            m.box(c(f[3]), f[0], f[1], f[2], f[0] + 3, f[1] + 2, f[2] + 1);
            m.box(c(f[3]), f[0] + 3, f[1], f[2], f[0] + 4, f[1] + 2, f[2] + 1);
        }
        m.box(BLACK, 0, 28, 3, 32, 30, 15);
        m.box(LIGHT, 2, 27, 5, 30, 28, 13);
        return m;
    }

    public static final Model GUITAR = reg(guitar());

    private static Model guitar() {
        Model m = new Model("guitarra", 1, 1, 1);
        Mat body = c(0xB5651D);
        m.box(BLACK, 5, 0, 7, 6, 4, 8);
        m.box(BLACK, 10, 0, 7, 11, 4, 8);
        m.box(BLACK, 5, 0, 10, 11, 1, 11);
        m.box(BLACK, 7, 2, 10, 9, 11, 11);
        m.ellipsoid(body, 8, 5, 8.5, 4.5, 3.8, 1.5);
        m.ellipsoid(body, 8, 9.5, 8.5, 3.4, 2.8, 1.5);
        m.cylZ(BLACK, 8, 8, 1.2, 7, 8);
        m.box(WALNUT, 7, 3, 7, 9, 4, 8);
        m.box(WALNUT, 7, 11, 8, 9, 15, 9);
        m.box(BLACK, 6, 15, 8, 10, 16, 9);
        return m;
    }

    public static final Model RECORD_PLAYER = reg(recordPlayer());

    private static Model recordPlayer() {
        Model m = new Model("tocadiscos", 1, 1, 1);
        m.box(WALNUT, 1, 0, 3, 15, 9, 15);
        m.cut(2, 1, 3, 14, 8, 13);
        for (int x = 2; x < 14; x += 2) m.box(c(VIVID[x % VIVID.length]), x, 1, 4, x + 1, 8, 13);
        m.box(c(0x3B2A20), 1, 9, 3, 15, 10, 15);
        m.cylY(BLACK, 7, 9, 4.5, 10, 11);
        m.cylY(RED, 7, 9, 1.2, 10, 12);
        m.box(STEEL, 12, 10, 5, 13, 12, 6);
        m.box(STEEL, 10, 11, 5, 12, 12, 10);
        return m;
    }

    public static final Model SPEAKER = reg(speaker());

    private static Model speaker() {
        Model m = new Model("parlante", 1, 2, 1);
        m.box(BLACK, 3, 0, 4, 13, 30, 13);
        m.cylZ(c(0x2C2C2C), 8, 11, 3.8, 3, 4);
        m.cylZ(GRAY, 8, 11, 1.4, 2, 3);
        m.cylZ(c(0x2C2C2C), 8, 20, 3, 3, 4);
        m.cylZ(GRAY, 8, 20, 1.1, 2, 3);
        m.cylZ(STEEL, 8, 26.5, 1.3, 3, 4);
        m.box(c(0x1A1A1A), 3, 0, 3, 13, 1, 4);
        return m;
    }

    public static final Model RUG_ROUND = reg(rugRound());

    private static Model rugRound() {
        Model m = new Model("alfombra_redonda", 2, 1, 2);
        int[] col = {0xA0442C, 0xE8DCC2, 0x2E4A7A, 0xE8DCC2, 0xA0442C};
        int[] rad = {15, 12, 9, 5, 2};
        for (int i = 0; i < rad.length; i++) {
            int rr = rad[i], k = (int) Math.round(rr * 0.42);
            Mat mt = w(col[i]);
            m.box(mt, 16 - rr + k, 0, 16 - rr, 16 + rr - k, 1, 16 + rr);
            m.box(mt, 16 - rr, 0, 16 - rr + k, 16 + rr, 1, 16 + rr - k);
            m.box(mt, 16 - rr + k / 2, 0, 16 - rr + k / 2, 16 + rr - k / 2, 1, 16 + rr - k / 2);
        }
        return m;
    }

    public static final Model RUG_RECT = reg(rugRect());

    private static Model rugRect() {
        Model m = new Model("alfombra", 3, 1, 2);
        m.box(w(0x7B241C), 1, 0, 2, 47, 1, 30);
        m.box(w(0xE6D5B8), 3, 0, 4, 45, 1, 28);
        m.box(w(0x7B241C), 5, 0, 6, 43, 1, 26);
        m.box(w(0xD9C9A3), 6, 0, 7, 42, 1, 25);
        for (int dz = -6; dz <= 6; dz += 2) {
            int hw = 12 - Math.abs(dz) * 12 / 7;
            m.box(w(0x1F3A5F), 24 - hw, 0, 16 + dz, 24 + hw, 1, 18 + dz);
        }
        m.box(w(0xD9A42B), 22, 0, 14, 26, 1, 19);
        m.box(w(0xF2E8D0), 1, 0, 1, 47, 1, 2);
        m.box(w(0xF2E8D0), 1, 0, 30, 47, 1, 31);
        return m;
    }

    // ================================================================== decoración

    public static final Model PAINT_LAND = reg(paintLand());

    private static Model paintLand() {
        Model m = new Model("cuadro_paisaje", 2, 1, 1);
        m.box(GOLD, 2, 3, 14, 30, 15, 16);
        m.box(c(0x87CEEB), 3, 9, 13, 29, 14, 14);
        m.box(c(0xB0DDF0), 3, 12, 13, 29, 14, 14);
        for (int x = 3; x < 29; x++) {
            int h = 9 + (int) Math.round(3.5 * Math.max(0, 1 - Math.abs(x - 11) / 7.0)) + (int) Math.round(2.5 * Math.max(0, 1 - Math.abs(x - 22) / 6.0));
            m.box(c(0x7B8794), x, 8, 13, x + 1, Math.min(14, h), 14);
            if (h >= 12) m.box(WHITE, x, h - 1, 13, x + 1, Math.min(14, h), 14);
        }
        m.box(c(0x6AA84F), 3, 4, 13, 29, 8, 14);
        m.box(c(0x4E8C3A), 3, 4, 13, 29, 5, 14);
        m.box(c(0x3D85C6), 15, 4, 13, 21, 6, 14);
        m.box(c(0xF7DC6F), 25, 11, 13, 27, 13, 14);
        return m;
    }

    public static final Model PAINT_ABS = reg(paintAbstract());

    private static Model paintAbstract() {
        Model m = new Model("cuadro_abstracto", 1, 1, 1);
        m.box(BLACK, 2, 2, 14, 14, 15, 16);
        m.box(WHITE, 3, 3, 13, 13, 14, 14);
        m.box(RED, 6, 9, 13, 13, 14, 14);
        m.box(BLUE, 3, 3, 13, 6, 7, 14);
        m.box(YELLOW, 10, 3, 13, 13, 5, 14);
        m.box(BLACK, 3, 8, 13, 13, 9, 14);
        m.box(BLACK, 5, 3, 13, 6, 14, 14);
        m.box(BLACK, 9, 3, 13, 10, 8, 14);
        return m;
    }

    public static final Model PAINT_FLOWERS = reg(paintFlowers());

    private static Model paintFlowers() {
        Model m = new Model("cuadro_flores", 1, 1, 1);
        m.box(WALNUT, 3, 1, 14, 13, 15, 16);
        m.box(c(0xF2E8D0), 4, 2, 13, 12, 14, 14);
        m.box(c(0x2E4A7A), 6, 3, 13, 10, 7, 14);
        m.box(c(0x2E4A7A), 7, 7, 13, 9, 8, 14);
        m.box(c(0x4E8C3A), 7, 8, 13, 9, 10, 14);
        int[][] fl = {{5, 11, 0xE74C3C}, {7, 12, 0xF4D03F}, {10, 11, 0xEC7063}, {9, 13, 0xFFFFFF}, {6, 9, 0xE74C3C}};
        for (int[] f : fl) m.box(c(f[2]), f[0], f[1], 13, f[0] + 2, f[1] + 1, 14);
        return m;
    }

    public static final Model MIRROR_ROUND = reg(mirrorRound());

    private static Model mirrorRound() {
        Model m = new Model("espejo_redondo", 1, 1, 1);
        m.cylZ(GOLD, 8, 8.5, 6.5, 14, 16);
        m.cylZ(c(0xCFE3EA), 8, 8.5, 5.4, 13, 14);
        m.box(c(0xE8F4F8), 5, 9, 13, 6, 12, 14);
        return m;
    }

    public static final Model WALL_CLOCK = reg(wallClock());

    private static Model wallClock() {
        Model m = new Model("reloj_pared", 1, 1, 1);
        m.cylZ(BLACK, 8, 8, 6, 14, 16);
        m.cylZ(WHITE, 8, 8, 5.2, 13, 14);
        for (int[] p : new int[][]{{8, 12}, {12, 8}, {8, 4}, {4, 8}}) m.box(BLACK, p[0], p[1], 12, p[0] + 1, p[1] + 1, 13);
        m.box(BLACK, 8, 8, 12, 9, 12, 13);
        m.box(BLACK, 8, 8, 12, 11, 9, 13);
        m.box(RED, 8, 8, 11, 9, 9, 12);
        return m;
    }

    public static final Model WALL_SHELF = reg(wallShelf());

    private static Model wallShelf() {
        Model m = new Model("repisa", 2, 1, 1);
        Rng r = new Rng(5);
        m.box(WALNUT, 2, 3, 10, 30, 4, 16);
        m.box(WALNUT, 2, 10, 10, 30, 11, 16);
        books(m, r, 4, 13, 4, 11, 16, 4, 5);
        pot(m, c(0xE8E2D4), 20, 13, 1.8, 4, 3);
        m.sphere(LEAF, 20, 8.5, 13, 2);
        m.box(BLACK, 25, 4, 14, 29, 9, 15);
        m.box(c(0x85C1E9), 26, 5, 13, 28, 8, 14);
        m.cylY(WHITE, 8, 13, 1.2, 11, 14);
        m.box(WARM, 8, 14, 13, 9, 15, 14);
        books(m, r, 14, 26, 11, 11, 16, 3, 5);
        return m;
    }

    public static final Model PENDANT = reg(pendant());

    private static Model pendant() {
        Model m = new Model("lampara_colgante", 1, 1, 1);
        m.box(BLACK, 7, 10, 7, 9, 16, 9);
        m.box(COPPER, 6, 9, 6, 10, 10, 10);
        m.box(COPPER, 4, 7, 4, 12, 9, 12);
        m.box(COPPER, 3, 5, 3, 13, 7, 13);
        m.cut(4, 5, 4, 12, 7, 12);
        m.box(WARM, 6, 5, 6, 10, 7, 10);
        return m;
    }

    public static final Model CHANDELIER = reg(chandelier());

    private static Model chandelier() {
        Model m = new Model("arana", 1, 1, 1);
        m.box(GOLD, 7, 8, 7, 9, 16, 9);
        m.sphere(GOLD, 8, 7, 8, 1.8);
        m.box(GOLD, 2, 5, 2, 14, 6, 14);
        m.cut(3, 5, 3, 13, 6, 13);
        m.box(GOLD, 2, 6, 7, 14, 7, 9);
        m.box(GOLD, 7, 6, 2, 9, 7, 14);
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3;
            int x = (int) Math.round(8 + Math.cos(a) * 5.4) - 1, z = (int) Math.round(8 + Math.sin(a) * 5.4) - 1;
            m.box(WHITE, x, 6, z, x + 1, 9, z + 1);
            m.box(WARM, x, 9, z, x + 1, 10, z + 1);
            m.box(GLASS_W, x, 3, z, x + 1, 5, z + 1);
        }
        m.box(GLASS_W, 7, 3, 7, 9, 5, 9);
        return m;
    }

    public static final Model CEILING_FAN = reg(ceilingFan());

    private static Model ceilingFan() {
        Model m = new Model("ventilador_techo", 2, 1, 2);
        m.box(DARK, 15, 10, 15, 17, 16, 17);
        m.cylY(COPPER, 16, 16, 3, 7, 10);
        m.cylY(PEARL, 16, 16, 2.2, 5, 7);
        m.box(WALNUT, 19, 8, 14, 31, 9, 18);
        m.box(WALNUT, 1, 8, 14, 13, 9, 18);
        m.box(WALNUT, 14, 8, 19, 18, 9, 31);
        m.box(WALNUT, 14, 8, 1, 18, 9, 13);
        return m;
    }

    public static final Model VASE_FLOWERS = reg(vaseFlowers());

    private static Model vaseFlowers() {
        Model m = new Model("jarron_flores", 1, 1, 1);
        m.cylY(c(0x2E4A7A), 8, 8, 3, 0, 8);
        m.cylY(c(0x2E4A7A), 8, 8, 2.2, 8, 10);
        m.cylY(c(0x2E4A7A), 8, 8, 2.6, 10, 11);
        m.box(LEAF2, 7, 11, 7, 9, 13, 9);
        int[][] fl = {{8, 14, 8, 0xE74C3C}, {5, 13, 7, 0xF4D03F}, {11, 13, 9, 0xFFFFFF}, {7, 15, 10, 0xEC7063}, {10, 15, 6, 0xAF7AC5}};
        for (int[] f : fl) m.sphere(c(f[3]), f[0], f[1], f[2], 1.5);
        return m;
    }

    public static final Model MONSTERA = reg(monstera());

    private static Model monstera() {
        Model m = new Model("monstera", 1, 2, 1);
        pot(m, c(0xF5F5F5), 8, 8, 5, 0, 8);
        m.box(c(0xBDBDBD), 3, 7, 3, 13, 8, 4);
        Mat a = c(0x2E7D32), b = c(0x1B5E20);
        m.box(a, 7, 8, 7, 9, 14, 9);
        double[][] lv = {{4, 16, 6, 4, 1.2, 3}, {12, 19, 9, 4, 1.2, 3.2}, {7, 23, 11, 3.6, 1.1, 3}, {10, 26, 5, 3.4, 1, 2.8}, {5, 21, 4, 3, 1, 2.6}};
        for (int i = 0; i < lv.length; i++) {
            double[] l = lv[i];
            m.ellipsoid(i % 2 == 0 ? a : b, l[0], l[1], l[2], l[3], l[4], l[5]);
            m.box(b, 8, (int) l[1] - 3, 8, 9, (int) l[1], 9);
        }
        return m;
    }

    public static final Model CACTUS = reg(cactus());

    private static Model cactus() {
        Model m = new Model("cactus", 1, 1, 1);
        pot(m, POT, 8, 8, 4, 0, 6);
        Mat g = c(0x4A7A2E);
        m.cylY(g, 8, 8, 2.4, 6, 15);
        m.sphere(g, 8, 15, 8, 2.3);
        m.cylY(g, 11.5, 8, 1.3, 9, 13);
        m.box(g, 10, 9, 7, 12, 10, 9);
        m.cylY(g, 4.5, 8, 1.2, 10, 14);
        m.box(g, 5, 10, 7, 7, 11, 9);
                m.box(c(0xF48FB1), 7, 15, 7, 9, 16, 9);
        return m;
    }

    public static final Model PALM = reg(palm());

    private static Model palm() {
        Model m = new Model("palmera_interior", 1, 2, 1);
        Mat basket = c(0xC8A165);
        m.cylY(basket, 8, 8, 5, 0, 7);
        for (int y = 1; y < 7; y += 2) m.cylY(c(0xA8844A), 8, 8, 5.1, y, y + 1);
        m.cylY(SOIL, 8, 8, 4, 6, 7);
        Mat stem = c(0x7D6B3A), fr = c(0x3B8A3B), fr2 = c(0x2F6E2F);
        for (int[] s : new int[][]{{7, 7, 18}, {9, 8, 22}, {8, 10, 16}}) m.box(stem, s[0], 7, s[1], s[0] + 1, s[2], s[1] + 1);
        int[][] fronds = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int k = 0; k < 4; k++) {
            int dx = fronds[k][0], dz = fronds[k][1], y = 24 + (k % 2) * 2;
            for (int i = 0; i < 3; i++) {
                int x0 = 8 + dx * (1 + i * 2), z0 = 8 + dz * (1 + i * 2);
                m.box(i % 2 == 0 ? fr : fr2, Math.min(x0, x0 + dx * 2) - (dz != 0 ? 1 : 0), y - i, Math.min(z0, z0 + dz * 2) - (dx != 0 ? 1 : 0),
                        Math.max(x0, x0 + dx * 2) + (dz != 0 ? 1 : 0) + (dx == 0 ? 1 : 0), y - i + 1, Math.max(z0, z0 + dz * 2) + (dx != 0 ? 1 : 0) + (dz == 0 ? 1 : 0));
            }
        }
        m.box(fr, 6, 26, 6, 10, 28, 10);
        return m;
    }

    public static final Model SNAKE_PLANT = reg(snakePlant());

    private static Model snakePlant() {
        Model m = new Model("sansevieria", 1, 1, 1);
        pot(m, c(0x5D6D7E), 8, 8, 4, 0, 6);
        int[][] lv = {{6, 7, 15}, {8, 6, 14}, {9, 9, 16}, {7, 10, 13}, {10, 7, 12}, {5, 9, 12}};
        for (int[] l : lv) {
            m.box(c(0x2E6B30), l[0], 6, l[1], l[0] + 1, l[2], l[1] + 1);
            m.box(c(0xC9C95A), l[0], l[2] - 2, l[1], l[0] + 1, l[2], l[1] + 1);
        }
        return m;
    }

    public static final Model BONSAI = reg(bonsai());

    private static Model bonsai() {
        Model m = new Model("bonsai", 1, 1, 1);
        m.box(WALNUT, 2, 0, 3, 14, 5, 13);
        m.cut(3, 0, 4, 13, 4, 12);
        m.box(c(0x2E4A7A), 4, 5, 5, 12, 8, 11);
        m.box(SOIL, 5, 7, 6, 11, 8, 10);
        Mat tr = c(0x5B3A29);
        m.box(tr, 7, 8, 7, 9, 10, 9);
        m.box(tr, 6, 10, 7, 8, 12, 9);
        m.box(tr, 8, 11, 7, 10, 13, 9);
        m.ellipsoid(LEAF, 5, 12.5, 8, 2.6, 1.2, 2.2);
        m.ellipsoid(LEAF, 10.5, 14, 8, 2.8, 1.3, 2.4);
        m.ellipsoid(LEAF2, 8, 15, 8, 2, 1, 2);
        return m;
    }

    public static final Model HANGING_PLANT = reg(hangingPlant());

    private static Model hangingPlant() {
        Model m = new Model("planta_colgante", 1, 1, 1);
        for (int[] p : new int[][]{{5, 8}, {11, 8}, {8, 11}}) m.box(c(0xE8DCC2), p[0], 9, p[1], p[0] + 1, 16, p[1] + 1);
        m.cylY(c(0xF5F5F5), 8, 8, 3.5, 5, 9);
        m.cylY(LEAF, 8, 8, 3, 9, 10);
        int[][] tr = {{4, 7, 0}, {12, 9, 1}, {7, 12, 3}, {9, 4, 2}, {5, 11, 1}, {11, 5, 0}};
        for (int[] t : tr) m.box(t[2] % 2 == 0 ? LEAF : LEAF2, t[0], t[2], t[1], t[0] + 1, 9, t[1] + 1);
        return m;
    }

    public static final Model FICUS = reg(ficus());

    private static Model ficus() {
        Model m = new Model("ficus", 1, 2, 1);
        pot(m, c(0x37474F), 8, 8, 5, 0, 9);
        Mat tr = c(0x6D4C41);
        m.cylY(tr, 8, 8, 1, 9, 20);
        m.box(tr, 8, 16, 8, 11, 17, 9);
        m.box(tr, 5, 18, 7, 8, 19, 8);
        m.box(LEAF, 3, 20, 3, 13, 28, 13);
        m.box(LEAF2, 4, 28, 4, 12, 31, 12);
        m.box(LEAF2, 2, 22, 5, 3, 27, 11);
        m.box(LEAF2, 13, 22, 5, 14, 27, 11);
        m.box(LEAF2, 5, 22, 2, 11, 27, 3);
        m.box(LEAF2, 5, 22, 13, 11, 27, 14);
        m.box(LEAF, 5, 18, 5, 11, 20, 11);
        return m;
    }

    public static final Model COAT_RACK = reg(coatRack());

    private static Model coatRack() {
        Model m = new Model("perchero_pie", 1, 2, 1);
        m.box(WALNUT, 3, 0, 7, 13, 1, 9);
        m.box(WALNUT, 7, 0, 3, 9, 1, 13);
        m.cylY(WALNUT, 8, 8, 1, 1, 29);
        m.box(WALNUT, 5, 26, 7, 11, 27, 9);
        m.box(WALNUT, 7, 26, 5, 9, 27, 11);
        m.box(c(0xC8A97E), 3, 13, 6, 7, 26, 10);
        m.box(c(0xB0926A), 3, 18, 5, 7, 26, 6);
        m.cylY(BLACK, 8, 8, 3.5, 28, 29);
        m.cylY(BLACK, 8, 8, 2.4, 29, 32);
        m.box(RED, 9, 15, 7, 11, 26, 9);
        return m;
    }

    public static final Model ENTRY_CONSOLE = reg(entryConsole());

    private static Model entryConsole() {
        Model m = new Model("recibidor", 1, 1, 1);
        m.box(WALNUT, 1, 11, 8, 15, 13, 15);
        legs(m, WALNUT, 1, 8, 15, 15, 0, 11, 1);
        m.box(OAK, 2, 9, 8, 14, 11, 9);
        m.box(GOLD, 7, 10, 7, 9, 11, 8);
        m.box(OAK, 2, 2, 9, 14, 3, 14);
        m.box(BLACK, 3, 3, 10, 6, 5, 13);
        m.box(c(0x8D6E63), 9, 3, 10, 12, 5, 13);
        m.cylY(c(0xE8E2D4), 5, 11, 2.2, 13, 14);
        m.box(GOLD, 4, 14, 11, 6, 15, 12);
        m.cylY(c(0x1F618D), 11, 11, 1.5, 13, 16);
        return m;
    }

    public static final Model GLOBE = reg(globe());

    private static Model globe() {
        Model m = new Model("globo_terraqueo", 1, 1, 1);
        m.cylY(WALNUT, 8, 8, 4, 0, 2);
        m.cylY(WALNUT, 8, 8, 0.8, 2, 6);
        m.sphere(c(0x2E86C1), 8, 10.5, 8, 4.5);
        double[][] land = {{-0.5, 0.5, -1}, {0.7, -0.1, -0.7}, {0.2, 0.8, 0.5}, {-0.9, -0.3, 0.3}, {0.8, 0.4, 0.3}, {-0.2, -0.7, -0.6}};
        for (double[] l : land) {
            double d = Math.sqrt(l[0] * l[0] + l[1] * l[1] + l[2] * l[2]);
            m.sphere(c(0x58A55C), 8 + l[0] / d * 3.9, 10.5 + l[1] / d * 3.9, 8 + l[2] / d * 3.9, 1.7);
        }
        for (int y = 5; y <= 15; y++) {
            double a = (y - 10.5) / 5.5;
            int x = (int) Math.round(8 + 5.5 * Math.sqrt(Math.max(0, 1 - a * a)));
            m.box(GOLD, x, y, 8, x + 1, y + 1, 9);
        }
        return m;
    }

    // ================================================================== cocina

    /** Bajo mesada (cuerpo + puerta + mesada de granito) y alzada con azulejos. */
    private static void kitchenBase(Model m, Mat door, Mat top, boolean doors) {
        m.box(door, 0, 1, 2, 16, 13, 16);
        m.box(c(0x2B2B2B), 0, 0, 3, 16, 1, 16);
        if (doors) {
            m.box(c(0xDCD6C8), 1, 2, 1, 15, 12, 2);
            m.box(STEEL, 12, 8, 0, 13, 11, 1);
        }
        m.box(top, 0, 13, 1, 16, 15, 16);
        m.box(c(0xEDEDED), 0, 15, 15, 16, 26, 16);
        m.box(LGRAY, 0, 20, 15, 16, 21, 16);
    }

    public static final Model KSINK = reg(kSink());

    private static Model kSink() {
        Model m = new Model("mesada_pileta", 1, 2, 1);
        kitchenBase(m, c(0xF2EEE6), c(0x3B3B3B), true);
        m.box(STEEL, 3, 10, 4, 13, 15, 12);
        m.cut(4, 11, 5, 12, 15, 11);
        m.box(c(0xBFC5C9), 4, 11, 5, 12, 12, 11);
        m.box(STEEL, 7, 15, 13, 9, 21, 15);
        m.box(STEEL, 7, 19, 9, 9, 21, 13);
        m.box(STEEL, 7, 18, 9, 9, 19, 10);
        m.box(STEEL, 4, 15, 13, 6, 17, 15);
        m.box(STEEL, 10, 15, 13, 12, 17, 15);
        m.box(c(0x48C9B0), 13, 15, 3, 15, 19, 5);
        return m;
    }

    public static final Model KCOUNTER = reg(kCounter());

    private static Model kCounter() {
        Model m = new Model("mesada", 1, 2, 1);
        kitchenBase(m, c(0xF2EEE6), c(0x3B3B3B), true);
        m.box(BIRCH, 2, 15, 3, 11, 16, 10);
        m.box(STEEL, 4, 16, 5, 9, 17, 6);
        m.box(BLACK, 9, 16, 5, 11, 17, 6);
        m.box(WALNUT, 12, 15, 9, 15, 21, 13);
        for (int x = 12; x < 15; x++) m.box(BLACK, x, 21, 10, x + 1, 23, 11);
        m.cylY(GLASS, 4, 13, 1.6, 15, 20);
        m.cylY(c(0xD4AC0D), 4, 13, 1.2, 15, 18);
        m.cylY(c(0x3B3B3B), 4, 13, 1.7, 20, 21);
        return m;
    }

    public static final Model KSPICE = reg(kSpice());

    private static Model kSpice() {
        Model m = new Model("mesada_especias", 1, 2, 1);
        kitchenBase(m, c(0x6D8B74), c(0xE5E1DA), true);
        m.box(WALNUT, 1, 20, 12, 15, 21, 15);
        m.box(WALNUT, 1, 24, 12, 15, 25, 15);
        int[] cols = {0xC0392B, 0xF39C12, 0x27AE60, 0x7D3C98, 0xA04000, 0xF4D03F};
        for (int i = 0; i < 6; i++) {
            int x = 2 + i * 2;
            m.box(c(cols[i]), x, 21, 13, x + 1, 23, 14);
            m.box(c(cols[(i + 3) % 6]), x, 25, 13, x + 1, 27, 14);
        }
        m.cylY(c(0xF2F3F4), 5, 8, 2.2, 15, 21);
        for (int[] u : new int[][]{{4, 7}, {6, 9}, {5, 8}}) m.box(WALNUT, u[0], 21, u[1], u[0] + 1, 25, u[1] + 1);
        m.sphere(c(0xE74C3C), 11, 16.5, 6, 1.6);
        m.sphere(c(0xF4D03F), 13, 16.5, 7, 1.5);
        m.cylY(c(0xF5F5F5), 12, 6.5, 3, 15, 16);
        return m;
    }

    public static final Model STOVE = reg(stove());

    private static Model stove() {
        Model m = new Model("cocina", 1, 2, 1);
        m.box(STEEL, 0, 0, 2, 16, 14, 16);
        m.box(c(0x2B2B2B), 1, 2, 1, 15, 10, 2);
        m.box(GLASS_G, 3, 4, 0, 13, 8, 1);
        m.box(STEEL, 3, 9, 0, 13, 10, 1);
        m.box(BLACK, 2, 11, 1, 14, 13, 2);
        m.box(BLACK, 0, 14, 1, 16, 15, 16);
        for (int[] b : new int[][]{{3, 4}, {10, 4}, {3, 10}}) m.box(c(0x555555), b[0], 15, b[1], b[0] + 3, 16, b[1] + 3);
        m.box(c(0xB03A2E), 9, 15, 9, 14, 19, 14);
        m.box(c(0xF5F5F5), 10, 18, 10, 13, 19, 13);
        m.box(c(0xEDEDED), 0, 15, 15, 16, 26, 16);
        m.box(LGRAY, 0, 20, 15, 16, 21, 16);
        return m;
    }

    public static final Model FRIDGE_HOME = reg(fridgeHome());

    private static Model fridgeHome() {
        Model m = new Model("heladera_casa", 1, 2, 1);
        m.box(WHITE, 1, 0, 2, 15, 31, 16);
        m.box(c(0xF7F7F7), 1, 1, 1, 15, 21, 2);
        m.box(c(0xF7F7F7), 1, 22, 1, 15, 30, 2);
        m.box(LGRAY, 1, 21, 1, 15, 22, 2);
        m.box(STEEL, 12, 13, 0, 13, 20, 1);
        m.box(STEEL, 12, 23, 0, 13, 27, 1);
        int[][] mg = {{3, 16, 0xE74C3C}, {6, 18, 0xF4D03F}, {4, 12, 0x3498DB}, {8, 15, 0x2ECC71}};
        for (int[] g : mg) m.box(c(g[2]), g[0], g[1], 0, g[0] + 2, g[1] + 2, 1);
        m.box(WHITE, 5, 9, 0, 9, 13, 1);
        return m;
    }

    public static final Model FRIDGE_SXS = reg(fridgeSxs());

    private static Model fridgeSxs() {
        Model m = new Model("heladera_doble", 2, 2, 1);
        m.box(STEEL, 1, 0, 2, 31, 31, 16);
        m.box(LGRAY, 1, 1, 1, 15, 31, 2);
        m.box(LGRAY, 17, 1, 1, 31, 31, 2);
        m.box(STEEL, 2, 2, 1, 14, 30, 2);
        m.box(STEEL, 18, 2, 1, 30, 30, 2);
        m.box(c(0x2B2B2B), 15, 1, 1, 17, 31, 2);
        m.box(DARK, 13, 8, 0, 14, 26, 1);
        m.box(DARK, 18, 8, 0, 19, 26, 1);
        m.box(BLACK, 21, 16, 0, 28, 24, 1);
        m.box(LIGHT, 23, 22, 0, 26, 23, 1);
        m.box(STEEL, 24, 18, 0, 25, 21, 1);
        return m;
    }

    public static final Model DISHWASHER = reg(dishwasher());

    private static Model dishwasher() {
        Model m = new Model("lavavajillas", 1, 2, 1);
        kitchenBase(m, STEEL, c(0x3B3B3B), false);
        m.box(STEEL, 1, 1, 1, 15, 11, 2);
        m.box(BLACK, 1, 11, 1, 15, 13, 2);
        m.box(GREEN_LIT, 3, 12, 0, 4, 13, 1);
        m.box(STEEL, 6, 9, 0, 10, 10, 1);
        for (int x = 3; x < 12; x += 3) {
            m.box(WHITE, x, 15, 5, x + 1, 20, 11);
        }
        m.box(STEEL, 2, 15, 4, 13, 16, 12);
        return m;
    }

    public static final Model MICROWAVE = reg(microwave());

    private static Model microwave() {
        Model m = new Model("mesada_microondas", 1, 2, 1);
        kitchenBase(m, c(0xF2EEE6), c(0x3B3B3B), true);
        m.box(BLACK, 1, 15, 6, 15, 22, 14);
        m.box(c(0x1C2833), 2, 16, 5, 11, 21, 6);
        m.box(GLASS_G, 3, 17, 4, 10, 20, 5);
        m.box(LGRAY, 12, 16, 5, 14, 21, 6);
        m.box(GREEN_LIT, 12, 20, 4, 14, 21, 5);
        return m;
    }

    public static final Model BREAKFAST = reg(breakfast());

    private static Model breakfast() {
        Model m = new Model("mesada_desayuno", 1, 2, 1);
        kitchenBase(m, c(0xF2EEE6), c(0x3B3B3B), true);
        m.box(RED, 1, 15, 5, 7, 20, 10);
        m.box(BLACK, 2, 20, 6, 3, 21, 9);
        m.box(BLACK, 5, 20, 6, 6, 21, 9);
        m.box(BLACK, 9, 15, 8, 15, 25, 14);
        m.box(GLASS, 10, 15, 5, 14, 20, 9);
        m.box(c(0x4A2C17), 11, 15, 6, 13, 17, 8);
        m.box(BLACK, 10, 20, 5, 14, 21, 9);
        m.cylY(STEEL, 4, 12, 2, 15, 20);
        m.box(BLACK, 3, 20, 12, 5, 21, 13);
        return m;
    }

    public static final Model WALL_CABINET = reg(wallCabinet());

    private static Model wallCabinet() {
        Model m = new Model("alacena", 1, 1, 1);
        m.box(c(0xF2EEE6), 0, 3, 9, 16, 16, 16);
        m.box(c(0xDCD6C8), 1, 4, 8, 15, 15, 9);
        m.box(STEEL, 12, 4, 7, 13, 7, 8);
        m.box(PEARL, 2, 2, 10, 14, 3, 15);
        return m;
    }

    public static final Model HOOD = reg(hood());

    private static Model hood() {
        Model m = new Model("campana", 1, 1, 1);
        m.box(STEEL, 5, 8, 11, 11, 16, 16);
        m.box(STEEL, 1, 4, 6, 15, 6, 16);
        m.box(STEEL, 3, 6, 9, 13, 8, 16);
        m.box(PEARL, 4, 3, 9, 6, 4, 11);
        m.box(PEARL, 10, 3, 9, 12, 4, 11);
        m.box(BLACK, 2, 4, 5, 14, 5, 6);
        return m;
    }

    public static final Model DINING_TABLE = reg(diningTable());

    private static Model diningTable() {
        Model m = new Model("mesa_comedor", 2, 1, 1);
        m.box(OAK, 0, 11, 1, 32, 13, 15);
        legs(m, OAK, 1, 2, 31, 14, 0, 11, 2);
        m.box(w(0x7B241C), 4, 13, 6, 28, 14, 10);
        for (int x : new int[]{6, 26})
            for (int z : new int[]{4, 12}) {
                m.cylY(WHITE, x, z, 2, 13, 14);
                m.cylY(GLASS, x + 2.5, z, 0.9, 13, 16);
            }
        m.cylY(c(0xF2F3F4), 16, 8, 1.4, 14, 16);
        m.sphere(c(0xE74C3C), 16, 15.5, 8, 0.9);
        return m;
    }

    public static final Model DINING_SET = reg(diningSet());

    private static Model diningSet() {
        Model m = new Model("juego_comedor", 2, 1, 2);
        m.box(WALNUT, 3, 11, 9, 29, 13, 23);
        legs(m, WALNUT, 4, 10, 28, 22, 0, 11, 2);
        Mat seat = w(0xD8C9A8);
        for (int x : new int[]{5, 19}) {
            legs(m, WALNUT, x, 1, x + 8, 8, 0, 6, 1);
            m.box(seat, x, 6, 1, x + 8, 8, 8);
            m.box(WALNUT, x, 8, 1, x + 8, 16, 2);
            legs(m, WALNUT, x, 24, x + 8, 31, 0, 6, 1);
            m.box(seat, x, 6, 24, x + 8, 8, 31);
            m.box(WALNUT, x, 8, 30, x + 8, 16, 31);
        }
        m.box(w(0xF2E8D0), 6, 13, 14, 26, 14, 18);
        m.cylY(c(0x2E4A7A), 16, 16, 1.8, 13, 16);
        m.sphere(c(0xF4D03F), 16, 15.5, 16, 1.2);
        for (int x : new int[]{9, 23})
            for (int z : new int[]{11, 21}) m.cylY(WHITE, x, z, 1.8, 13, 14);
        return m;
    }

    public static final Model ROUND_TABLE = reg(roundTable());

    private static Model roundTable() {
        Model m = new Model("mesa_redonda", 2, 1, 2);
        m.box(WALNUT, 10, 11, 8, 22, 13, 24);
        m.box(WALNUT, 8, 11, 10, 24, 13, 22);
        m.box(WALNUT, 15, 1, 15, 17, 11, 17);
        m.box(WALNUT, 12, 0, 12, 20, 1, 20);
        Mat seat = w(0x8E5B3A);
        int[][] ch = {{12, 0, 0}, {12, 24, 2}, {0, 12, 3}, {24, 12, 1}};
        for (int[] p : ch) {
            int x = p[0], z = p[1];
            legs(m, BLACK, x, z, x + 8, z + 8, 0, 6, 1);
            m.box(seat, x, 6, z, x + 8, 8, z + 8);
            switch (p[2]) {
                case 0 -> m.box(seat, x, 8, z, x + 8, 15, z + 1);
                case 2 -> m.box(seat, x, 8, z + 7, x + 8, 15, z + 8);
                case 3 -> m.box(seat, x, 8, z, x + 1, 15, z + 8);
                default -> m.box(seat, x + 7, 8, z, x + 8, 15, z + 8);
            }
        }
        m.box(c(0xF5F5F5), 13, 13, 13, 19, 14, 19);
        m.box(c(0xE67E22), 14, 14, 14, 16, 15, 16);
        m.box(c(0x27AE60), 16, 14, 16, 18, 15, 18);
        return m;
    }

    public static final Model CHAIR = reg(chairWood());

    private static Model chairWood() {
        Model m = new Model("silla_madera", 1, 1, 1);
        legs(m, OAK, 3, 3, 13, 13, 0, 7, 1);
        m.box(OAK, 3, 7, 3, 13, 8, 13);
        m.box(w(0x9E2B25), 4, 8, 4, 12, 9, 12);
        m.box(OAK, 3, 8, 12, 4, 16, 13);
        m.box(OAK, 12, 8, 12, 13, 16, 13);
        m.box(OAK, 4, 12, 12, 12, 15, 13);
        m.box(OAK, 4, 9, 12, 12, 10, 13);
        return m;
    }

    public static final Model ISLAND = reg(island());

    private static Model island() {
        Model m = new Model("isla_cocina", 2, 1, 1);
        m.box(c(0x2C3E50), 0, 0, 7, 32, 13, 16);
        m.box(MARBLE, 0, 13, 0, 32, 15, 16);
        for (int x : new int[]{6, 20}) {
            m.cylY(STEEL, x + 3, 3.5, 3, 0, 1);
            m.cylY(STEEL, x + 3, 3.5, 0.8, 1, 9);
            m.cylY(BLACK, x + 3, 3.5, 2.8, 9, 10);
            m.box(STEEL, x + 1, 5, 1, x + 5, 6, 2);
        }
        m.cylY(c(0xF5F5F5), 24, 11, 3, 15, 16);
        m.sphere(c(0xF39C12), 24, 16, 11, 1.0);
        m.box(BIRCH, 4, 15, 9, 12, 16, 14);
        return m;
    }

    public static final Model BAR_STOOL = reg(barStool());

    private static Model barStool() {
        Model m = new Model("banqueta", 1, 1, 1);
        m.cylY(STEEL, 8, 8, 4, 0, 1);
        m.cylY(STEEL, 8, 8, 0.8, 1, 11);
        m.cylY(STEEL, 8, 8, 3.2, 5, 6);
        m.cylY(null, 8, 8, 2.4, 5, 6);
        m.cylY(STEEL, 8, 8, 0.8, 5, 6);
        m.cylY(c(0xB03A2E), 8, 8, 4, 11, 13);
        return m;
    }

    public static final Model WASHER = reg(washer());

    private static Model washer() {
        Model m = new Model("lavarropas", 1, 1, 1);
        m.box(WHITE, 1, 0, 2, 15, 15, 16);
        m.box(LGRAY, 1, 12, 1, 15, 15, 2);
        m.box(BLACK, 9, 13, 0, 13, 14, 1);
        m.box(LIGHT, 10, 13, 0, 12, 14, 1);
        m.cylZ(STEEL, 4, 13.5, 1, 0, 1);
        m.cylZ(STEEL, 8, 6.5, 4.6, 1, 2);
        m.cylZ(GLASS_G, 8, 6.5, 3.4, 0, 2);
        m.cylZ(c(0x5DADE2), 8, 6.5, 2.2, 1, 2);
        return m;
    }

    public static final Model DRYER = reg(dryer());

    private static Model dryer() {
        Model m = new Model("secarropas", 1, 1, 1);
        m.box(c(0xD5D8DC), 1, 0, 2, 15, 15, 16);
        m.box(c(0x2C3E50), 1, 12, 1, 15, 15, 2);
        m.box(c(0x5DADE2), 3, 13, 0, 7, 14, 1);
        for (int x = 9; x < 14; x += 2) m.box(STEEL, x, 13, 0, x + 1, 14, 1);
        m.cylZ(c(0x2C3E50), 8, 6.5, 5, 1, 2);
        m.cylZ(TGLASS, 8, 6.5, 3.8, 0, 2);
        m.box(STEEL, 12, 5, 0, 13, 8, 1);
        return m;
    }

    public static final Model PANTRY = reg(pantry());

    private static Model pantry() {
        Model m = new Model("despensa", 1, 2, 1);
        Rng r = new Rng(12);
        m.box(BIRCH, 0, 0, 4, 1, 31, 16);
        m.box(BIRCH, 15, 0, 4, 16, 31, 16);
        m.box(BIRCH, 0, 30, 4, 16, 31, 16);
        for (int y : new int[]{0, 8, 16, 23}) m.box(BIRCH, 1, y, 4, 15, y + 1, 16);
        for (int x = 2; x < 14; x += 4) {
            m.cylY(GLASS, x + 1.5, 9, 1.6, 1, 6);
            m.cylY(c(VIVID[r.nextInt(6)]), x + 1.5, 9, 1.3, 1, 4);
            m.cylY(c(0xC0392B), x + 1.5, 9, 1.7, 6, 7);
        }
        for (int x = 2; x < 14; x += 3) m.cylY(c(new int[]{0xB03A2E, 0x2471A3, 0xD4AC0D}[x % 3]), x + 1, 10, 1.3, 9, 13);
        for (int x = 2; x < 14; x += 4) m.box(c(new int[]{0xF39C12, 0x27AE60, 0xE74C3C}[(x / 4) % 3]), x, 17, 7, x + 3, 22, 13);
        m.box(c(0xC8A165), 2, 24, 6, 7, 28, 14);
        m.box(c(0xC8A165), 9, 24, 6, 14, 28, 14);
        m.sphere(c(0xE67E22), 4, 28, 10, 1.3);
        return m;
    }

    public static final Model HIGH_CHAIR = reg(highChair());

    private static Model highChair() {
        Model m = new Model("silla_bebe", 1, 1, 1);
        Mat p = WHITE;
        m.box(p, 3, 0, 4, 4, 9, 5);
        m.box(p, 12, 0, 4, 13, 9, 5);
        m.box(p, 3, 0, 12, 4, 9, 13);
        m.box(p, 12, 0, 12, 13, 9, 13);
        m.box(p, 3, 4, 4, 13, 5, 5);
        m.box(c(0x76D7C4), 4, 9, 5, 12, 10, 12);
        m.box(p, 4, 10, 11, 12, 16, 12);
        m.box(p, 4, 10, 5, 5, 13, 12);
        m.box(p, 11, 10, 5, 12, 13, 12);
        m.box(c(0x76D7C4), 3, 13, 1, 13, 14, 6);
        return m;
    }

    public static final Model PEDAL_BIN = reg(pedalBin());

    private static Model pedalBin() {
        Model m = new Model("tacho_pedal", 1, 1, 1);
        m.cylY(STEEL, 8, 9, 3.6, 0, 10);
        m.cylY(BLACK, 8, 9, 3.7, 10, 11);
        m.box(BLACK, 6, 0, 4, 10, 1, 6);
        m.box(BLACK, 7, 0, 5, 9, 2, 6);
        return m;
    }

    // ================================================================== dormitorio

    public static final Model BED_DOUBLE = reg(bedDouble());

    private static Model bedDouble() {
        Model m = new Model("cama_matrimonial", 2, 1, 2);
        Mat duvet = w(0x5B7FA3);
        legs(m, WALNUT, 0, 0, 32, 30, 0, 2, 2);
        m.box(WALNUT, 0, 2, 0, 32, 6, 30);
        m.box(WHITE, 1, 6, 1, 31, 10, 29);
        m.box(duvet, 1, 9, 1, 31, 11, 20);
        m.box(duvet, 0, 5, 1, 1, 11, 20);
        m.box(duvet, 31, 5, 1, 32, 11, 20);
        m.box(duvet, 1, 5, 0, 31, 11, 1);
        m.box(w(0xD9A42B), 1, 11, 3, 31, 12, 8);
        cushion(m, Mat.of("white_wool"), 3, 10, 23, 14, 13, 29);
        cushion(m, Mat.of("white_wool"), 18, 10, 23, 29, 13, 29);
        m.box(WALNUT, 0, 2, 30, 32, 16, 32);
        m.box(w(0xC9B79C), 2, 8, 29, 30, 15, 30);
        return m;
    }

    public static final Model BED_MODERN = reg(bedModern());

    private static Model bedModern() {
        Model m = new Model("cama_moderna", 2, 1, 2);
        Mat base = c(0x5D6D7E), head = w(0x7F8C8D), duvet = Mat.of("white_wool");
        m.box(base, 0, 0, 0, 32, 4, 30);
        m.box(WHITE, 1, 4, 1, 31, 8, 29);
        m.box(duvet, 0, 7, 0, 32, 9, 20);
        m.box(w(0x34495E), 1, 9, 2, 31, 10, 9);
        cushion(m, Mat.of("white_wool"), 3, 8, 23, 15, 12, 29);
        cushion(m, Mat.of("white_wool"), 17, 8, 23, 29, 12, 29);
        cushion(m, w(0xE59866), 6, 8, 21, 12, 13, 23);
        cushion(m, w(0x48C9B0), 20, 8, 21, 26, 13, 23);
        m.box(head, 0, 0, 29, 32, 16, 32);
        for (int x = 2; x < 32; x += 4) m.box(w(0x6C7A7B), x, 2, 28, x + 1, 16, 29);
        m.box(head, 0, 2, 28, 1, 16, 29);
        return m;
    }

    public static final Model BED_CANOPY = reg(bedCanopy());

    private static Model bedCanopy() {
        Model m = new Model("cama_dosel", 2, 3, 2);
        for (int[] p : new int[][]{{0, 0}, {29, 0}, {0, 29}, {29, 29}}) m.box(WALNUT, p[0], 0, p[1], p[0] + 3, 44, p[1] + 3);
        m.box(WALNUT, 0, 42, 0, 32, 44, 3);
        m.box(WALNUT, 0, 42, 29, 32, 44, 32);
        m.box(WALNUT, 0, 42, 0, 3, 44, 32);
        m.box(WALNUT, 29, 42, 0, 32, 44, 32);
        m.box(w(0xF2E8D0), 3, 38, 0, 29, 42, 1);
        m.box(WALNUT, 3, 2, 2, 29, 6, 30);
        m.box(WHITE, 3, 6, 2, 29, 10, 29);
        m.box(w(0x922B21), 3, 9, 2, 29, 11, 20);
        m.box(w(0x922B21), 3, 6, 1, 29, 11, 2);
        cushion(m, Mat.of("white_wool"), 5, 10, 23, 15, 13, 29);
        cushion(m, Mat.of("white_wool"), 17, 10, 23, 27, 13, 29);
        m.box(WALNUT, 3, 2, 30, 29, 22, 31);
        for (int[] p : new int[][]{{3, 1}, {27, 1}}) {
            drape(m, w(0xF2E8D0), w(0xE3D7BE), p[0], 12, p[1], p[0] + 2, 38, p[1] + 2);
            m.box(GOLD, p[0], 20, p[1], p[0] + 2, 21, p[1] + 2);
        }
        return m;
    }

    public static final Model BED_SINGLE = reg(bedSingle());

    private static Model bedSingle() {
        Model m = new Model("cama_simple", 1, 1, 2);
        legs(m, BIRCH, 0, 0, 16, 30, 0, 2, 2);
        m.box(BIRCH, 0, 2, 0, 16, 5, 30);
        m.box(WHITE, 1, 5, 1, 15, 9, 29);
        m.box(w(0x3F6FB5), 0, 8, 0, 16, 10, 21);
        m.box(w(0x3F6FB5), 0, 4, 0, 16, 8, 1);
        m.box(w(0x5D8CD0), 0, 9, 4, 16, 10, 7);
        cushion(m, Mat.of("white_wool"), 3, 9, 23, 13, 12, 29);
        m.box(BIRCH, 0, 2, 30, 16, 14, 32);
        m.box(BIRCH, 0, 2, 0, 16, 9, 1);
        return m;
    }

    public static final Model BUNK = reg(bunk());

    private static Model bunk() {
        Model m = new Model("cucheta", 1, 2, 2);
        for (int[] p : new int[][]{{0, 0}, {14, 0}, {0, 30}, {14, 30}}) m.box(PALE, p[0], 0, p[1], p[0] + 2, 31, p[1] + 2);
        for (int y : new int[]{3, 18}) {
            m.box(PALE, 0, y, 0, 16, y + 2, 32);
            m.box(WHITE, 2, y + 2, 2, 14, y + 5, 30);
        }
        m.box(w(0xC0392B), 2, 6, 2, 14, 8, 21);
        m.box(w(0x2471A3), 2, 21, 2, 14, 23, 21);
        cushion(m, Mat.of("white_wool"), 4, 7, 24, 12, 9, 29);
        cushion(m, Mat.of("white_wool"), 4, 22, 24, 12, 24, 29);
        m.box(PALE, 0, 24, 0, 2, 27, 32);
        m.box(PALE, 14, 24, 8, 16, 27, 32);
        for (int y = 3; y < 24; y += 5) m.box(PALE, 14, y, 3, 16, y + 1, 6);
        m.box(PALE, 15, 0, 2, 16, 27, 3);
        m.box(PALE, 15, 0, 6, 16, 27, 7);
        return m;
    }

    public static final Model CAR_BED = reg(carBed());

    private static Model carBed() {
        Model m = new Model("cama_auto", 1, 1, 2);
        Mat body = c(0xD32F2F);
        m.box(body, 0, 1, 0, 16, 8, 32);
        m.box(body, 1, 8, 0, 15, 10, 7);
        m.box(body, 0, 8, 25, 16, 14, 32);
        m.box(GLASS_B, 2, 8, 24, 14, 13, 25);
        m.box(WHITE, 1, 6, 7, 15, 9, 25);
        m.box(w(0xFFFFFF), 3, 9, 19, 13, 11, 24);
        m.box(w(0x212121), 1, 9, 7, 15, 10, 18);
        for (int z : new int[]{5, 26}) {
            m.cylX(BLACK, 3.5, z, 3.5, -1 + 1, 2);
            m.cylX(BLACK, 3.5, z, 3.5, 14, 16);
            m.cylX(STEEL, 3.5, z, 1.4, 0, 1);
            m.cylX(STEEL, 3.5, z, 1.4, 15, 16);
        }
        m.box(YELLOW, 2, 4, 0, 5, 6, 1);
        m.box(YELLOW, 11, 4, 0, 14, 6, 1);
        m.box(WHITE, 6, 3, 0, 10, 7, 1);
        Kit.text(m, "1", BLACK, 8, 7, 0, 0 + 1);
        return m;
    }

    public static final Model CRIB = reg(crib());

    private static Model crib() {
        Model m = new Model("cuna", 1, 1, 1);
        for (int[] p : new int[][]{{1, 3}, {14, 3}, {1, 12}, {14, 12}}) m.box(WHITE, p[0], 0, p[1], p[0] + 1, 15, p[1] + 1);
        m.box(WHITE, 1, 4, 3, 15, 5, 13);
        m.box(c(0xD6EAF8), 2, 5, 4, 14, 7, 12);
        for (int y : new int[]{7, 14}) {
            m.box(WHITE, 1, y, 3, 15, y + 1, 4);
            m.box(WHITE, 1, y, 12, 15, y + 1, 13);
            m.box(WHITE, 1, y, 3, 2, y + 1, 13);
            m.box(WHITE, 14, y, 3, 15, y + 1, 13);
        }
        for (int x = 3; x < 14; x += 2) {
            m.box(WHITE, x, 7, 3, x + 1, 14, 4);
            m.box(WHITE, x, 7, 12, x + 1, 14, 13);
        }
        for (int z = 5; z < 12; z += 2) {
            m.box(WHITE, 1, 7, z, 2, 14, z + 1);
            m.box(WHITE, 14, 7, z, 15, 14, z + 1);
        }
        m.sphere(c(0xA0522D), 10, 8, 8, 1.6);
        m.sphere(c(0xA0522D), 10, 10, 8, 1.2);
        return m;
    }

    public static final Model NIGHTSTAND = reg(nightstand());

    private static Model nightstand() {
        Model m = new Model("mesa_de_luz", 1, 1, 1);
        m.box(WALNUT, 2, 0, 4, 14, 10, 15);
        m.box(OAK, 3, 5, 3, 13, 9, 4);
        m.box(GOLD, 7, 7, 2, 9, 8, 3);
        m.box(OAK, 3, 1, 3, 13, 4, 4);
        m.cylY(c(0xF2F3F4), 5, 10, 1.6, 10, 12);
        m.cylY(STEEL, 5, 10, 0.5, 12, 13);
        m.cylY(w(0xF2E8D0), 5, 10, 2.4, 13, 16);
        m.box(c(0x1F618D), 9, 10, 7, 13, 11, 12);
        m.box(BLACK, 10, 11, 8, 12, 12, 11);
        return m;
    }

    public static final Model WARDROBE = reg(wardrobe());

    private static Model wardrobe() {
        Model m = new Model("ropero", 2, 2, 1);
        m.box(WALNUT, 0, 0, 2, 32, 32, 16);
        m.box(c(0x2E1F12), 0, 0, 1, 32, 2, 2);
        m.box(WALNUT, 0, 30, 1, 32, 32, 2);
        m.box(c(0x2E1F12), 15, 2, 1, 17, 30, 2);
        for (int x : new int[]{2, 18}) {
            m.box(c(0x5A4030), x, 4, 1, x + 12, 28, 2);
            m.box(WALNUT, x + 1, 5, 1, x + 11, 27, 2);
        }
        m.box(GOLD, 13, 14, 0, 14, 18, 1);
        m.box(GOLD, 18, 14, 0, 19, 18, 1);
        return m;
    }

    public static final Model WARDROBE_MIRROR = reg(wardrobeMirror());

    private static Model wardrobeMirror() {
        Model m = new Model("placard_espejo", 2, 2, 1);
        m.box(WHITE, 0, 0, 3, 32, 32, 16);
        m.box(LGRAY, 0, 0, 2, 32, 1, 3);
        m.box(LGRAY, 0, 31, 2, 32, 32, 3);
        m.box(c(0xCFE3EA), 1, 1, 2, 16, 31, 3);
        m.box(c(0xBFD7E0), 16, 1, 1, 31, 31, 2);
        m.box(STEEL, 15, 1, 1, 17, 31, 3);
        m.box(STEEL, 1, 1, 2, 2, 31, 3);
        m.box(STEEL, 30, 1, 1, 31, 31, 2);
        m.box(c(0xE8F4F8), 5, 18, 1, 7, 26, 2);
        return m;
    }

    public static final Model DRESSER = reg(dresser());

    private static Model dresser() {
        Model m = new Model("comoda", 2, 1, 1);
        m.box(WALNUT, 0, 0, 4, 32, 12, 15);
        m.box(WALNUT, 0, 12, 3, 32, 13, 16);
        for (int x : new int[]{1, 17}) drawers(m, OAK, GOLD, x, x + 14, 1, 12, 3, 3);
        m.box(c(0x7D3C98), 3, 13, 8, 9, 16, 13);
        m.box(GOLD, 3, 15, 8, 9, 16, 9);
        m.cylY(c(0xF5B7B1), 14, 10, 1.2, 13, 16);
        m.cylY(c(0xAED6F1), 17, 11, 1.2, 13, 15);
        m.box(GOLD, 22, 13, 13, 30, 16, 14);
        m.box(c(0xCFE3EA), 23, 13, 12, 29, 16, 13);
        return m;
    }

    public static final Model VANITY = reg(vanity());

    private static Model vanity() {
        Model m = new Model("tocador", 1, 2, 1);
        m.box(WHITE, 1, 10, 8, 15, 12, 16);
        legs(m, WHITE, 1, 8, 15, 16, 0, 10, 1);
        m.box(c(0xF5F5F5), 2, 8, 8, 14, 10, 9);
        m.box(GOLD, 7, 9, 7, 9, 10, 8);
        m.cylZ(GOLD, 8, 21, 6, 14, 16);
        m.cylZ(c(0xCFE3EA), 8, 21, 5, 13, 14);
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4;
            m.box(PEARL, (int) Math.round(8 + Math.cos(a) * 6.3), (int) Math.round(21 + Math.sin(a) * 6.3), 13,
                    (int) Math.round(8 + Math.cos(a) * 6.3) + 1, (int) Math.round(21 + Math.sin(a) * 6.3) + 1, 14);
        }
        m.cylY(w(0xF5B7B1), 8, 3, 3, 0, 7);
        m.cylY(c(0xF1948A), 3, 11, 1, 12, 15);
        m.cylY(c(0xAF7AC5), 12, 11, 1, 12, 14);
        return m;
    }

    public static final Model DESK_HOME = reg(deskHome());

    private static Model deskHome() {
        Model m = new Model("escritorio_casa", 2, 2, 1);
        m.box(OAK, 0, 12, 2, 32, 13, 16);
        m.box(OAK, 0, 0, 3, 1, 12, 16);
        m.box(OAK, 20, 0, 3, 32, 12, 16);
        drawers(m, BIRCH, STEEL, 21, 31, 1, 12, 3, 2);
        m.box(c(0x566573), 6, 13, 4, 16, 14, 11);
        m.box(c(0x566573), 6, 13, 10, 16, 20, 11);
        m.box(c(0x85C1E9), 7, 14, 9, 15, 19, 10);
        m.box(BLACK, 17, 13, 6, 19, 14, 9);
        legs(m, STEEL, 26, 12, 27, 13, 13, 14, 1);
        m.box(STEEL, 26, 13, 12, 27, 21, 13);
        m.box(STEEL, 23, 20, 9, 27, 21, 13);
        m.box(STEEL, 22, 18, 8, 25, 20, 11);
        m.box(WARM, 22, 17, 9, 25, 18, 10);
        cup(m, c(0xE74C3C), 2, 13, 5);
        m.box(WALNUT, 0, 24, 11, 32, 25, 16);
        books(m, new Rng(21), 2, 18, 25, 12, 16, 4, 6);
        pot(m, c(0xF5F5F5), 25, 13.5, 2, 25, 3);
        m.sphere(LEAF, 25, 30, 13.5, 2.3);
        return m;
    }

    public static final Model GAMING_DESK = reg(gamingDesk());

    private static Model gamingDesk() {
        Model m = new Model("escritorio_gamer", 2, 2, 1);
        m.box(BLACK, 0, 12, 2, 32, 13, 16);
        m.box(BLACK, 1, 0, 4, 3, 12, 14);
        m.box(BLACK, 22, 0, 4, 24, 12, 14);
        m.box(c(0xAF00FF), 0, 11, 2, 32, 12, 3);
        m.box(c(0x00E5FF), 0, 11, 15, 32, 12, 16);
        m.box(BLACK, 25, 0, 3, 31, 12, 14);
        m.box(GLASS_G, 25, 1, 2, 31, 11, 3);
        m.box(c(0xFF00AA), 26, 3, 3, 30, 4, 13);
        m.box(c(0x00E5FF), 27, 6, 3, 29, 9, 4);
        for (int[] s : new int[][]{{3, 15}, {16, 28}}) {
            m.box(BLACK, s[0] + 4, 13, 9, s[1] - 4, 14, 12);
            m.box(BLACK, (s[0] + s[1]) / 2 - 1, 14, 11, (s[0] + s[1]) / 2 + 1, 17, 12);
            screen(m, s[0], 17, s[1], 25, 10, 2, c(0x1B4F72));
            m.box(c(0xE74C3C), s[0] + 2, 19, 10, s[0] + 5, 22, 11);
            m.box(c(0x2ECC71), s[1] - 5, 20, 10, s[1] - 2, 23, 11);
        }
        m.box(c(0x2C3E50), 8, 13, 4, 22, 14, 7);
        for (int x = 9; x < 21; x += 2) m.box(c(VIVID[x % 7]), x, 14, 5, x + 1, 15, 6);
        m.box(BLACK, 24, 13, 5, 26, 14, 7);
        return m;
    }

    public static final Model GAMING_CHAIR = reg(gamingChair());

    private static Model gamingChair() {
        Model m = new Model("silla_gamer", 1, 1, 1);
        m.box(BLACK, 3, 0, 7, 13, 1, 9);
        m.box(BLACK, 7, 0, 3, 9, 1, 13);
        m.cylY(STEEL, 8, 8, 0.9, 1, 6);
        m.box(BLACK, 3, 6, 3, 13, 8, 13);
        m.box(RED, 3, 7, 3, 4, 9, 13);
        m.box(RED, 12, 7, 3, 13, 9, 13);
        m.box(BLACK, 3, 8, 12, 13, 16, 14);
        m.box(RED, 3, 9, 12, 4, 16, 14);
        m.box(RED, 12, 9, 12, 13, 16, 14);
        m.box(RED, 6, 13, 11, 10, 15, 12);
        m.box(BLACK, 2, 9, 5, 3, 10, 11);
        m.box(BLACK, 13, 9, 5, 14, 10, 11);
        return m;
    }

    public static final Model MIRROR_FLOOR = reg(mirrorFloor());

    private static Model mirrorFloor() {
        Model m = new Model("espejo_pie", 1, 2, 1);
        m.box(GOLD, 3, 0, 9, 5, 2, 13);
        m.box(GOLD, 11, 0, 9, 13, 2, 13);
        for (int y = 2; y < 30; y++) {
            double a = (y - 16) / 14.0;
            int hw = (int) Math.round(6 * Math.sqrt(Math.max(0, 1 - a * a)));
            if (hw < 1) hw = 1;
            m.box(GOLD, 8 - hw, y, 10, 8 + hw, y + 1, 12);
            if (hw > 1) m.box(c(0xCFE3EA), 9 - hw, y, 9, 7 + hw, y + 1, 10);
        }
        m.box(c(0xE8F4F8), 5, 16, 8, 6, 24, 9);
        return m;
    }

    public static final Model TOY_BOX = reg(toyBox());

    private static Model toyBox() {
        Model m = new Model("baul_juguetes", 1, 1, 1);
        m.box(c(0x2E86C1), 1, 0, 3, 15, 9, 13);
        m.cut(2, 2, 4, 14, 9, 12);
        m.box(c(0xF4D03F), 1, 4, 2, 15, 5, 3);
        m.box(c(0x2E86C1), 1, 9, 13, 15, 16, 14);
        m.sphere(RED, 5, 9, 7, 2.6);
        m.box(c(0x27AE60), 9, 6, 5, 12, 9, 8);
        m.box(YELLOW, 10, 9, 8, 13, 12, 11);
        m.sphere(c(0xA0522D), 8, 10, 10, 1.8);
        m.box(c(0xE74C3C), 3, 5, 9, 6, 8, 12);
        return m;
    }

    public static final Model TEDDY = reg(teddy());

    private static Model teddy() {
        Model m = new Model("oso_peluche", 1, 1, 1);
        Mat fur = c(0xA0522D), lt = c(0xD2A679);
        m.ellipsoid(fur, 8, 5, 9, 3.5, 4, 3);
        m.ellipsoid(lt, 8, 4.5, 6.6, 2.2, 2.6, 0.9);
        m.sphere(fur, 8, 10.5, 8.5, 3);
        m.sphere(fur, 5.6, 13, 8.5, 1.3);
        m.sphere(fur, 10.4, 13, 8.5, 1.3);
        m.ellipsoid(lt, 8, 9.6, 5.8, 1.5, 1.1, 1);
        m.box(BLACK, 7, 10, 5, 9, 11, 6);
        m.box(BLACK, 6, 11, 6, 7, 12, 7);
        m.box(BLACK, 9, 11, 6, 10, 12, 7);
        m.ellipsoid(fur, 4.5, 6, 8, 1.4, 2.6, 1.4);
        m.ellipsoid(fur, 11.5, 6, 8, 1.4, 2.6, 1.4);
        m.ellipsoid(fur, 6, 1.5, 6.5, 1.6, 1.5, 2.4);
        m.ellipsoid(fur, 10, 1.5, 6.5, 1.6, 1.5, 2.4);
        m.box(RED, 6, 8, 6, 10, 9, 8);
        return m;
    }

    public static final Model HAMPER = reg(hamper());

    private static Model hamper() {
        Model m = new Model("cesto_ropa", 1, 1, 1);
        Mat a = c(0xC9A66B), b = c(0xAE8C55);
        m.box(a, 4, 0, 4, 12, 10, 12);
        m.box(b, 3, 2, 4, 13, 4, 12);
        m.box(b, 4, 2, 3, 12, 4, 13);
        m.box(b, 3, 6, 4, 13, 8, 12);
        m.box(b, 4, 6, 3, 12, 8, 13);
        m.cut(5, 3, 5, 11, 10, 11);
        m.box(w(0x5DADE2), 5, 9, 5, 9, 11, 9);
        m.box(w(0xF1948A), 8, 9, 7, 11, 11, 11);
        m.box(w(0xFFFFFF), 5, 9, 8, 8, 10, 11);
        return m;
    }

    public static final Model ROCKING_HORSE = reg(rockingHorse());

    private static Model rockingHorse() {
        Model m = new Model("caballito", 1, 1, 1);
        for (int z = 0; z < 16; z++) {
            double t = (z - 7.5) / 7.5;
            int y = (int) Math.round(2.5 * t * t);
            m.box(c(0xB03A2E), 3, y, z, 5, y + 1, z + 1);
            m.box(c(0xB03A2E), 11, y, z, 13, y + 1, z + 1);
        }
        for (int[] p : new int[][]{{4, 3}, {11, 3}, {4, 11}, {11, 11}}) m.box(WALNUT, p[0], 1, p[1], p[0] + 1, 7, p[1] + 1);
        Mat hide = c(0xC68642);
        m.ellipsoid(hide, 8, 8.5, 8, 3, 2.2, 5.5);
        m.box(hide, 7, 9, 2, 10, 13, 5);
        m.box(hide, 7, 11, 0, 10, 14, 3);
        m.box(c(0x6E2C00), 7, 12, 3, 10, 15, 4);
        m.box(c(0x6E2C00), 8, 9, 13, 9, 12, 15);
        m.box(c(0xC0392B), 5, 10, 7, 11, 11, 10);
        m.box(BLACK, 7, 12, 0, 8, 13, 1);
        m.box(BLACK, 9, 12, 0, 10, 13, 1);
        return m;
    }

    // ================================================================== baño

    public static final Model TOILET = reg(toilet());

    private static Model toilet() {
        Model m = new Model("inodoro", 1, 1, 1);
        Mat p = QUARTZ;
        m.box(p, 3, 9, 12, 13, 16, 16);
        m.box(p, 5, 0, 7, 11, 5, 13);
        m.box(p, 4, 4, 4, 12, 8, 13);
        m.box(p, 5, 4, 3, 11, 8, 4);
        m.cut(5, 6, 5, 11, 8, 11);
        m.box(c(0xBFD7E0), 6, 6, 6, 10, 7, 10);
        m.box(WHITE, 4, 8, 3, 12, 9, 12);
        m.cut(6, 8, 5, 10, 9, 10);
        m.box(STEEL, 7, 15, 13, 9, 16, 15);
        return m;
    }

    public static final Model BATH_SINK = reg(bathSink());

    private static Model bathSink() {
        Model m = new Model("lavatorio", 1, 2, 1);
        Mat p = QUARTZ;
        m.cylY(p, 8, 11, 2, 0, 11);
        m.box(p, 2, 11, 5, 14, 14, 16);
        m.cut(4, 12, 7, 12, 14, 13);
        m.box(c(0xBFD7E0), 4, 12, 7, 12, 13, 13);
        m.box(STEEL, 7, 14, 13, 9, 18, 15);
        m.box(STEEL, 7, 17, 10, 9, 18, 13);
        m.box(BLACK, 3, 18, 15, 13, 30, 16);
        m.box(c(0xCFE3EA), 4, 19, 14, 12, 29, 15);
        m.box(PEARL, 4, 30, 14, 12, 31, 16);
        m.box(GLASS, 11, 14, 6, 13, 17, 8);
        m.box(c(0x48C9B0), 11, 15, 7, 12, 19, 8);
        return m;
    }

    public static final Model VANITY_DOUBLE = reg(vanityDouble());

    private static Model vanityDouble() {
        Model m = new Model("vanitory", 2, 2, 1);
        m.box(WALNUT, 0, 1, 3, 32, 13, 16);
        m.box(c(0x2B2B2B), 0, 0, 4, 32, 1, 16);
        for (int x : new int[]{1, 9, 17, 25}) m.box(OAK, x, 2, 2, x + 6, 12, 3);
        for (int x : new int[]{6, 10, 22, 26}) m.box(STEEL, x, 9, 1, x + 1, 11, 2);
        m.box(QUARTZ, 0, 13, 2, 32, 15, 16);
        for (int cx : new int[]{8, 24}) {
            m.cut(cx - 4, 13, 5, cx + 4, 15, 12);
            m.box(c(0xBFD7E0), cx - 4, 13, 5, cx + 4, 14, 12);
            m.box(STEEL, cx - 1, 15, 13, cx + 1, 19, 15);
            m.box(STEEL, cx - 1, 18, 10, cx + 1, 19, 13);
        }
        m.box(BLACK, 2, 18, 15, 30, 30, 16);
        m.box(c(0xCFE3EA), 3, 19, 14, 29, 29, 15);
        m.box(PEARL, 4, 30, 14, 28, 31, 16);
        m.box(c(0xF5F5F5), 14, 15, 6, 18, 17, 10);
        return m;
    }

    public static final Model BATHTUB = reg(bathtub());

    private static Model bathtub() {
        Model m = new Model("banera", 1, 1, 2);
        Mat p = QUARTZ;
        m.box(p, 0, 0, 1, 16, 9, 32);
        m.cut(2, 3, 3, 14, 9, 30);
        m.box(WATER, 2, 3, 3, 14, 7, 30);
        m.box(p, 2, 2, 3, 14, 3, 30);
        m.box(STEEL, 7, 9, 29, 9, 12, 31);
        m.box(STEEL, 7, 11, 26, 9, 12, 29);
        m.box(STEEL, 4, 9, 30, 6, 10, 31);
        m.box(STEEL, 10, 9, 30, 12, 10, 31);
        m.box(YELLOW, 6, 7, 12, 9, 9, 15);
        m.box(YELLOW, 8, 9, 12, 10, 11, 14);
        m.box(ORANGE, 10, 10, 13, 11, 11, 14);
        m.box(w(0xFFFFFF), 0, 9, 6, 16, 10, 9);
        return m;
    }

    public static final Model SHOWER = reg(shower());

    private static Model shower() {
        Model m = new Model("ducha", 1, 2, 1);
        m.box(QUARTZ, 0, 0, 0, 16, 1, 16);
        m.box(STEEL, 7, 0, 7, 9, 1, 9);
        m.box(c(0xE8EEF0), 0, 1, 15, 16, 31, 16);
        m.box(LGRAY, 0, 16, 15, 16, 17, 16);
        m.box(GLASS, 0, 1, 0, 16, 31, 1);
        m.box(GLASS, 0, 1, 1, 1, 31, 15);
        m.box(STEEL, 0, 31, 0, 16, 32, 1);
        m.box(STEEL, 0, 31, 0, 1, 32, 16);
        m.box(STEEL, 13, 1, 0, 14, 31, 1);
        m.box(STEEL, 12, 14, 1, 13, 17, 2);
        m.box(STEEL, 7, 15, 14, 9, 29, 15);
        m.box(STEEL, 7, 27, 9, 9, 29, 14);
        m.box(STEEL, 6, 26, 7, 10, 27, 11);
        m.box(STEEL, 6, 14, 14, 10, 17, 15);
        return m;
    }

    public static final Model TOWEL_RACK = reg(towelRack());

    private static Model towelRack() {
        Model m = new Model("toallero", 1, 1, 1);
        m.box(STEEL, 1, 10, 14, 2, 12, 16);
        m.box(STEEL, 14, 10, 14, 15, 12, 16);
        m.box(STEEL, 1, 11, 12, 15, 12, 14);
        m.box(w(0xFFFFFF), 2, 3, 12, 8, 12, 14);
        m.box(w(0x85C1E9), 8, 4, 12, 14, 12, 14);
        m.box(w(0x5DADE2), 8, 4, 12, 14, 5, 14);
        return m;
    }

    public static final Model MED_MIRROR = reg(medMirror());

    private static Model medMirror() {
        Model m = new Model("botiquin_espejo", 1, 1, 1);
        m.box(WHITE, 2, 4, 12, 14, 16, 16);
        m.box(c(0xCFE3EA), 3, 5, 11, 13, 15, 12);
        m.box(STEEL, 12, 8, 10, 13, 11, 11);
        m.box(WHITE, 2, 1, 12, 14, 2, 16);
        m.cylY(c(0x48C9B0), 5, 13.5, 1.2, 2, 5);
        m.box(c(0xE74C3C), 5, 4, 13, 6, 7, 14);
        m.cylY(c(0xF5B7B1), 10, 14, 1, 2, 5);
        return m;
    }
}
