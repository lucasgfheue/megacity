package com.megaciudad.core.layout;

import com.megaciudad.core.Rng;

import java.util.ArrayList;
import java.util.List;

import static com.megaciudad.core.layout.Plot.*;

/** Decide de forma determinista cómo se divide cada manzana y qué se construye en cada parcela. */
public final class LotPlanner {
    private final CityLayout L;

    public LotPlanner(CityLayout layout) {
        this.L = layout;
    }

    private static final int[][] SPECIAL = {
            {11, 11, CITY_HALL}, {12, 11, CENTRAL_PLAZA}, {11, 12, CATHEDRAL}, {12, 12, LANDMARK},
            {10, 7, CENTRAL_STATION}, {4, 18, STADIUM},
            {8, 14, PARK}, {15, 9, PARK}, {5, 5, PARK}, {18, 19, PARK}, {2, 12, PARK}, {21, 4, PARK}, {13, 21, PARK},
            {9, 2, PARK}, {16, 16, PARK},
            {14, 14, HOSPITAL}, {6, 9, HOSPITAL}, {17, 2, HOSPITAL},
            {16, 12, MALL}, {7, 15, MALL}, {19, 8, MALL}, {10, 19, MALL},
            {13, 8, SUPERMARKET}, {9, 16, SUPERMARKET},
    };

    public static int special(int i, int j) {
        for (int[] s : SPECIAL) if (s[0] == i && s[1] == j) return s[2];
        return -1;
    }

    public List<Plot> plan(int i, int j) {
        List<Plot> out = new ArrayList<>();
        Rng r = new Rng(Rng.hash(L.seed, 0x107, i, j));
        int x0 = L.lotX0(i), x1 = L.lotX1(i), z0 = L.lotZ0(j), z1 = L.lotZ1(j);
        int dist = L.district(i, j);
        int sp = special(i, j);
        if (sp >= 0) {
            out.add(plot(i, j, x0, z0, x1, z1, front(i, j, x0, z0, x1, z1, r), sp, r, dist));
            return out;
        }
        boolean ind = L.industrial(i, j) && dist >= CityLayout.URBAN;
        int layout;
        if (ind) layout = r.weighted(0.5, 0.5, 0, 0, 0);
        else layout = switch (dist) {
            case CityLayout.CORE -> r.weighted(0.4, 0.35, 0.25, 0, 0);
            case CityLayout.MIDTOWN -> r.weighted(0.15, 0.35, 0.5, 0, 0);
            case CityLayout.URBAN -> r.weighted(0.12, 0.25, 0.13, 0.5, 0);
            default -> r.weighted(0.12, 0.18, 0, 0, 0.7);
        };
        switch (layout) {
            case 0 -> {
                int t = ind ? (r.chance(0.6) ? WAREHOUSE : FACTORY) : pickFull(dist, r);
                out.add(plot(i, j, x0, z0, x1, z1, front(i, j, x0, z0, x1, z1, r), t, r, dist));
            }
            case 1 -> {
                boolean splitX = r.chance(0.5);
                int[][] rects = splitX
                        ? new int[][]{{x0, z0, (x0 + x1) / 2, z1}, {(x0 + x1) / 2 + 1, z0, x1, z1}}
                        : new int[][]{{x0, z0, x1, (z0 + z1) / 2}, {x0, (z0 + z1) / 2 + 1, x1, z1}};
                for (int[] q : rects) {
                    int t = ind ? (r.chance(0.7) ? WAREHOUSE : FACTORY) : pickHalf(dist, r);
                    out.add(plot(i, j, q[0], q[1], q[2], q[3], frontLong(i, j, q, r), t, r, dist));
                }
            }
            case 2 -> {
                int mx = (x0 + x1) / 2, mz = (z0 + z1) / 2;
                int[][] rects = {{x0, z0, mx, mz}, {mx + 1, z0, x1, mz}, {x0, mz + 1, mx, z1}, {mx + 1, mz + 1, x1, z1}};
                for (int[] q : rects) {
                    int t = pickQuarter(dist, r);
                    out.add(plot(i, j, q[0], q[1], q[2], q[3], front(i, j, q[0], q[1], q[2], q[3], r), t, r, dist));
                }
            }
            case 3 -> perimeterBlock(out, i, j, x0, z0, x1, z1, r, dist);
            default -> houses(out, i, j, x0, z0, x1, z1, r, dist);
        }
        return out;
    }

    private Plot plot(int i, int j, int x0, int z0, int x1, int z1, int rot, int type, Rng r, int dist) {
        return new Plot(x0, z0, x1, z1, rot, type, r.nextLong(), dist, i, j);
    }

    private static int roadWidthAt(int i, int j, int side) {
        return switch (side) {
            case 0 -> CityLayout.roadW(j);
            case 1 -> CityLayout.roadW(i + 1);
            case 2 -> CityLayout.roadW(j + 1);
            default -> CityLayout.roadW(i);
        };
    }

    /** Frente hacia la calle más importante de los lados que toca la parcela. */
    private int front(int i, int j, int x0, int z0, int x1, int z1, Rng r) {
        boolean[] touches = {z0 == L.lotZ0(j), x1 == L.lotX1(i), z1 == L.lotZ1(j), x0 == L.lotX0(i)};
        int best = -1, bestW = -1;
        int start = r.nextInt(4);
        for (int n = 0; n < 4; n++) {
            int s = (start + n) & 3;
            if (!touches[s]) continue;
            int w = roadWidthAt(i, j, s);
            if (w > bestW) {
                bestW = w;
                best = s;
            }
        }
        return best < 0 ? 0 : best;
    }

    /** Para medias manzanas: frente sobre el lado largo. */
    private int frontLong(int i, int j, int[] q, Rng r) {
        int w = q[2] - q[0] + 1, d = q[3] - q[1] + 1;
        boolean[] touches = {q[1] == L.lotZ0(j), q[2] == L.lotX1(i), q[3] == L.lotZ1(j), q[0] == L.lotX0(i)};
        if (w >= d) {
            if (touches[0] && touches[2]) return roadWidthAt(i, j, 0) >= roadWidthAt(i, j, 2) ? 0 : 2;
            return touches[0] ? 0 : 2;
        }
        if (touches[1] && touches[3]) return roadWidthAt(i, j, 1) >= roadWidthAt(i, j, 3) ? 1 : 3;
        return touches[1] ? 1 : 3;
    }

    private static int pickFull(int d, Rng r) {
        return switch (d) {
            case CityLayout.CORE -> new int[]{TOWER, HOTEL, PLAZA, OFFICE, MALL}[r.weighted(0.55, 0.15, 0.08, 0.14, 0.08)];
            case CityLayout.MIDTOWN -> new int[]{TOWER, RESI_TOWER, MALL, PARK, PLAZA, SUPERMARKET, HOTEL, OFFICE}
                    [r.weighted(0.22, 0.18, 0.1, 0.1, 0.05, 0.1, 0.1, 0.15)];
            case CityLayout.URBAN -> new int[]{PARK, SCHOOL, SUPERMARKET, APARTMENTS, PARKING_LOT, RESI_TOWER}
                    [r.weighted(0.2, 0.2, 0.2, 0.25, 0.05, 0.1)];
            default -> new int[]{PARK, SCHOOL, SUPERMARKET, WAREHOUSE, PARKING_LOT, APARTMENTS}
                    [r.weighted(0.25, 0.2, 0.25, 0.1, 0.05, 0.15)];
        };
    }

    private static int pickHalf(int d, Rng r) {
        return switch (d) {
            case CityLayout.CORE -> new int[]{TOWER, HOTEL, OFFICE}[r.weighted(0.5, 0.2, 0.3)];
            case CityLayout.MIDTOWN -> new int[]{TOWER, RESI_TOWER, OFFICE, HOTEL, SUPERMARKET, PARKING_GARAGE, APARTMENTS}
                    [r.weighted(0.22, 0.3, 0.2, 0.08, 0.06, 0.06, 0.08)];
            case CityLayout.URBAN -> new int[]{APARTMENTS, SUPERMARKET, SCHOOL, FIRE_STATION, POLICE, PARKING_LOT, SHOPS, RESI_TOWER}
                    [r.weighted(0.32, 0.18, 0.08, 0.05, 0.05, 0.06, 0.14, 0.12)];
            default -> new int[]{SUPERMARKET, WAREHOUSE, GAS_STATION, PARKING_LOT, SCHOOL, FIRE_STATION, POLICE, APARTMENTS}
                    [r.weighted(0.2, 0.2, 0.12, 0.08, 0.1, 0.05, 0.05, 0.2)];
        };
    }

    private static int pickQuarter(int d, Rng r) {
        return switch (d) {
            case CityLayout.CORE -> new int[]{TOWER, OFFICE, PARKING_GARAGE, HOTEL}[r.weighted(0.55, 0.3, 0.05, 0.1)];
            case CityLayout.MIDTOWN -> new int[]{RESI_TOWER, OFFICE, TOWER, PARKING_GARAGE, GAS_STATION, APARTMENTS, PLAZA}
                    [r.weighted(0.3, 0.28, 0.15, 0.07, 0.03, 0.12, 0.05)];
            default -> new int[]{APARTMENTS, SHOPS, GAS_STATION, PARKING_LOT, POLICE, FIRE_STATION, PLAZA}
                    [r.weighted(0.4, 0.2, 0.1, 0.08, 0.04, 0.04, 0.14)];
        };
    }

    /** Manzana perimetral: edificios entre medianeras alrededor de un patio interior. */
    private void perimeterBlock(List<Plot> out, int i, int j, int x0, int z0, int x1, int z1, Rng r, int dist) {
        int D = r.range(18, 21);
        // lados norte y sur (ancho completo), lados este y oeste (tramo medio)
        frontages(out, i, j, x0, z0, x1, z0 + D - 1, 0, r, dist);
        frontages(out, i, j, x0, z1 - D + 1, x1, z1, 2, r, dist);
        frontages(out, i, j, x1 - D + 1, z0 + D, x1, z1 - D, 1, r, dist);
        frontages(out, i, j, x0, z0 + D, x0 + D - 1, z1 - D, 3, r, dist);
        out.add(new Plot(x0 + D, z0 + D, x1 - D, z1 - D, 0, COURTYARD, r.nextLong(), dist, i, j));
    }

    private void frontages(List<Plot> out, int i, int j, int x0, int z0, int x1, int z1, int rot, Rng r, int dist) {
        boolean alongX = rot == 0 || rot == 2;
        int len = alongX ? x1 - x0 + 1 : z1 - z0 + 1;
        int p = 0;
        while (p < len) {
            int rem = len - p;
            int t = new int[]{TOWNHOUSE, SHOPS, APARTMENTS}[r.weighted(0.38, 0.32, 0.3)];
            int w = t == APARTMENTS ? r.range(15, 22) : r.range(8, 13);
            if (rem - w < 8) w = rem;
            if (w > 24 && t != APARTMENTS) t = APARTMENTS;
            int a = p, b = p + w - 1;
            if (alongX) out.add(new Plot(x0 + a, z0, x0 + b, z1, rot, t, r.nextLong(), dist, i, j));
            else out.add(new Plot(x0, z0 + a, x1, z0 + b, rot, t, r.nextLong(), dist, i, j));
            p += w;
        }
    }

    /** Barrio de casas: dos hileras espalda con espalda que miran al norte y al sur. */
    private void houses(List<Plot> out, int i, int j, int x0, int z0, int x1, int z1, Rng r, int dist) {
        int mz = (z0 + z1) / 2;
        for (int side = 0; side < 2; side++) {
            int zz0 = side == 0 ? z0 : mz + 1, zz1 = side == 0 ? mz : z1;
            int rot = side == 0 ? 0 : 2;
            int len = x1 - x0 + 1, p = 0;
            while (p < len) {
                int w = r.range(13, 17);
                if (len - p - w < 12) w = len - p;
                int t = r.chance(0.08) ? SHOPS : r.chance(0.05) ? GAS_STATION : HOUSE;
                out.add(new Plot(x0 + p, zz0, x0 + p + w - 1, zz1, rot, t, r.nextLong(), dist, i, j));
                p += w;
            }
        }
    }
}
