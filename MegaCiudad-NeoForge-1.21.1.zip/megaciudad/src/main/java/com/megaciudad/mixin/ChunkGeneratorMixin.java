package com.megaciudad.mixin;

import com.megaciudad.mc.CityHooks;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Genera la ciudad en la etapa de decoración del chunk y evita que la decoración y las
 * estructuras vanilla aparezcan dentro de ella.
 */
@Mixin(ChunkGenerator.class)
public abstract class ChunkGeneratorMixin {

    @Inject(method = "applyBiomeDecoration", at = @At("HEAD"), cancellable = true)
    private void megaciudad$applyBiomeDecoration(WorldGenLevel level, ChunkAccess chunk, StructureManager structureManager,
                                                 CallbackInfo ci) {
        if (CityHooks.decorate(level, chunk)) ci.cancel();
    }

    @Inject(method = "createStructures", at = @At("HEAD"), cancellable = true)
    private void megaciudad$createStructures(RegistryAccess registryAccess, ChunkGeneratorStructureState structureState,
                                             StructureManager structureManager, ChunkAccess chunk,
                                             StructureTemplateManager structureTemplateManager, CallbackInfo ci) {
        if (CityHooks.blockStructures(structureManager, chunk)) ci.cancel();
    }
}
