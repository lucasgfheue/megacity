package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

import java.util.ArrayList;
import java.util.List;

/**
 * Modelo de mini-bloques definido en vóxeles (16 por bloque). Se rasteriza una vez, se rota en
 * pasos de 90° y se convierte por bloque en cajas mínimas (greedy meshing) para LittleTiles.
 * Coordenadas de caja: mínimo inclusivo, máximo exclusivo. El frente del modelo mira al norte (z=0).
 */
public final class Model {
    public final String name;
    public final int sx, sy, sz;
    final int vx, vy, vz;
    final short[] vox;
    final List<Mat> mats = new ArrayList<>();
    final List<int[]> extras = new ArrayList<>();
    private final Compiled[] compiled = new Compiled[4];

    public Model(String name, int sx, int sy, int sz) {
        this.name = name;
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
        this.vx = sx * 16;
        this.vy = sy * 16;
        this.vz = sz * 16;
        this.vox = new short[vx * vy * vz];
        mats.add(null);
    }

    private int id(Mat m) {
        if (m == null) return 0;
        for (int i = 1; i < mats.size(); i++) if (mats.get(i) == m) return i;
        mats.add(m);
        return mats.size() - 1;
    }

    private int idx(int x, int y, int z) {
        return (y * vz + z) * vx + x;
    }

    public boolean inside(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < vx && y < vy && z < vz;
    }

    public void put(int x, int y, int z, Mat m) {
        if (inside(x, y, z)) vox[idx(x, y, z)] = (short) id(m);
    }

    /** Caja de vóxeles [x0,x1) x [y0,y1) x [z0,z1). Material null = vaciar. */
    public Model box(Mat m, int x0, int y0, int z0, int x1, int y1, int z1) {
        int id = id(m);
        int ax = Math.max(0, Math.min(x0, x1)), bx = Math.min(vx, Math.max(x0, x1));
        int ay = Math.max(0, Math.min(y0, y1)), by = Math.min(vy, Math.max(y0, y1));
        int az = Math.max(0, Math.min(z0, z1)), bz = Math.min(vz, Math.max(z0, z1));
        for (int y = ay; y < by; y++)
            for (int z = az; z < bz; z++)
                for (int x = ax; x < bx; x++) vox[idx(x, y, z)] = (short) id;
        return this;
    }

    public Model cut(int x0, int y0, int z0, int x1, int y1, int z1) {
        return box(null, x0, y0, z0, x1, y1, z1);
    }

    /** Cilindro vertical de centro (cx,cz) y radio r en vóxeles. */
    public Model cylY(Mat m, double cx, double cz, double r, int y0, int y1) {
        int id = id(m);
        for (int z = (int) Math.floor(cz - r); z <= (int) Math.ceil(cz + r); z++)
            for (int x = (int) Math.floor(cx - r); x <= (int) Math.ceil(cx + r); x++) {
                double dx = x + 0.5 - cx, dz = z + 0.5 - cz;
                if (dx * dx + dz * dz > r * r) continue;
                for (int y = Math.max(0, y0); y < Math.min(vy, y1); y++) if (inside(x, y, z)) vox[idx(x, y, z)] = (short) id;
            }
        return this;
    }

    /** Cilindro a lo largo de X. */
    public Model cylX(Mat m, double cy, double cz, double r, int x0, int x1) {
        int id = id(m);
        for (int z = (int) Math.floor(cz - r); z <= (int) Math.ceil(cz + r); z++)
            for (int y = (int) Math.floor(cy - r); y <= (int) Math.ceil(cy + r); y++) {
                double dy = y + 0.5 - cy, dz = z + 0.5 - cz;
                if (dy * dy + dz * dz > r * r) continue;
                for (int x = Math.max(0, x0); x < Math.min(vx, x1); x++) if (inside(x, y, z)) vox[idx(x, y, z)] = (short) id;
            }
        return this;
    }

    /** Cilindro a lo largo de Z. */
    public Model cylZ(Mat m, double cx, double cy, double r, int z0, int z1) {
        int id = id(m);
        for (int y = (int) Math.floor(cy - r); y <= (int) Math.ceil(cy + r); y++)
            for (int x = (int) Math.floor(cx - r); x <= (int) Math.ceil(cx + r); x++) {
                double dx = x + 0.5 - cx, dy = y + 0.5 - cy;
                if (dx * dx + dy * dy > r * r) continue;
                for (int z = Math.max(0, z0); z < Math.min(vz, z1); z++) if (inside(x, y, z)) vox[idx(x, y, z)] = (short) id;
            }
        return this;
    }

    public Model sphere(Mat m, double cx, double cy, double cz, double r) {
        return ellipsoid(m, cx, cy, cz, r, r, r);
    }

    public Model ellipsoid(Mat m, double cx, double cy, double cz, double rx, double ry, double rz) {
        int id = id(m);
        for (int y = (int) Math.floor(cy - ry); y <= (int) Math.ceil(cy + ry); y++)
            for (int z = (int) Math.floor(cz - rz); z <= (int) Math.ceil(cz + rz); z++)
                for (int x = (int) Math.floor(cx - rx); x <= (int) Math.ceil(cx + rx); x++) {
                    double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry, dz = (z + 0.5 - cz) / rz;
                    if (dx * dx + dy * dy + dz * dz <= 1 && inside(x, y, z)) vox[idx(x, y, z)] = (short) id;
                }
        return this;
    }

    /** Sustituye un material por otro (para variantes de color). */
    public Model replace(Mat from, Mat to) {
        int a = id(from), b = id(to);
        for (int i = 0; i < vox.length; i++) if (vox[i] == a) vox[i] = (short) b;
        return this;
    }

    public Model copy(String newName) {
        Model m = new Model(newName, sx, sy, sz);
        m.mats.clear();
        m.mats.addAll(mats);
        System.arraycopy(vox, 0, m.vox, 0, vox.length);
        m.extras.addAll(extras);
        return m;
    }

    /** Bloque vanilla adicional en una celda (bx,by,bz) del modelo, p. ej. una luz invisible. */
    public Model extra(int bx, int by, int bz, BlockRef b) {
        extras.add(new int[]{bx, by, bz, b.index});
        return this;
    }

    public Model light(int bx, int by, int bz, int level) {
        return extra(bx, by, bz, BlockRef.of("light[level=" + level + ",waterlogged=false]"));
    }

    // ------------------------------------------------------------------ compilación

    public static final class Compiled {
        public final int sx, sz;
        public final LittleBlock[] blocks;
        public final List<int[]> extras;

        Compiled(int sx, int sz, LittleBlock[] blocks, List<int[]> extras) {
            this.sx = sx;
            this.sz = sz;
            this.blocks = blocks;
            this.extras = extras;
        }
    }

    public Compiled compiled(int k) {
        k &= 3;
        Compiled c = compiled[k];
        if (c == null) {
            synchronized (this) {
                c = compiled[k];
                if (c == null) {
                    c = compile(k);
                    compiled[k] = c;
                }
            }
        }
        return c;
    }

    private Compiled compile(int k) {
        int rvx = (k & 1) == 0 ? vx : vz, rvz = (k & 1) == 0 ? vz : vx;
        int rsx = rvx / 16, rsz = rvz / 16;
        short[] r = new short[vox.length];
        for (int y = 0; y < vy; y++)
            for (int z = 0; z < vz; z++)
                for (int x = 0; x < vx; x++) {
                    short v = vox[idx(x, y, z)];
                    if (v == 0) continue;
                    int nx, nz;
                    switch (k) {
                        case 1 -> { nx = vz - 1 - z; nz = x; }
                        case 2 -> { nx = vx - 1 - x; nz = vz - 1 - z; }
                        case 3 -> { nx = z; nz = vx - 1 - x; }
                        default -> { nx = x; nz = z; }
                    }
                    r[(y * rvz + nz) * rvx + nx] = v;
                }
        Mat[] rm = new Mat[mats.size()];
        for (int i = 1; i < rm.length; i++) rm[i] = mats.get(i).rot(k);

        LittleBlock[] out = new LittleBlock[rsx * sy * rsz];
        short[] cell = new short[16 * 16 * 16];
        for (int by = 0; by < sy; by++)
            for (int bz = 0; bz < rsz; bz++)
                for (int bx = 0; bx < rsx; bx++) {
                    boolean any = false;
                    for (int y = 0; y < 16; y++)
                        for (int z = 0; z < 16; z++)
                            for (int x = 0; x < 16; x++) {
                                short v = r[((by * 16 + y) * rvz + bz * 16 + z) * rvx + bx * 16 + x];
                                cell[(y * 16 + z) * 16 + x] = v;
                                if (v != 0) any = true;
                            }
                    if (any) out[(by * rsz + bz) * rsx + bx] = mesh(cell, rm);
                }
        List<int[]> ex = new ArrayList<>();
        for (int[] e : extras) {
            int nx, nz;
            switch (k) {
                case 1 -> { nx = sz - 1 - e[2]; nz = e[0]; }
                case 2 -> { nx = sx - 1 - e[0]; nz = sz - 1 - e[2]; }
                case 3 -> { nx = e[2]; nz = sx - 1 - e[0]; }
                default -> { nx = e[0]; nz = e[2]; }
            }
            ex.add(new int[]{nx, e[1], nz, BlockRef.byIndex(e[3]).rot(k).index});
        }
        return new Compiled(rsx, rsz, out, ex);
    }

    /** Greedy meshing de una celda 16³ en cajas por material. */
    static LittleBlock mesh(short[] cell, Mat[] mats) {
        boolean[] used = new boolean[cell.length];
        List<List<Integer>> perMat = new ArrayList<>();
        for (int i = 0; i < mats.length; i++) perMat.add(null);
        int[] count = new int[mats.length];
        int volume = 0;
        for (int y = 0; y < 16; y++)
            for (int z = 0; z < 16; z++)
                for (int x = 0; x < 16; x++) {
                    int i0 = (y * 16 + z) * 16 + x;
                    int m = cell[i0];
                    if (m == 0 || used[i0]) continue;
                    int x1 = x;
                    while (x1 + 1 < 16 && cell[(y * 16 + z) * 16 + x1 + 1] == m && !used[(y * 16 + z) * 16 + x1 + 1]) x1++;
                    int z1 = z;
                    grow:
                    while (z1 + 1 < 16) {
                        for (int xx = x; xx <= x1; xx++) {
                            int j = (y * 16 + z1 + 1) * 16 + xx;
                            if (cell[j] != m || used[j]) break grow;
                        }
                        z1++;
                    }
                    int y1 = y;
                    growY:
                    while (y1 + 1 < 16) {
                        for (int zz = z; zz <= z1; zz++)
                            for (int xx = x; xx <= x1; xx++) {
                                int j = ((y1 + 1) * 16 + zz) * 16 + xx;
                                if (cell[j] != m || used[j]) break growY;
                            }
                        y1++;
                    }
                    for (int yy = y; yy <= y1; yy++)
                        for (int zz = z; zz <= z1; zz++)
                            for (int xx = x; xx <= x1; xx++) used[(yy * 16 + zz) * 16 + xx] = true;
                    List<Integer> l = perMat.get(m);
                    if (l == null) perMat.set(m, l = new ArrayList<>());
                    l.add(x);
                    l.add(y);
                    l.add(z);
                    l.add(x1 + 1);
                    l.add(y1 + 1);
                    l.add(z1 + 1);
                    int vol = (x1 - x + 1) * (y1 - y + 1) * (z1 - z + 1);
                    count[m] += vol;
                    volume += vol;
                }
        int n = 0;
        for (List<Integer> l : perMat) if (l != null) n++;
        Mat[] tm = new Mat[n];
        int[][] tb = new int[n][];
        int t = 0, best = -1;
        for (int m = 0; m < perMat.size(); m++) {
            List<Integer> l = perMat.get(m);
            if (l == null) continue;
            tm[t] = mats[m];
            int[] arr = new int[l.size()];
            for (int i = 0; i < arr.length; i++) arr[i] = l.get(i);
            tb[t++] = arr;
            if (best < 0 || count[m] > count[best]) best = m;
        }
        BlockRef fb = null;
        if (volume >= 4096 * 0.45 && best > 0) {
            BlockRef b = mats[best].block;
            if (!b.path().contains("glass")) fb = b;
        }
        return new LittleBlock(tm, tb, volume, fb);
    }
}
