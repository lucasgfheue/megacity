package com.megaciudad;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Configuración (config/megaciudad-common.toml). */
public final class Config {
    private Config() {
    }

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLED = BUILDER
            .comment("Generar la ciudad en el mundo normal (solo afecta a chunks nuevos).")
            .define("enabled", true);

    public static final ModConfigSpec.IntValue CENTER_X = BUILDER
            .comment("Coordenada X del centro de la ciudad (se ajusta a múltiplos de 16).")
            .defineInRange("centerX", 0, -29_000_000, 29_000_000);

    public static final ModConfigSpec.IntValue CENTER_Z = BUILDER
            .comment("Coordenada Z del centro de la ciudad (se ajusta a múltiplos de 16).")
            .defineInRange("centerZ", 0, -29_000_000, 29_000_000);

    public static final ModConfigSpec.BooleanValue SPAWN_IN_PLAZA = BUILDER
            .comment("Aparecer en la plaza central al crear un mundo nuevo.")
            .define("spawnInPlaza", true);

    public static final ModConfigSpec.IntValue INTERIOR_DETAIL = BUILDER
            .comment("Muebles y objetos de mini-bloques dentro de los edificios (cambiarlo antes de crear el mundo):",
                    "0 = sin muebles interiores (máximo rendimiento)",
                    "1 = liviano: en torres y departamentos, planta baja y primer piso completos; el resto con lo básico",
                    "2 = normal: además, los dos primeros pisos y uno de cada cuatro pisos completos",
                    "3 = completo: todos los pisos de todos los edificios amueblados (lo más pesado)",
                    "Casas, comercios y edificios públicos van siempre completos (salvo con 0).")
            .defineInRange("interiorDetail", 2, 0, 3);

    public static final ModConfigSpec SPEC = BUILDER.build();
}
