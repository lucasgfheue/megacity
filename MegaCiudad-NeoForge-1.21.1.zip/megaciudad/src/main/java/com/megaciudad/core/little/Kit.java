package com.megaciudad.core.little;

import com.megaciudad.core.BlockRef;

/**
 * Piezas de los mods que amueblan la ciudad, cada una con su alternativa si el mod no está instalado
 * (cadena "mod:bloque|otro_mod:bloque|minecraft:bloque").
 * <p>
 * Todas las decoraciones miran al norte (frente en z = 0). Convenciones de "facing" de cada mod para que
 * el frente quede al norte: Refurbished (MrCrayfish) y las escaleras usadas como asiento indican la
 * espalda (south); Farmer's Delight, Extra Delight, Create y los bloques vanilla tipo horno indican el
 * frente (north).
 */
public final class Kit {
    private Kit() {
    }

    public static final String RF = "refurbished_furniture:", FD = "farmersdelight:", CR = "create:", ED = "extradelight:",
            NP = "neapolitan:", CD = "createdeco:", SD = "sliceanddice:", MC = "minecraft:";

    public static final String[] WOODS = {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"};
    public static final String[] DYES = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};

    public static BlockRef r(String spec) {
        return BlockRef.of(spec);
    }

    public static final BlockRef AIR = r("minecraft:air");

    // ================================================================== constructores de modelos

    public static Model m(String name, int sx, int sy, int sz) {
        return new Model(name, sx, sy, sz);
    }

    public static Model one(String name, BlockRef b) {
        return new Model(name, 1, 1, 1).b(0, 0, 0, b);
    }

    /** Columna de abajo hacia arriba. */
    public static Model col(String name, BlockRef... layers) {
        Model m = new Model(name, 1, layers.length, 1);
        for (int y = 0; y < layers.length; y++) m.b(0, y, 0, layers[y]);
        return m;
    }

    /** Fila a lo largo de x. */
    public static Model row(String name, BlockRef... cells) {
        Model m = new Model(name, cells.length, 1, 1);
        for (int x = 0; x < cells.length; x++) m.b(x, 0, 0, cells[x]);
        return m;
    }

    /** Fila de dos pisos: abajo y arriba (null = vacío). */
    public static Model row2(String name, BlockRef[] low, BlockRef[] high) {
        Model m = new Model(name, low.length, 2, 1);
        for (int x = 0; x < low.length; x++) {
            m.b(x, 0, 0, low[x]);
            if (high != null && x < high.length) m.b(x, 1, 0, high[x]);
        }
        return m;
    }

    public static BlockRef[] n(int count, BlockRef b) {
        BlockRef[] a = new BlockRef[count];
        java.util.Arrays.fill(a, b);
        return a;
    }

    public static BlockRef[] a(BlockRef... b) {
        return b;
    }

    // ================================================================== MrCrayfish's Furniture Mod: Refurbished

    public static BlockRef chair(String wood) {
        return r(RF + wood + "_chair[facing=south,tucked=false]|" + MC + wood + "_stairs[facing=south]");
    }

    /** Mesa con uniones (n, e, s, w en coordenadas del modelo). */
    public static BlockRef table(String wood, boolean n, boolean e, boolean s, boolean w) {
        return r(RF + wood + "_table[north=" + n + ",east=" + e + ",south=" + s + ",west=" + w + "]|" + MC + wood + "_slab[type=top]");
    }

    /** Mesa de w x d celdas, unida. */
    public static Model tableGrid(String name, String wood, int w, int d) {
        Model m = new Model(name, w, 1, d);
        for (int z = 0; z < d; z++)
            for (int x = 0; x < w; x++) m.b(x, 0, z, table(wood, z > 0, x < w - 1, z < d - 1, x > 0));
        return m;
    }

    /** Pieza de sofá: shape default (sillón suelto), right (extremo oeste), middle, left (extremo este). */
    public static BlockRef sofa(String color, String shape) {
        return r(RF + color + "_sofa[facing=south,shape=" + shape + "]|" + MC + color + "_wool");
    }

    /** Sofá recto de n plazas mirando al norte. */
    public static BlockRef[] sofaRow(String color, int n) {
        BlockRef[] a = new BlockRef[n];
        for (int i = 0; i < n; i++) a[i] = sofa(color, n == 1 ? "default" : i == 0 ? "right" : i == n - 1 ? "left" : "middle");
        return a;
    }

    public static BlockRef desk(String wood, boolean left, boolean right) {
        return r(RF + wood + "_desk[facing=south,left=" + left + ",right=" + right + "]|" + MC + wood + "_slab[type=top]");
    }

    public static BlockRef[] deskRow(String wood, int n) {
        BlockRef[] a = new BlockRef[n];
        for (int i = 0; i < n; i++) a[i] = desk(wood, i > 0, i < n - 1);
        return a;
    }

    public static BlockRef drawer(String wood, boolean left, boolean right) {
        return r(RF + wood + "_drawer[facing=south,left=" + left + ",right=" + right + ",open=false]|" + MC + "barrel[facing=north]");
    }

    public static BlockRef[] drawerRow(String wood, int n) {
        BlockRef[] a = new BlockRef[n];
        for (int i = 0; i < n; i++) a[i] = drawer(wood, i > 0, i < n - 1);
        return a;
    }

    private static String fdWood(String mat) {
        for (String w : WOODS) if (w.equals(mat)) return w;
        return switch (mat) {
            case "white", "light_gray", "yellow", "lime", "pink" -> "birch";
            case "black", "gray", "brown", "purple" -> "dark_oak";
            case "red", "orange" -> "mangrove";
            default -> "spruce";
        };
    }

    /** Mueble bajo de cocina (madera o color). */
    public static BlockRef counter(String mat) {
        return r(RF + mat + "_kitchen_cabinetry[facing=south,shape=default]|" + FD + fdWood(mat) + "_cabinet[facing=north,open=false]|" + MC + "barrel[facing=north]");
    }

    public static BlockRef kdrawer(String mat) {
        return r(RF + mat + "_kitchen_drawer[facing=south,open=false]|" + ED + fdWood(mat) + "_counter_cabinet[facing=north,open=false]|" + MC + "barrel[facing=north]");
    }

    public static BlockRef ksink(String mat) {
        return r(RF + mat + "_kitchen_sink[facing=south]|" + ED + fdWood(mat) + "_sink[facing=north]|" + MC + "cauldron");
    }

    /** Alacena de pared (va arriba de la mesada). */
    public static BlockRef wallCab(String mat) {
        return r(RF + mat + "_kitchen_storage_cabinet[facing=south,open=false,hinge=left]|" + FD + fdWood(mat) + "_cabinet[facing=north,open=false]|" + MC + "barrel[facing=north]");
    }

    public static BlockRef cabinet(String wood, String hinge) {
        return r(RF + wood + "_storage_cabinet[facing=south,open=false,hinge=" + hinge + "]|" + FD + fdWood(wood) + "_cabinet[facing=north,open=false]|" + MC + "barrel[facing=north]");
    }

    public static final BlockRef FREEZER_L = r(RF + "light_freezer[facing=south,open=false]|" + MC + "iron_block");
    public static final BlockRef FRIDGE_L = r(RF + "light_fridge[facing=south,open=false]|" + MC + "iron_block");
    public static final BlockRef FREEZER_D = r(RF + "dark_freezer[facing=south,open=false]|" + MC + "polished_deepslate");
    public static final BlockRef FRIDGE_D = r(RF + "dark_fridge[facing=south,open=false]|" + MC + "polished_deepslate");
    public static final BlockRef STOVE_L = r(RF + "light_stove[facing=south,open=false,powered=false,lit=false]|" + FD + "stove[facing=north,lit=false]|" + MC + "smoker[facing=north]");
    public static final BlockRef STOVE_D = r(RF + "dark_stove[facing=south,open=false,powered=false,lit=false]|" + FD + "stove[facing=north,lit=false]|" + MC + "smoker[facing=north]");
    public static final BlockRef MICRO_L = r(RF + "light_microwave[facing=south,open=false]|" + MC + "air");
    public static final BlockRef MICRO_D = r(RF + "dark_microwave[facing=south,open=false]|" + MC + "air");
    public static final BlockRef TOASTER = r(RF + "light_toaster[facing=south,powered=false]|" + MC + "air");
    public static final BlockRef HOOD_L = r(RF + "light_range_hood[facing=south,powered=false]|" + MC + "air");
    public static final BlockRef HOOD_D = r(RF + "dark_range_hood[facing=south,powered=false]|" + MC + "air");
    public static final BlockRef TV = r(RF + "television[facing=south,powered=false]|" + MC + "black_concrete");
    public static final BlockRef COMPUTER = r(RF + "computer[facing=south,powered=false]|" + MC + "black_carpet");
    public static final BlockRef RECYCLE = r(RF + "recycle_bin[facing=south,open=false]|" + MC + "composter");
    public static final BlockRef PLATE = r(RF + "plate|" + MC + "air");
    public static final BlockRef PAN = r(RF + "frying_pan[facing=south,lit=false]|" + FD + "skillet[facing=north,support=false]|" + MC + "air");
    public static final BlockRef WORKBENCH = r(RF + "workbench[facing=south,powered=false]|" + MC + "crafting_table");
    public static final BlockRef GENERATOR = r(RF + "light_electricity_generator[facing=south,powered=false]|" + MC + "blast_furnace[facing=north]");
    public static final BlockRef POST_BOX = r(RF + "post_box[facing=south]|" + CR + "red_postbox[facing=north]|" + MC + "red_concrete");
    public static final BlockRef DOOR_MAT = r(RF + "door_mat[facing=south]|" + MC + "brown_carpet");
    public static final BlockRef CEIL_LIGHT = r(RF + "light_ceiling_light[face=ceiling,facing=north,powered=false]|" + MC + "lantern[hanging=true]");
    public static final BlockRef CEIL_LIGHT_D = r(RF + "dark_ceiling_light[face=ceiling,facing=north,powered=false]|" + MC + "lantern[hanging=true]");
    public static final BlockRef SWITCH = r(RF + "light_lightswitch[face=wall,facing=north,enabled=false,powered=false]|" + MC + "air");

    public static BlockRef fan(String wood) {
        return r(RF + wood + "_light_ceiling_fan[facing=up,powered=false,lit=false]|" + MC + "lantern[hanging=true]");
    }

    public static BlockRef lamp(String color) {
        return r(RF + color + "_lamp[powered=false]|" + MC + "lantern");
    }

    public static BlockRef stool(String color) {
        return r(RF + color + "_stool|" + MC + "oak_slab[type=bottom]");
    }

    public static BlockRef toilet(String mat) {
        return r(RF + mat + "_toilet[facing=south]|" + MC + "quartz_stairs[facing=south]");
    }

    public static BlockRef basin(String mat) {
        return r(RF + mat + "_basin[facing=south]|" + MC + "cauldron");
    }

    /** Bañera de 1x2 a lo largo de z: [0] = pie (z = 0), [1] = cabecera (z = 1). */
    public static BlockRef[] bath(String mat) {
        return new BlockRef[]{r(RF + mat + "_bath[facing=south,type=bottom]|" + MC + "cauldron"),
                r(RF + mat + "_bath[facing=south,type=head]|" + MC + "cauldron")};
    }

    public static BlockRef crate(String wood) {
        return r(RF + wood + "_crate[open=false]|" + MC + "barrel[facing=up]");
    }

    public static BlockRef cooler(String color) {
        return r(RF + color + "_cooler[facing=south,open=false]|" + MC + color + "_terracotta");
    }

    public static BlockRef grill(String color) {
        return r(RF + color + "_grill[facing=south]|" + MC + "campfire[lit=false]");
    }

    public static BlockRef hedge(String leaf) {
        return r(RF + leaf + "_hedge|" + MC + leaf + "_leaves[persistent=true]");
    }

    public static BlockRef jar(String wood) {
        return r(RF + wood + "_storage_jar[facing=south]|" + MC + "decorated_pot");
    }

    public static BlockRef board(String wood) {
        return r(RF + wood + "_cutting_board[facing=south]|" + FD + "cutting_board[facing=north]|" + MC + "air");
    }

    public static BlockRef mailbox(String wood) {
        return r(RF + wood + "_mail_box[facing=south,enabled=false]|" + MC + wood + "_fence");
    }

    // ================================================================== Farmer's Delight

    public static final BlockRef FD_STOVE = r(FD + "stove[facing=north,lit=false]|" + MC + "smoker[facing=north]");
    public static final BlockRef FD_STOVE_LIT = r(FD + "stove[facing=north,lit=true]|" + MC + "smoker[facing=north,lit=true]");
    public static final BlockRef POT = r(FD + "cooking_pot[facing=north,support=none]|" + MC + "cauldron");
    public static final BlockRef SKILLET = r(FD + "skillet[facing=north,support=false]|" + MC + "air");
    public static final BlockRef CUTTING = r(FD + "cutting_board[facing=north]|" + MC + "air");
    public static final BlockRef BASKET = r(FD + "wooden_basket[facing=up]|" + MC + "barrel[facing=up]");
    public static final BlockRef RICE_BAG = r(FD + "rice_bag|" + MC + "white_wool");
    public static final BlockRef STRAW = r(FD + "straw_bale[axis=y]|" + MC + "hay_block[axis=y]");

    public static BlockRef fdCrate(String what) {
        return r(FD + what + "_crate|" + MC + "barrel[facing=up]");
    }

    public static BlockRef fdCabinet(String wood) {
        return r(FD + wood + "_cabinet[facing=north,open=false]|" + MC + "barrel[facing=north]");
    }

    /** Tarta de Farmer's Delight entera (apple_pie, chocolate_pie, pumpkin_pie, sweet_berry_cheesecake). */
    public static BlockRef pie(String name) {
        return r(FD + name + "[bites=0,facing=north]|" + MC + "cake");
    }

    /** Fuente de comida de Farmer's Delight entera (roast_chicken_block, honey_glazed_ham_block...). */
    public static BlockRef feast(String name) {
        int max = name.equals("rice_roll_medley_block") ? 8 : 4;
        return r(FD + name + "[facing=north,servings=" + max + "]|" + MC + "cake");
    }

    // ================================================================== Extra Delight

    /** Tarta o cheesecake de Extra Delight (con alternativa de Farmer's Delight). */
    public static BlockRef edPie(String name) {
        return r(ED + name + "[bites=0,facing=north]|" + FD + "apple_pie[bites=0,facing=north]|" + MC + "cake");
    }

    /** Fuente de comida de Extra Delight (lasagna_block, curry_block, brownies...). */
    public static BlockRef edFeast(String name, String fdAlt) {
        return r(ED + name + "[facing=north,servings=4]|" + FD + fdAlt + "[facing=north,servings=4]|" + MC + "cake");
    }

    public static BlockRef edCake(String name) {
        return r(ED + name + "[bites=0]|" + MC + "cake");
    }

    public static BlockRef ed(String name) {
        return r(ED + name + "|" + MC + "air");
    }

    public static BlockRef edCrate(String what) {
        return r(ED + what + "|" + FD + "carrot_crate|" + MC + "barrel[facing=up]");
    }

    public static final BlockRef OVEN = r(ED + "oven[facing=north,support=none]|" + FD + "stove[facing=north,lit=false]|" + MC + "smoker[facing=north]");
    public static final BlockRef CHILLER = r(ED + "chiller[facing=north]|" + MC + "packed_ice");
    public static final BlockRef JUICER = r(ED + "juicer[facing=north,style=0]|" + MC + "brewing_stand");
    public static final BlockRef MIXING_BOWL = r(ED + "mixing_bowl|" + MC + "air");
    public static final BlockRef CANDY_BOWL = r(ED + "candy_bowl|" + MC + "air");
    public static final BlockRef FRUIT_BOWL = r(ED + "fruit_bowl|" + MC + "air");
    public static final BlockRef JAR_DISPLAY = r(ED + "jar_display_block|" + MC + "air");

    public static BlockRef spiceRack(String wood) {
        return r(ED + wood + "_spice_rack_full[facing=north]|" + MC + "air");
    }

    public static BlockRef knifeBlock(String wood) {
        return r(ED + wood + "_knife_block[facing=north]|" + MC + "air");
    }

    public static BlockRef foodDisplay(String wood) {
        return r(ED + wood + "_food_display[facing=north,encased=true]|" + MC + "glass");
    }

    public static BlockRef chocoBox(String color) {
        return r(ED + color + "_chocolate_box[facing=north,open=false]|" + MC + "air");
    }

    public static BlockRef picnicBasket(String color) {
        return r(ED + color + "_picnic_basket[facing=north]|" + FD + "wooden_basket[facing=up]|" + MC + "barrel[facing=up]");
    }

    public static BlockRef gingham(String color) {
        return r(ED + "gingham_carpet_" + color + "|" + MC + color + "_carpet");
    }

    // ================================================================== Neapolitan (helados)

    public static final String[] FLAVORS = {"vanilla", "chocolate", "strawberry", "banana", "mint", "adzuki"};
    private static final String[] FLAVOR_ALT = {"snow_block", "brown_concrete_powder", "pink_concrete_powder",
            "yellow_concrete_powder", "lime_concrete_powder", "red_concrete_powder"};

    public static BlockRef iceCream(int i) {
        i = Math.floorMod(i, FLAVORS.length);
        return r(NP + FLAVORS[i] + "_ice_cream_block|" + MC + FLAVOR_ALT[i]);
    }

    public static BlockRef npCake(int i) {
        i = Math.floorMod(i, FLAVORS.length);
        return r(NP + FLAVORS[i] + "_cake[bites=0]|" + ED + "chocolate_cake[bites=0]|" + MC + "cake");
    }

    public static BlockRef milkshake(int i) {
        i = Math.floorMod(i, FLAVORS.length);
        return r(NP + FLAVORS[i] + "_milkshake_cauldron[level=3]|" + MC + "powder_snow_cauldron[level=3]");
    }

    public static final BlockRef WAFFLE = r(NP + "waffle_cone_block|" + MC + "orange_terracotta");
    public static final BlockRef CHOCOLATE_BLOCK = r(NP + "chocolate_block|" + MC + "brown_terracotta");
    public static final BlockRef CHILLBOX = r(NP + "chillbox|" + ED + "chiller[facing=north]|" + MC + "packed_ice");
    public static final BlockRef STRAWBERRIES = r(NP + "strawberry_basket[facing=up]|" + FD + "tomato_crate|" + MC + "barrel[facing=up]");
    public static final BlockRef BANANAS = r(NP + "banana_crate[facing=up]|" + FD + "carrot_crate|" + MC + "barrel[facing=up]");
    public static final BlockRef MINT = r(NP + "mint_basket[facing=up]|" + FD + "cabbage_crate|" + MC + "barrel[facing=up]");

    // ================================================================== Create

    public static BlockRef cr(String spec, String alt) {
        return r(CR + spec + "|" + alt);
    }

    public static BlockRef seat(String color) {
        return r(CR + color + "_seat|" + MC + color + "_carpet");
    }

    public static BlockRef toolbox(String color) {
        return r(CR + color + "_toolbox[facing=north]|" + MC + "chest[facing=north]");
    }

    public static BlockRef cloth(String color) {
        return r(CR + color + "_table_cloth|" + RF + "oak_table[north=false,east=false,south=false,west=false]|" + MC + "smooth_stone_slab[type=top]");
    }

    public static BlockRef postbox(String color) {
        return r(CR + color + "_postbox[facing=north,open=false]|" + MC + "red_concrete");
    }

    public static BlockRef valve(String color) {
        return r(CR + color + "_valve_handle[facing=north]|" + MC + "air");
    }

    public static final BlockRef SHAFT_X = cr("shaft[axis=x]", MC + "chain[axis=x]");
    public static final BlockRef SHAFT_Y = cr("shaft[axis=y]", MC + "chain[axis=y]");
    public static final BlockRef SHAFT_Z = cr("shaft[axis=z]", MC + "chain[axis=z]");
    public static final BlockRef COG_Y = cr("cogwheel[axis=y]", MC + "stripped_spruce_log[axis=y]");
    public static final BlockRef COG_Z = cr("cogwheel[axis=z]", MC + "stripped_spruce_log[axis=z]");
    public static final BlockRef BIG_COG_Z = cr("large_cogwheel[axis=z]", MC + "stripped_spruce_wood[axis=z]");
    public static final BlockRef GEARBOX = cr("gearbox[axis=y]", MC + "polished_andesite");
    public static final BlockRef ANDESITE_CASING = cr("andesite_casing", MC + "polished_andesite");
    public static final BlockRef BRASS_CASING = cr("brass_casing", MC + "stripped_dark_oak_wood");
    public static final BlockRef COPPER_CASING = cr("copper_casing", MC + "waxed_cut_copper");
    public static final BlockRef RAILWAY_CASING = cr("railway_casing", MC + "polished_deepslate");
    public static final BlockRef ENCASED_SHAFT = cr("andesite_encased_shaft[axis=y]", MC + "polished_andesite");
    public static final BlockRef PRESS = cr("mechanical_press[facing=north]", MC + "piston[facing=down]");
    public static final BlockRef MIXER = cr("mechanical_mixer", MC + "piston[facing=down]");
    public static final BlockRef BASIN = cr("basin[facing=down]", MC + "cauldron");
    public static final BlockRef DEPOT = cr("depot", MC + "smooth_stone_slab[type=bottom]");
    public static final BlockRef MILLSTONE = cr("millstone", MC + "stonecutter[facing=north]");
    public static final BlockRef FAN = cr("encased_fan[facing=north]", MC + "dispenser[facing=north]");
    public static final BlockRef FAN_UP = cr("encased_fan[facing=up]", MC + "dispenser[facing=up]");
    public static final BlockRef DRILL = cr("mechanical_drill[facing=north]", MC + "dispenser[facing=north]");
    public static final BlockRef SAW_UP = cr("mechanical_saw[facing=up,axis_along_first=false,flipped=false]", MC + "stonecutter[facing=north]");
    public static final BlockRef DEPLOYER = cr("deployer[facing=down,axis_along_first=false]", MC + "dispenser[facing=down]");
    public static final BlockRef ARM = cr("mechanical_arm[ceiling=false]", MC + "lightning_rod[facing=up]");
    public static final BlockRef CRAFTER = cr("mechanical_crafter[facing=north,pointing=up]", MC + "crafting_table");
    public static final BlockRef CRUSHER_Z = cr("crushing_wheel[axis=z]", MC + "smooth_stone");
    public static final BlockRef SPOUT = cr("spout", MC + "hopper[facing=down]");
    public static final BlockRef DRAIN = cr("item_drain", MC + "cauldron");
    public static final BlockRef CHUTE = cr("chute[facing=down,shape=normal]", MC + "hopper[facing=down]");
    public static final BlockRef TANK = cr("fluid_tank[bottom=true,top=true,shape=window]", MC + "waxed_copper_block");
    public static final BlockRef TANK_LOW = cr("fluid_tank[bottom=true,top=false,shape=window]", MC + "waxed_copper_block");
    public static final BlockRef TANK_HIGH = cr("fluid_tank[bottom=false,top=true,shape=window]", MC + "waxed_copper_block");
    public static final BlockRef VAULT = cr("item_vault[axis=x,large=false]", MC + "iron_block");
    public static final BlockRef PUMP_UP = cr("mechanical_pump[facing=up]", MC + "waxed_copper_block");
    public static final BlockRef PIPE_Y = cr("fluid_pipe[up=true,down=true,north=false,south=false,east=false,west=false]", MC + "chain[axis=y]");
    public static final BlockRef PIPE_X = cr("fluid_pipe[east=true,west=true,north=false,south=false,up=false,down=false]", MC + "chain[axis=x]");
    public static final BlockRef STEAM_ENGINE = cr("steam_engine[face=floor,facing=north]", MC + "air");
    public static final BlockRef WHISTLE = cr("steam_whistle[facing=north,size=medium,wall=false,powered=false]", MC + "air");
    public static final BlockRef BURNER = cr("blaze_burner[blaze=smouldering]", MC + "campfire[lit=false]");
    public static final BlockRef BURNER_EMPTY = cr("blaze_burner", MC + "blast_furnace[facing=north]");
    public static final BlockRef FLYWHEEL = cr("flywheel[axis=z]", MC + "stripped_spruce_wood[axis=z]");
    public static final BlockRef WATER_WHEEL = cr("water_wheel[facing=north]", MC + "air");
    public static final BlockRef CRANK = cr("hand_crank[facing=up]", MC + "lever[face=floor,facing=north]");
    public static final BlockRef SPEEDOMETER = cr("speedometer[facing=north,axis_along_first=false]", MC + "observer[facing=north]");
    public static final BlockRef STRESSOMETER = cr("stressometer[facing=north,axis_along_first=false]", MC + "observer[facing=north]");
    public static final BlockRef TURNTABLE = cr("turntable", MC + "smooth_stone_slab[type=bottom]");
    public static final BlockRef CLOCK = cr("cuckoo_clock[facing=north]", MC + "dark_oak_trapdoor[facing=north,half=bottom,open=true]");
    public static final BlockRef DESK_BELL = cr("desk_bell[facing=up]", MC + "air");
    public static final BlockRef DISPLAY = cr("display_board[facing=north]", MC + "black_wall_banner[facing=north]");
    public static final BlockRef NIXIE = cr("nixie_tube[double_face=floor,facing=north]", MC + "air");
    public static final BlockRef CLIPBOARD = cr("clipboard[face=floor,facing=north,written=true]", MC + "air");
    public static final BlockRef SCHEMATIC_TABLE = cr("schematic_table[facing=north]", MC + "cartography_table");
    public static final BlockRef SCHEMATICANNON = cr("schematicannon", MC + "dispenser[facing=up]");
    public static final BlockRef BACKTANK = cr("copper_backtank[facing=north]", MC + "lightning_rod[facing=up]");
    public static final BlockRef NETHERITE_TANK = cr("netherite_backtank[facing=north]", MC + "lightning_rod[facing=up]");
    public static final BlockRef PLACARD = cr("placard[face=wall,facing=north]", MC + "air");
    public static final BlockRef QUARTZ_LAMP = cr("rose_quartz_lamp", MC + "redstone_lamp");
    public static final BlockRef BRACKET = cr("metal_bracket[facing=up,type=shaft,axis_along_first=false]", MC + "air");
    public static final BlockRef GIRDER = cr("metal_girder", MC + "polished_andesite_wall");
    public static final BlockRef INDUSTRIAL_IRON = cr("industrial_iron_block", MC + "polished_deepslate");
    public static final BlockRef LADDER = cr("andesite_ladder[facing=north]", MC + "ladder[facing=north]");
    public static final BlockRef ANDESITE_BARS = cr("andesite_bars[east=true,west=true,north=false,south=false]", MC + "iron_bars[east=true,west=true]");
    public static final BlockRef SCAFFOLD = cr("andesite_scaffolding", MC + "oak_fence");
    public static final BlockRef CARDBOARD = cr("cardboard_block[axis=x]", MC + "barrel[facing=up]");
    public static final BlockRef CARDBOARD_TIED = cr("bound_cardboard_block[axis=z]", MC + "barrel[facing=up]");
    public static final BlockRef PACKAGER = cr("packager[facing=north,linked=false,powered=false]", MC + "dropper[facing=north]");
    public static final BlockRef REPACKAGER = cr("repackager[facing=north,powered=false]", MC + "dispenser[facing=north]");
    public static final BlockRef STOCK_TICKER = cr("stock_ticker[facing=north]", MC + "lectern[facing=north]");
    public static final BlockRef STOCK_LINK = cr("stock_link[face=floor,facing=north,powered=false]", MC + "air");
    public static final BlockRef FROGPORT = cr("package_frogport", MC + "barrel[facing=up]");
    public static final BlockRef EJECTOR = cr("weighted_ejector[facing=north]", MC + "heavy_weighted_pressure_plate");
    public static final BlockRef PSI = cr("portable_storage_interface[facing=up]", MC + "barrel[facing=up]");
    public static final BlockRef CONTROLS = cr("controls[facing=north,open=false,virtual=false]", MC + "lectern[facing=north]");
    public static final BlockRef FRAMED_GLASS = cr("framed_glass", MC + "glass");
    public static final BlockRef ORNATE_WINDOW = cr("ornate_iron_window", MC + "glass");
    public static final BlockRef EXPERIENCE = cr("experience_block", MC + "emerald_block");

    // ================================================================== Create Deco y Slice & Dice

    /** Farol de jaula encendido: up = apoyado en el piso, down = colgado del techo. */
    public static BlockRef cageLamp(String color, String metal, String facing) {
        String alt = facing.equals("down") ? MC + "lantern[hanging=true]" : MC + "lantern";
        return r(CD + color + "_" + metal + "_lamp[facing=" + facing + ",lit=true,inverted=true]|" + alt);
    }

    public static BlockRef coins(String metal, int layers) {
        return r(CD + metal + "_coinstack[layers=" + layers + "]|" + MC + "light_weighted_pressure_plate");
    }

    public static BlockRef container(String color, String axis) {
        return r(CD + color + "_shipping_container[axis=" + axis + ",large=false]|" + CR + "item_vault[axis=" + axis + ",large=false]|" + MC + color + "_concrete");
    }

    public static final BlockRef SLICER = r(SD + "slicer|" + CR + "mechanical_press[facing=north]|" + MC + "stonecutter[facing=north]");
    public static final BlockRef SPRINKLER = r(SD + "sprinkler[type=ceiling]|" + MC + "air");

    // ================================================================== vanilla

    public static BlockRef v(String spec) {
        return r(MC + spec);
    }

    public static final BlockRef BOOKS = v("bookshelf");
    public static final BlockRef CHISELED = v("chiseled_bookshelf[facing=north]");
    public static final BlockRef BARREL_N = v("barrel[facing=north]");
    public static final BlockRef BARREL_UP = v("barrel[facing=up]");
    public static final BlockRef BREWING = v("brewing_stand");
    public static final BlockRef LANTERN = v("lantern");
    public static final BlockRef LANTERN_HANG = v("lantern[hanging=true]");
    public static final BlockRef LECTERN = v("lectern[facing=north]");
    public static final BlockRef NOTE = v("note_block");
    public static final BlockRef JUKEBOX = v("jukebox");
    public static final BlockRef HOPPER = v("hopper[facing=down]");
    public static final BlockRef CAULDRON_WATER = v("water_cauldron[level=3]");
    /** Panel adosado a la pared del fondo (trampilla de hierro abierta). */
    public static final BlockRef MIRROR = v("iron_trapdoor[facing=north,half=bottom,open=true]");

    public static BlockRef wood(String w, String part) {
        return v(w + "_" + part);
    }

    public static BlockRef banner(String color) {
        return v(color + "_wall_banner[facing=north]");
    }

    public static BlockRef standingBanner(String color) {
        return v(color + "_banner[rotation=8]");
    }

    public static BlockRef potted(String plant) {
        return v("potted_" + plant);
    }

    public static BlockRef leaves(String leaf) {
        return v(leaf + "_leaves[persistent=true]");
    }

    public static BlockRef wallSign(String wood) {
        return v(wood + "_wall_sign[facing=north]");
    }

    public static BlockRef seatStairs(String material) {
        return v(material + "_stairs[facing=south]");
    }

    public static BlockRef bed(String color, String part) {
        return v(color + "_bed[facing=south,part=" + part + "]");
    }

    public static BlockRef pane(String color, boolean e, boolean w) {
        String id = color == null ? "glass_pane" : color + "_stained_glass_pane";
        return v(id + "[east=" + e + ",west=" + w + ",north=false,south=false]");
    }

    public static BlockRef bars(boolean e, boolean w) {
        return v("iron_bars[east=" + e + ",west=" + w + ",north=false,south=false]");
    }

    private static final java.util.Map<String, Model> SEATS = new java.util.concurrent.ConcurrentHashMap<>();

    /** Silla de madera (Refurbished) como modelo suelto, para rodear mesas. */
    public static Model chairModel(String wood) {
        return SEATS.computeIfAbsent("silla_" + wood, k -> one(k, chair(wood)));
    }

    /** Asiento de Create (almohadón de color) como modelo suelto. */
    public static Model seatModel(String color) {
        return SEATS.computeIfAbsent("asiento_" + color, k -> one(k, seat(color)));
    }

    public static Model stoolModel(String color) {
        return SEATS.computeIfAbsent("banqueta_" + color, k -> one(k, stool(color)));
    }

    public static String pick(String[] a, int i) {
        return a[Math.floorMod(i, a.length)];
    }
}
